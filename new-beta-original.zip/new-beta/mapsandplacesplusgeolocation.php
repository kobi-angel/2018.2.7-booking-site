<!DOCTYPE HTML>
<html><html lang="en">
  <head>
   <meta charset="UTF-8>
   <meta name="veiwport" content="width=device-width,
   initial-scale=1.0">
   <meta http-equiv=X-UA-Compatible" content="ie=edge">
   <title>My Google Map</title>
   <style>
     #map{
       height:400px;
       width:100%;
      }
   </style>
</head>
 <body>
    <div id="map"></div>
    <script>
       function initMap() {
          var options = {
             zoom:8,
             center: {lat: -34.397, lng: 150.644}
            }
         
           var map = new google.maps.Map(document.getElementById('map'), options); 
      }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCABsUV0eCHYDSoBWQtULGfwG6lnEY7zIQ&callback=initMap"
    async defer></script
</body>
</html>
