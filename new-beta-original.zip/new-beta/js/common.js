
// Weather 
$(document).ready(function() {
$.ajax( {
            type: 'GET',
            url: '//geoapi123.appspot.com/',
            dataType: 'script',
            cache: true,
            success: function() {
              var geo = geoip_country_code() + '|' + geoip_region_name() + '|' + geoip_city() + '|' + geoip_latitude() + '|' + geoip_longitude();
               $.ajax({
     
              //url: "http://api.openweathermap.org/data/2.5/weather?q=Lagos,Nigeria&appid=371f15346191ae114ca4ab11f4db4e2f",
              url:"http://api.openweathermap.org/data/2.5/weather?q="+geoip_city()+','+geoip_country_code()+"&appid=371f15346191ae114ca4ab11f4db4e2f",
              success: function(data){
               // [0 Kalvin = -273.15 Celsius] Conversion (k to c);
                var cel=data.main.temp - 273.15;
                $('#weatherName').html(data.name);
                $('#weatherImg').attr('src', 'https://openweathermap.org/img/w/'+data.weather[0].icon+'.png');
                $('#weatherCelsius').html(Math.round(cel)   +'' + ' &#8451;');
                $('#weatherCloudiness').html(data.weather[0].description);
              }
            });
            }
        });



});


// =====================
$(document).ready(function() {
  var s = $(".navbar-default");                   
  $(window).scroll(function() {
      var windowpos = $(window).scrollTop();
      if (windowpos >= 70) {
          s.addClass("top-sticky");
      } else {
          s.removeClass("top-sticky");
      }
  });
});

// //go to top on page
$(document).ready(function(){
  $(window).scroll(function(){
    if($(this).scrollTop()>450){
      $('.gototop').fadeIn();
    }
    else{$('.gototop').fadeOut();
    }
  });
  $('.gototop').click(function(){
    $('html, body').animate({scrollTop:0},1200);
    return false;
  });
});


$(document).on('click', '.porfolio-sh', function(e) {
  e.preventDefault();
  var findText = $(this).text();
  if (findText =='View Price') {
    $(this).parent().addClass('in');
    $(this).text('Hide');
  }
  else{
    $(this).parent().removeClass('in');
    $(this).text('View Price');
  }
});

$(document).on('click', '[data-tabing]', function() {
  $('[data-tabing]').removeClass('active');
  $(this).addClass('active');
  var getTarget = $(this).data('tabing');
  if (getTarget=='all') {
    $('[data-city]').show(500);
  }
  if(getTarget=='africa'){
    $('[data-city]').hide(500);
    $('[data-city="africa"]').show(500);
  }
  if(getTarget=='nigeria'){
    $('[data-city]').hide(500);
    $('[data-city="nigeria"]').show(500);
  }
});



// ===================================================
// ===================================================
// Set passenger and cabin
// ===================================================
// ===================================================
$(document).on('click', '[data-counting]', function(){
  var getVal = $(this).data('counting');
  var getLastName = $(this).data('person');
  var getCurrentVal = $($(this).parent().parent().find('.form-control')[0]).val();
  // Click on Minus Sign
  if (getVal.split(',')[0]=="minus" || getVal.split(',')[1]==getLastName) {
    if (getCurrentVal==null || getCurrentVal=='' || getCurrentVal=='1') {
      $($(this).parent().parent().find('.form-control')[0]).val('');
    }
    else{
      $($(this).parent().parent().find('.form-control')[0]).val(getCurrentVal - 1);
    }
  }
  // Click on Plus Sign
  if (getVal.split(',')[0]=="plus" || getVal.split(',')[1]==getLastName) {
    if (getCurrentVal==null || getCurrentVal=='' || getCurrentVal=='0') {
      $($(this).parent().parent().find('.form-control')[0]).val('1');
    }
    else{
      $($(this).parent().parent().find('.form-control')[0]).val(parseInt(getCurrentVal) + 1);
    }
  }
  cabinSet();
});


$(document).on('change', '#CabinSet', function(){
  cabinSet();
});

function cabinSet(){
  var getSelectedCabin = $('#CabinSet').val();
  var getAdultVal      = parseInt($('.adult-field').val()); // Adults
  var getChildrenVal      = parseInt($('.children-field').val()); // Children
  var getInfantVal     = parseInt($('.infant-field').val()); // Infant

  var setval1 = getAdultVal>0 ? getAdultVal+' Adult, ' : '';
  var setval2 =  getChildrenVal>0 ? getChildrenVal+' Children, ' : '';
  var setval3 = getInfantVal>0 ? getInfantVal+' Infant, ' : '';
  var setval  = (getAdultVal>0 || getChildrenVal>0 || getInfantVal>0) ? setval1+setval2+setval3+getSelectedCabin : '';
  
  $("#TargetValSet").val(setval);
}
$('#TargetValSet').on('focus', function(){
  $('.cabin-wrapper').addClass('open-cabin');
});
$('#RoomTarget').on('focus', function(){
  $('.cabin-wrapper').addClass('open-cabin');
});

$('#addRoom').on('click' , function(){
  	var count = $(".roomCont").length;
  	count++;
	if(count == 2){
   		$('#removeRoom').removeClass("hide");
	} 
  	var cont = $(".roomCont.firstElement").clone();
  	cont.addClass("room" +count);
  	cont.removeClass("firstElement");
  	$(".cabin-design #roomWrapper").append(cont);
  	var container = $("#roomWrapper .roomCont.room"+count);
  	container.find("#roomCount").html("");
 	container.find("#roomCount").html("Room " + count);
  	if(count == 5){
   		$('#addRoom').addClass("hide");
	} 
});
$('#removeRoom').on('click' , function(){
  	var count = $(".roomCont").length;
	var container = $("#roomWrapper .roomCont.room"+count);
  	container.remove();
	if(count == 5){
   		$('#addRoom').removeClass("hide");
	} 
	if(count == 2){
   		$('#removeRoom').addClass("hide");
	} 
});

$(document).click(function(e) {
  if (!$(e.target).is('.cabin-wrapper, .cabin-wrapper *')) {
    $('.cabin-wrapper').removeClass('open-cabin');
  }
});
// ===================================================
// ===================================================
// End //Set passenger and cabin
// ===================================================
// ===================================================


// ===================================================
// ===================================================
// Datepicket for checkin and checkout
// ===================================================
// ===================================================
$(function () {
  $('#datepicker1').datetimepicker({
    format: 'MM/DD/YYYY',
    minDate:new Date(),
    'allowInputToggle' : true
  });
  $('#datepicker2').datetimepicker({
    format: 'MM/DD/YYYY',
    useCurrent: false, //Important! See issue #1075
    'allowInputToggle' : true
  });
  $("#datepicker1").on("dp.change", function (e) {
    $('#datepicker2').data("DateTimePicker").minDate(e.date);
  });
  $("#datepicker2").on("dp.change", function (e) {
    $('#datepicker1').data("DateTimePicker").maxDate(e.date);
  });
});
// ===================================================
// ===================================================
// End // Datepicket for checkin and checkout
// ===================================================
// ===================================================









//When whole page loaded then hide loader
//This should be always on bottom side 
window.onload = function () { 
  setTimeout(function(){
    $('#loader').fadeOut();
  },100);
}