<?php

header('Content-Type: text/html; charset=utf-8');
error_reporting(E_ERROR | E_WARNING | E_PARSE);


	function random_string($type = 'alnum', $len = 8){					
		switch($type)
		{
			case 'alnum'	:
			case 'numeric'	:
			case 'nozero'	:
			case 'captcha'	:
			
					switch ($type)
					{
						case 'alnum'	:	$pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
							break;
						case 'numeric'	:	$pool = '0123456789';
							break;
						case 'nozero'	:	$pool = '123456789';
							break;
						case 'captcha'	:	$pool = '123456789abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ';
							break;
					}
	
					$str = '';
					for ($i=0; $i < $len; $i++)
					{
						$str .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
					}
					return $str;
			  break;
			case 'unique' : return md5(uniqid(mt_rand()));
			  break;
		}
	}
	
	
// This flag is used to check if user is sent from
// index page.
$is_user_refered = 0;

// This is to apply referer, if there is One
$is_there_referer = '';
$is_there_referer = $_SERVER['HTTP_REFERER'];

if($is_there_referer != ''){
	$is_user_refered = 1;
}

// Test echoes
//echo $is_there_referer.'<br/>';
//echo $is_user_referered.'<br/>';

$user_random_id = random_string('unique',64);
//echo $user_random_id;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Gokuest</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-datetimepicker.min.css">
  <link href="css/style.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">

 
  <link rel="stylesheet" href="css/teleport-autocomplete.css">


  <script src="js/jquery.1.12.4.min.js"></script>
  
  
  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->


    <!-- Autocomplete JS -->
   <script>
    function get_airport_suggestions(my_input_value, from_to_marker){
        $.ajax({
            type: "POST",
            url: 'php/get_airport_suggestions.php',
            data: {my_input_value: my_input_value},
            success: function( response ) {                          
                $('#search_response_'+from_to_marker).html(response).addClass('open');
                from_to_marker = '';
                $('.open .suggestion').click(function(e) {
                    suggestion_value = $(this).html();
                    $(this).parents('.tp-autocomplete').find('input').attr('title',suggestion_value).val(suggestion_value);
                    $(this).parent().removeClass('open');
                });
            }
        });
    }
       
    $('document').ready( function(){
    
        $(document).click(function(e) {
          if (!$(e.target).is('.my-input-from, #search_response_from *')) {
             $('#search_response_from').removeClass('open');
             if($('.my-input-from').val() == my_input_from_value){
                $('.my-input-from').val('');
             }
          }
        });

        $(document).click(function(e) {
          if (!$(e.target).is('.my-input-to, #search_response_to *')) {
             $('#search_response_to').removeClass('open');
             if($('.my-input-to').val() == my_input_to_value){
                $('.my-input-to').val('');
             }             
          }
        });
        
        my_input_from_value= '';
        my_input_to_value= '';    
        my_input_from_counter = 0;
        my_input_to_counter = 0;
        from_to_marker = '';
      $('.my-input-from').bind('input', function() {
            my_input_from_counter = $('.my-input-from').val().length;
         //alert(my_input_from_counter);
         if(my_input_from_counter >= 3){
                my_input_from_value = $('.my-input-from').val();
                from_to_marker = 'from';
                get_airport_suggestions(my_input_from_value, from_to_marker);
         }
         else{
                $('.my-input-from').next().removeClass('open');
         }
        
      });
      
      $('.my-input-to').bind('input', function() {
            my_input_to_counter = $('.my-input-to').val().length;
            //alert(my_input_to_counter);
         if(my_input_to_counter >= 3){
                my_input_to_value = $('.my-input-to').val();
                from_to_marker = 'to';
                get_airport_suggestions(my_input_to_value, from_to_marker);
         }
         else{
                $('.my-input-to').next().removeClass('open');
         }                     
      }); 
      
   });            
   </script>
    
    
<script>  
    
        function addCommas(str) {
            var parts = (str + "").split("."),
                main = parts[0],
                len = main.length,
                output = "",
                first = main.charAt(0),
                i;

            if (first === '-') {
                main = main.slice(1);
                len = main.length;    
            } else {
                first = "";
            }
            i = len - 1;
            while(i >= 0) {
                output = main.charAt(i) + output;
                if ((len - i) % 3 === 0 && i > 0) {
                    output = "," + output;
                }
                --i;
            }
            // put sign back
            output = first + output;
            // put decimal part back
            if (parts.length > 1) {
                output += "." + parts[1];
            }
            return output;
        }
        
        // function for ajax calling with search params
        function AjaxWithSearchParams(){
        
						// Create and apply new random id every time seacrch is done.
						var user_random_id = '<?php $user_random_id = random_string('unique', 64); echo $user_random_id; ?>';
						$('#user_random_id').val(user_random_id);
						
						// Array of flights systems list
						var flights_system = new Array('travelpaddy', 'travelbeta', 'travelden', 'wakanow', 'sabre');
						
						// Counter of flights systems result
						var flights_system_result = 0;
						
						// Number of used crawlers
						var number_of_crawlers = 5;
						
						var form = $('#search_form');
						$('.cabin-wrapper').removeClass('open-cabin');
						if($('#from').val() != '' && $('#to').val() != '' && $('#check_in').val() != '' && $('#check_out').val() != '' && $('#TargetValSet').val() != ''){
                   
                    $('#loader').fadeIn('slow');
                    $('.kiss').remove();
                    if($('#search_values_response').hasClass('opened')){
                        $('#search_values_response').slideUp('slow').removeClass('opened');
                    }
								
 								$('#flights_system').val('travelpaddy');																
								$.ajax( {
									type: "POST",
									url: form.attr( 'action' ),
									data: form.serialize(),
									success: function( response ) {
										flights_system_result++;
										//alert(flights_system_result);
									}
								});
								
								
 								$('#flights_system').val('travelbeta');																
								$.ajax( {
									type: "POST",
									url: form.attr( 'action' ),
									data: form.serialize(),
									success: function( response ) {
										flights_system_result++;
										//alert(flights_system_result);
									}
								});
								
								
 								$('#flights_system').val('travelden');																
								$.ajax( {
									type: "POST",
									url: form.attr( 'action' ),
									data: form.serialize(),
									success: function( response ) {
										flights_system_result++;
										//alert(flights_system_result);
									}
								});
								
								
 								$('#flights_system').val('wakanow');																
								$.ajax( {
									type: "POST",
									url: form.attr( 'action' ),
									data: form.serialize(),
									success: function( response ) {
										flights_system_result++;
										//alert(flights_system_result);
									}
								});
							
							
 								$('#flights_system').val('sabre');																
								$.ajax( {
									type: "POST",
									url: form.attr( 'action' ),
									data: form.serialize(),
									success: function( response ) {
										flights_system_result++;
										//alert(flights_system_result);
									}
								});
														
							check_is_done();							
							
							function check_is_done(){
								if(flights_system_result == number_of_crawlers){
								
									//alert('We 4 are here!');
									get_flights_details();
								}
								else{									                   
									setTimeout(function(){ 							
										check_is_done(); 							
									}, 1000);
								}
							}
							
						  
						  function get_flights_details(){                
							  $.ajax( {
									type: "POST",
									url: "php/get_search_result.php",
									data: form.serialize(),
									success: function( response ) {
									  
									if(response == 'NOK'){
										 $('#loader').fadeOut('slow', function(){
											  $('#search_response').html('<div class="sorry" style="text-align:center;color:orangered;font-size:17px">Sorry. The flight option you are trying to book is not available. This usually occurs in case of limited seats being available or temporary non connectivity with the airline reservation system. Please, try again using a different date combination OR after a little while.</div>');
										 });
									  }
									  else{
									  
											$('#search_response').html('');
											
											$('#loader').fadeOut('slow', function(){
												 
												 // After 5 minutes a message for outdated prices and seats
												 setTimeout(function(){ 							
													 $('#outdated_reminder').fadeIn('slow'); 							
												 }, 360000);
												 
												 // When user click on 'OK' above message is closed
												 $('#outdated_reminder_close').click(function(){
													 $('#outdated_reminder').fadeOut('slow');
												 });
												 
												 //$('#search_response').html(response);
												 
												 // Transform json php output to array
												 // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
													frontend_array = jQuery.parseJSON( response );
													
													airlines_filter_list = new Array();
													stops_filter_list = new Array();
													for (var i = 0; i < frontend_array.length; i++) {
													    
														  //console.log('id: ' + frontend_array[i].id);
														  
														  $('#flight_template').clone(true).attr('id',frontend_array[i].id).addClass('time_filter').addClass('kiss').appendTo('#chorni');
														  
														  // Sliders Names
														  //----------------
														  $('#depart_origin').html(frontend_array[i].origin_city_name);
														  //console.log('depart_origin: ' + frontend_array[i].origin_city_name);
														  $('#arrive_destination').html(frontend_array[i].destination_city_name);
														  $('#depart_destination').html(frontend_array[i].destination_city_name);
														  $('#arrive_origin').html(frontend_array[i].origin_city_name);
														  
														  
														  
														  // Set Sliders times
														  //----------------------
														  //---------------------------------
													  
														  // Depart Origin Slider
														  //---------------------------------------
														  if(i == 0){
																 departure_origin_time_splitted = (frontend_array[i].departure_origin_time).split(':');
															    depart_origin_min = parseInt(departure_origin_time_splitted[0]);
															    depart_origin_max = parseInt(departure_origin_time_splitted[0]);
															    //alert('Min is '+depart_origin_min+'<br>Max is '+depart_origin_max);
																 $("#slider_range_depart_origin").slider({
																	  range: true,
																	  min: depart_origin_min,
																	  max: depart_origin_max,
																	  values: [ depart_origin_min, depart_origin_max ],
																	  slide: function( event, ui ) {
																			$( "#amount_depart_origin" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
																			depart_origin_min = parseInt(ui.values[0]);
																			depart_origin_max = parseInt(ui.values[1]);
																			$('.time_filter').each(function(){
																				depart_origin = parseInt($(this).attr('depart_origin'));
																				if(depart_origin_min <= depart_origin && depart_origin <= depart_origin_max){
																					if($(this).hasClass('arrive_destination_hidden') || $(this).hasClass('depart_destination_hidden') || $(this).hasClass('arrive_origin_hidden') || $(this).hasClass('airline_hidden') || $(this).hasClass('stops_hidden')){
																						$(this).removeClass('depart_origin_hidden');
																						
																					}
																					else{
																						$(this).removeClass('depart_origin_hidden').fadeIn();
																					}
																				}
																				else{
																					$(this).addClass('depart_origin_hidden').fadeOut();
																				}
																			});
																			
																	  }
																 });
																 $("#amount_depart_origin").val($("#slider_range_depart_origin").slider("values", 0)+":00 - " + $("#slider_range_depart_origin").slider("values", 1)+":00");															  
														  }
														  else if(i > 0){
															  departure_origin_time_splitted = (frontend_array[i].departure_origin_time).split(':');
															  if(parseInt(departure_origin_time_splitted[0]) < depart_origin_min){
																	 
																	 depart_origin_min = parseInt(departure_origin_time_splitted[0]);
																    //alert('Min is '+depart_origin_min+'<br>Max is '+depart_origin_max);
																 
																	 $("#slider_range_depart_origin").slider({
																		  range: true,
																		  min: depart_origin_min,
																		  max: depart_origin_max,
																		  values: [ depart_origin_min, depart_origin_max ],
																		  slide: function( event, ui ) {
																				$( "#amount_depart_origin" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
																				depart_origin_min = parseInt(ui.values[0]);
																				depart_origin_max = parseInt(ui.values[1]);
																				$('.time_filter').each(function(){
																					depart_origin = parseInt($(this).attr('depart_origin'));
																					if(depart_origin_min <= depart_origin && depart_origin <= depart_origin_max){
																						if($(this).hasClass('arrive_destination_hidden') || $(this).hasClass('depart_destination_hidden') || $(this).hasClass('arrive_origin_hidden') || $(this).hasClass('airline_hidden') || $(this).hasClass('stops_hidden')){
																							$(this).removeClass('depart_origin_hidden');
																							
																						}
																						else{
																							$(this).removeClass('depart_origin_hidden').fadeIn();
																						}
																					}
																					else{
																						//alert(depart_origin);
																						$(this).addClass('depart_origin_hidden').fadeOut();
																					}
																				});																				
																		  }
																	 });
																	 $("#amount_depart_origin").val($("#slider_range_depart_origin").slider("values", 0)+":00 - " + $("#slider_range_depart_origin").slider("values", 1)+":00");																  
															  }
															  if(parseInt(departure_origin_time_splitted[0]) > depart_origin_max){
																	 
																	 depart_origin_max = parseInt(departure_origin_time_splitted[0]);
																	 //alert('Max is '+depart_origin_max);
																	 $("#slider_range_depart_origin").slider({
																		  range: true,
																		  min: depart_origin_min,
																		  max: depart_origin_max,
																		  values: [ depart_origin_min, depart_origin_max ],
																		  slide: function( event, ui ) {
																				$( "#amount_depart_origin" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
																				depart_origin_min = parseInt(ui.values[0]);
																				depart_origin_max = parseInt(ui.values[1]);
																				$('.time_filter').each(function(){
																					depart_origin = parseInt($(this).attr('depart_origin'));
																					if(depart_origin_min <= depart_origin && depart_origin <= depart_origin_max){
																						if($(this).hasClass('arrive_destination_hidden') || $(this).hasClass('depart_destination_hidden') || $(this).hasClass('arrive_origin_hidden') || $(this).hasClass('airline_hidden') || $(this).hasClass('stops_hidden')){
																							$(this).removeClass('depart_origin_hidden');
																							
																						}
																						else{
																							$(this).removeClass('depart_origin_hidden').fadeIn();
																						}
																					}
																					else{
																						$(this).addClass('depart_origin_hidden').fadeOut();
																					}
																				});																				
																		  }
																	 });
																	 $("#amount_depart_origin").val($("#slider_range_depart_origin").slider("values", 0)+":00 - " + $("#slider_range_depart_origin").slider("values", 1)+":00");																  
															  }
														  
														  }
														  
														  $('#'+frontend_array[i].id).attr('depart_origin',parseInt(departure_origin_time_splitted[0]));
														  
														  
														  // Arrive Destination Slider
														  //-----------------------------------
														  if(i == 0){
																 arrival_destination_time_splitted = (frontend_array[i].arrival_destination_time).split(':');
															    arrive_destination_min = parseInt(arrival_destination_time_splitted[0]);
															    arrive_destination_max = parseInt(arrival_destination_time_splitted[0]);
															    //alert('Min is '+arrive_destination_min+'<br>Max is '+arrive_destination_max);
																 $("#slider_range_arrive_destination").slider({
																	  range: true,
																	  min: arrive_destination_min,
																	  max: arrive_destination_max,
																	  values: [ arrive_destination_min, arrive_destination_max ],
																	  slide: function( event, ui ) {
																			$( "#amount_arrive_destination" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
																			arrive_destination_min = parseInt(ui.values[0]);
																			arrive_destination_max = parseInt(ui.values[1]);
																			$('.time_filter').each(function(){
																				arrive_destination = parseInt($(this).attr('arrive_destination'));
																				if(arrive_destination_min <= arrive_destination && arrive_destination <= arrive_destination_max){
																					if($(this).hasClass('depart_origin_hidden') || $(this).hasClass('depart_destination_hidden') || $(this).hasClass('arrive_origin_hidden') || $(this).hasClass('airline_hidden') || $(this).hasClass('stops_hidden')){
																						$(this).removeClass('arrive_destination_hidden');
																						
																					}
																					else{
																						$(this).removeClass('arrive_destination_hidden').fadeIn();
																					}
																				}
																				else{
																					$(this).addClass('arrive_destination_hidden').fadeOut();
																				}
																			});																			
																	  }
																 });
																 $("#amount_arrive_destination").val($("#slider_range_arrive_destination").slider("values", 0)+":00 - " + $("#slider_range_arrive_destination").slider("values", 1)+":00");															  
														  }
														  else if(i > 0){
															  arrival_destination_time_splitted = (frontend_array[i].arrival_destination_time).split(':');
															  if(parseInt(arrival_destination_time_splitted[0]) < arrive_destination_min){
																	 
																	 arrive_destination_min = parseInt(arrival_destination_time_splitted[0]);
																    //alert('Min is '+arrive_destination_min+'<br>Max is '+arrive_destination_max);
																 
																	 $("#slider_range_arrive_destination").slider({
																		  range: true,
																		  min: arrive_destination_min,
																		  max: arrive_destination_max,
																		  values: [ arrive_destination_min, arrive_destination_max ],
																		  slide: function( event, ui ) {
																				$( "#amount_arrive_destination" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
																				arrive_destination_min = parseInt(ui.values[0]);
																				arrive_destination_max = parseInt(ui.values[1]);
																				$('.time_filter').each(function(){
																					arrive_destination = parseInt($(this).attr('arrive_destination'));
																					if(arrive_destination_min <= arrive_destination && arrive_destination <= arrive_destination_max){
																						if($(this).hasClass('depart_origin_hidden') || $(this).hasClass('depart_destination_hidden') || $(this).hasClass('arrive_origin_hidden') || $(this).hasClass('airline_hidden') || $(this).hasClass('stops_hidden')){
																							$(this).removeClass('arrive_destination_hidden');
																							
																						}
																						else{
																							$(this).removeClass('arrive_destination_hidden').fadeIn();
																						}
																					}
																					else{
																						$(this).addClass('arrive_destination_hidden').fadeOut();
																					}
																				});																					
																		  }
																	 });
																	 $("#amount_arrive_destination").val($("#slider_range_arrive_destination").slider("values", 0)+":00 - " + $("#slider_range_arrive_destination").slider("values", 1)+":00");																  
															  }
															  if(parseInt(arrival_destination_time_splitted[0]) > arrive_destination_max){
																	 
																	 arrive_destination_max = parseInt(arrival_destination_time_splitted[0]);
																	 //alert('Max is '+arrive_destination_max);
																	 $("#slider_range_arrive_destination").slider({
																		  range: true,
																		  min: arrive_destination_min,
																		  max: arrive_destination_max,
																		  values: [ arrive_destination_min, arrive_destination_max ],
																		  slide: function( event, ui ) {
																				$( "#amount_arrive_destination" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
																				arrive_destination_min = parseInt(ui.values[0]);
																				arrive_destination_max = parseInt(ui.values[1]);
																				$('.time_filter').each(function(){
																					arrive_destination = parseInt($(this).attr('arrive_destination'));
																					if(arrive_destination_min <= arrive_destination && arrive_destination <= arrive_destination_max){
																						if($(this).hasClass('depart_origin_hidden') || $(this).hasClass('depart_destination_hidden') || $(this).hasClass('arrive_origin_hidden') || $(this).hasClass('airline_hidden') || $(this).hasClass('stops_hidden')){
																							$(this).removeClass('arrive_destination_hidden');
																							
																						}
																						else{
																							$(this).removeClass('arrive_destination_hidden').fadeIn();
																						}
																					}
																					else{
																						$(this).addClass('arrive_destination_hidden').fadeOut();
																					}
																				});																				
																		  }
																	 });
																	 $("#amount_arrive_destination").val($("#slider_range_arrive_destination").slider("values", 0)+":00 - " + $("#slider_range_arrive_destination").slider("values", 1)+":00");																  
															  }
														  
														  }
														  
														  $('#'+frontend_array[i].id).attr('arrive_destination',parseInt(arrival_destination_time_splitted[0]));														  
														  
														  // Depart Destination Slider
														  //--------------------------------------
														  if(i == 0){
																 departure_destination_time_splitted = (frontend_array[i].departure_destination_time).split(':');
															    depart_destination_min = parseInt(departure_destination_time_splitted[0]);
															    depart_destination_max = parseInt(departure_destination_time_splitted[0]);
															    //alert('Min is '+depart_destination_min+'<br>Max is '+depart_destination_max);
																 $("#slider_range_depart_destination").slider({
																	  range: true,
																	  min: depart_destination_min,
																	  max: depart_destination_max,
																	  values: [ depart_destination_min, depart_destination_max ],
																	  slide: function( event, ui ) {
																			$( "#amount_depart_destination" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
																			depart_destination_min = parseInt(ui.values[0]);
																			depart_destination_max = parseInt(ui.values[1]);
																			$('.time_filter').each(function(){
																				depart_destination = parseInt($(this).attr('depart_destination'));
																				if(depart_destination_min <= depart_destination && depart_destination <= depart_destination_max){
																					if($(this).hasClass('depart_origin_hidden') || $(this).hasClass('arrive_destination_hidden') || $(this).hasClass('arrive_origin_hidden') || $(this).hasClass('airline_hidden') || $(this).hasClass('stops_hidden')){
																						$(this).removeClass('depart_destination_hidden');
																						
																					}
																					else{
																						$(this).removeClass('depart_destination_hidden').fadeIn();
																					}
																				}
																				else{
																					$(this).addClass('depart_destination_hidden').fadeOut();
																				}
																			});																			
																	  }
																 });
																 $("#amount_depart_destination").val($("#slider_range_depart_destination").slider("values", 0)+":00 - " + $("#slider_range_depart_destination").slider("values", 1)+":00");															  
														  }
														  else if(i > 0){
															  departure_destination_time_splitted = (frontend_array[i].departure_destination_time).split(':');
															  if(parseInt(departure_destination_time_splitted[0]) < depart_destination_min){
																	 
																	 depart_destination_min = parseInt(departure_destination_time_splitted[0]);
																    //alert('Min is '+depart_destination_min+'<br>Max is '+depart_destination_max);
																 
																	 $("#slider_range_depart_destination").slider({
																		  range: true,
																		  min: depart_destination_min,
																		  max: depart_destination_max,
																		  values: [ depart_destination_min, depart_destination_max ],
																		  slide: function( event, ui ) {
																				$( "#amount_depart_destination" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
																				depart_destination_min = parseInt(ui.values[0]);
																				depart_destination_max = parseInt(ui.values[1]);
																				$('.time_filter').each(function(){
																					depart_destination = parseInt($(this).attr('depart_destination'));
																					if(depart_destination_min <= depart_destination && depart_destination <= depart_destination_max){
																						if($(this).hasClass('depart_origin_hidden') || $(this).hasClass('arrive_destination_hidden') || $(this).hasClass('arrive_origin_hidden') || $(this).hasClass('airline_hidden') || $(this).hasClass('stops_hidden')){
																							$(this).removeClass('depart_destination_hidden');
																							
																						}
																						else{
																							$(this).removeClass('depart_destination_hidden').fadeIn();
																						}
																					}
																					else{
																						$(this).addClass('depart_destination_hidden').fadeOut();
																					}
																				});																				
																				
																		  }
																	 });
																	 $("#amount_depart_destination").val($("#slider_range_depart_destination").slider("values", 0)+":00 - " + $("#slider_range_depart_destination").slider("values", 1)+":00");																  
															  }
															  if(parseInt(departure_destination_time_splitted[0]) > depart_destination_max){
																	 
																	 depart_destination_max = parseInt(departure_destination_time_splitted[0]);
																	 //alert('Max is '+depart_destination_max);
																	 $("#slider_range_depart_destination").slider({
																		  range: true,
																		  min: depart_destination_min,
																		  max: depart_destination_max,
																		  values: [ depart_destination_min, depart_destination_max ],
																		  slide: function( event, ui ) {
																				$( "#amount_depart_destination" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
																				depart_destination_min = parseInt(ui.values[0]);
																				depart_destination_max = parseInt(ui.values[1]);
																				$('.time_filter').each(function(){
																					depart_destination = parseInt($(this).attr('depart_destination'));
																					if(depart_destination_min <= depart_destination && depart_destination <= depart_destination_max){
																						if($(this).hasClass('depart_origin_hidden') || $(this).hasClass('arrive_destination_hidden') || $(this).hasClass('arrive_origin_hidden') || $(this).hasClass('airline_hidden') || $(this).hasClass('stops_hidden')){
																							$(this).removeClass('depart_destination_hidden');
																							
																						}
																						else{
																							$(this).removeClass('depart_destination_hidden').fadeIn();
																						}
																					}
																					else{
																						$(this).addClass('depart_destination_hidden').fadeOut();
																					}
																				});																				
																		  }
																	 });
																	 $("#amount_depart_destination").val($("#slider_range_depart_destination").slider("values", 0)+":00 - " + $("#slider_range_depart_destination").slider("values", 1)+":00");																  
															  }
														  
														  }	
														  
														  $('#'+frontend_array[i].id).attr('depart_destination',parseInt(departure_destination_time_splitted[0]));													  
														  
														  // Arrive Origin Slider
														  //-----------------------------------
														  if(i == 0){
																 arrival_origin_time_splitted = (frontend_array[i].arrival_origin_time).split(':');
															    arrive_origin_min = parseInt(arrival_origin_time_splitted[0]);
															    arrive_origin_max = parseInt(arrival_origin_time_splitted[0]);
															    //alert('Min is '+arrive_origin_min+'<br>Max is '+arrive_origin_max);
																 $("#slider_range_arrive_origin").slider({
																	  range: true,
																	  min: arrive_origin_min,
																	  max: arrive_origin_max,
																	  values: [ arrive_origin_min, arrive_origin_max ],
																	  slide: function( event, ui ) {
																			$( "#amount_arrive_origin" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
																			arrive_origin_min = parseInt(ui.values[0]);
																			arrive_origin_max = parseInt(ui.values[1]);
																			$('.time_filter').each(function(){
																				arrive_origin = parseInt($(this).attr('arrive_origin'));
																				if(arrive_origin_min <= arrive_origin && arrive_origin <= arrive_origin_max){
																					if($(this).hasClass('depart_origin_hidden') || $(this).hasClass('arrive_destination_hidden') || $(this).hasClass('depart_destination_hidden') || $(this).hasClass('airline_hidden') || $(this).hasClass('stops_hidden')){
																						$(this).removeClass('arrive_origin_hidden');
																						
																					}
																					else{
																						$(this).removeClass('arrive_origin_hidden').fadeIn();
																					}
																				}
																				else{
																					$(this).addClass('arrive_origin_hidden').fadeOut();
																				}
																			});																			
																	  }
																 });
																 $("#amount_arrive_origin").val($("#slider_range_arrive_origin").slider("values", 0)+":00 - " + $("#slider_range_arrive_origin").slider("values", 1)+":00");															  
														  }
														  else if(i > 0){
															  arrival_origin_time_splitted = (frontend_array[i].arrival_origin_time).split(':');
															  if(parseInt(arrival_origin_time_splitted[0]) < arrive_origin_min){
																	 
																	 arrive_origin_min = parseInt(arrival_origin_time_splitted[0]);
																    //alert('Min is '+arrive_origin_min+'<br>Max is '+arrive_origin_max);
																 
																	 $("#slider_range_arrive_origin").slider({
																		  range: true,
																		  min: arrive_origin_min,
																		  max: arrive_origin_max,
																		  values: [ arrive_origin_min, arrive_origin_max ],
																		  slide: function( event, ui ) {
																				$( "#amount_arrive_origin" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
																				arrive_origin_min = parseInt(ui.values[0]);
																				arrive_origin_max = parseInt(ui.values[1]);
																				$('.time_filter').each(function(){
																					arrive_origin = parseInt($(this).attr('arrive_origin'));
																					if(arrive_origin_min <= arrive_origin && arrive_origin <= arrive_origin_max){
																						if($(this).hasClass('depart_origin_hidden') || $(this).hasClass('arrive_destination_hidden') || $(this).hasClass('depart_destination_hidden') || $(this).hasClass('airline_hidden') || $(this).hasClass('stops_hidden')){
																							$(this).removeClass('arrive_origin_hidden');
																							
																						}
																						else{
																							$(this).removeClass('arrive_origin_hidden').fadeIn();
																						}
																					}
																					else{
																						$(this).addClass('arrive_origin_hidden').fadeOut();
																					}
																				});																					
																		  }
																	 });
																	 $("#amount_arrive_origin").val($("#slider_range_arrive_origin").slider("values", 0)+":00 - " + $("#slider_range_arrive_origin").slider("values", 1)+":00");																  
															  }
															  if(parseInt(arrival_origin_time_splitted[0]) > arrive_origin_max){
																	 
																	 arrive_origin_max = parseInt(arrival_origin_time_splitted[0]);
																	 //alert('Max is '+arrive_origin_max);
																	 $("#slider_range_arrive_origin").slider({
																		  range: true,
																		  min: arrive_origin_min,
																		  max: arrive_origin_max,
																		  values: [ arrive_origin_min, arrive_origin_max ],
																		  slide: function( event, ui ) {
																				$( "#amount_arrive_origin" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
																				arrive_origin_min = parseInt(ui.values[0]);
																				arrive_origin_max = parseInt(ui.values[1]);
																				$('.time_filter').each(function(){
																					arrive_origin = parseInt($(this).attr('arrive_origin'));
																					if(arrive_origin_min <= arrive_origin && arrive_origin <= arrive_origin_max){
																						if($(this).hasClass('depart_origin_hidden') || $(this).hasClass('arrive_destination_hidden') || $(this).hasClass('depart_destination_hidden') || $(this).hasClass('airline_hidden') || $(this).hasClass('stops_hidden')){
																							$(this).removeClass('arrive_origin_hidden');
																							
																						}
																						else{
																							$(this).removeClass('arrive_origin_hidden').fadeIn();
																						}
																					}
																					else{
																						$(this).addClass('arrive_origin_hidden').fadeOut();
																					}
																				});																					
																		  }
																	 });
																	 $("#amount_arrive_origin").val($("#slider_range_arrive_origin").slider("values", 0)+":00 - " + $("#slider_range_arrive_origin").slider("values", 1)+":00");																  
															  }
														  
														  }	
														  
														  $('#'+frontend_array[i].id).attr('arrive_origin',parseInt(arrival_origin_time_splitted[0]));													  
														  
														  
														  //$('#chorni').last().attr('id',frontend_array[i].id);
														  
														  // Before 01082017 Price Schema
														  //--------------------------------
														  //$('#'+frontend_array[i].id+' .gokuest_price').text(frontend_array[i].price > 0 ? addCommas(frontend_array[i].price) + ' Naira' : 'Not Available');
														  //$('#'+frontend_array[i].id+' .travelbeta_price').text(frontend_array[i].travelbeta_price > 0 ? addCommas(frontend_array[i].travelbeta_price) + ' Naira' : 'Not Available');
														  //$('#'+frontend_array[i].id+' .travelden_price').text(frontend_array[i].travelden_price > 0 ? addCommas(frontend_array[i].travelden_price) + ' Naira' : 'Not Available');
														  //$('#'+frontend_array[i].id+' .wakanow_price').text(frontend_array[i].wakanow_price > 0 ? addCommas(frontend_array[i].wakanow_price) + ' Naira' : 'Not Available');
														  
														  // After 01082017 Price Schema
														  //--------------------------------
														  // Gokuest Price
														  if(frontend_array[i].sabre_price > 0){
															  $('#'+frontend_array[i].id+' .gokuest_price').text(addCommas(frontend_array[i].sabre_price) + ' Naira');														  
														  }
														  else{
															  $('#'+frontend_array[i].id+' .gokuest_father').hide();
															  $('#'+frontend_array[i].id+' .gokuest_price').text('Not Available');	
														  }
														  
														  
														  // Travelpaddy Price
														  if(frontend_array[i].price > 0){
															  $('#'+frontend_array[i].id+' .travelpaddy_price').text(addCommas(frontend_array[i].price) + ' Naira');														  
														  }
														  else{
															  $('#'+frontend_array[i].id+' .travelpaddy_father').hide();
														  }														  
														  
														  // Travelbeta Price
														  if(frontend_array[i].travelbeta_price > 0){
															  $('#'+frontend_array[i].id+' .travelbeta_price').text(addCommas(frontend_array[i].travelbeta_price) + ' Naira');														  
														  }
														  else{
															  $('#'+frontend_array[i].id+' .travelbeta_father').hide();
														  }
														  
														  
														  // Travelden Price
														  if(frontend_array[i].travelden_price > 0){
															  $('#'+frontend_array[i].id+' .travelden_price').text(addCommas(frontend_array[i].travelden_price) + ' Naira');														  
														  }
														  else{
															  $('#'+frontend_array[i].id+' .travelden_father').hide();
														  }
														  
														  
														  // Wakanow Price
														  if(frontend_array[i].wakanow_price > 0){
															  $('#'+frontend_array[i].id+' .wakanow_price').text(addCommas(frontend_array[i].wakanow_price) + ' Naira');														  
														  }
														  else{
															  $('#'+frontend_array[i].id+' .wakanow_father').hide();
														  }
														  
														  														  
														  													  
														  $('#'+frontend_array[i].id+' .aircompany').text(frontend_array[i].aircompany);
														  
														  
														  $('#'+frontend_array[i].id).attr('airline_name',(frontend_array[i].aircompany).replace(/ /gi,"_"));
														  
														  $('#'+frontend_array[i].id).attr('stops',frontend_array[i].stops);
														  
														  
														  
														  
														  // Start Of Ailines Filter List
														  // ---------------------------------
														  
														  if(airlines_filter_list.length == 0){
															   airlines_filter_list.push(frontend_array[i].aircompany);
															   //alert(airlines_filter_list.length);
														  }
														  else{
																if(jQuery.inArray(frontend_array[i].aircompany, airlines_filter_list) != -1){
																
																}
																else{
																	airlines_filter_list.push(frontend_array[i].aircompany);
																	//alert(airlines_filter_list.length);
																}
														  
														  }
														  
														  // End Of Airlines Filter List
														  // --------------------------------


														  // Start Of Stops Filter List
														  // ---------------------------------
														  
														  if(stops_filter_list.length == 0){
															   stops_filter_list.push(frontend_array[i].stops);
															   //alert(stops_filter_list.length);
														  }
														  else{
																if(jQuery.inArray(frontend_array[i].stops, stops_filter_list) != -1){
																
																}
																else{
																	stops_filter_list.push(frontend_array[i].stops);
																	//alert(stops_filter_list.length);
																}
														  
														  }
														  
														  // End Of Stops Filter List
														  // --------------------------------
														  
														  														  
														  
														  $('#'+frontend_array[i].id+' .media-object').attr('src','images/airlines_logos/'+frontend_array[i].company_logo+'.gif');
																												 
														  
														  $('#'+frontend_array[i].id+' .media-object').load('images/airlines_logos/'+frontend_array[i].company_logo+'.gif', function(response, status, xhr) {
																 if (status == "error"){ 
																	  $(this).attr('src', 'images/airlines_logos/no-image-icon-23.jpg');
																}
																 else{
																	  //$('#'+frontend_array[i].id+' .media-object').attr('src', 'images/airlines_logos/'+frontend_array[i].company_logo+'.gif');
																 }
																 });
																

														  $('#'+frontend_array[i].id+' .from_code').text(frontend_array[i].from_code);
														  $('#'+frontend_array[i].id+' .to_code').text(frontend_array[i].to_code);
														  $('#'+frontend_array[i].id+' .departure_origin_time').text(frontend_array[i].departure_origin_time);
														  $('#'+frontend_array[i].id+' .arrival_destination_time').text(frontend_array[i].arrival_destination_time);
														  $('#'+frontend_array[i].id+' .arrival_origin_time').text(frontend_array[i].arrival_origin_time);
														  $('#'+frontend_array[i].id+' .departure_destination_time').text(frontend_array[i].departure_destination_time);
														  
														  $('#'+frontend_array[i].id+' .common-flightsh').attr('href','#collapse'+frontend_array[i].id);
														  $('#'+frontend_array[i].id+' .collapse').attr('id','collapse'+frontend_array[i].id);
												
													}
													
													// Create Ailines Filter List
													// --------------------------------------
													airlines_filter_list.sort();
													//alert(airlines_filter_list.length);
													$('.airline_hide').remove();
													
													airlines_filter_list.forEach(function(entry){
														if(entry != undefined){
															airline_id = entry.replace(/ /gi,"_");
														}
														$('.airline_sample').clone(true).removeClass('airline_sample').addClass('airline_hide').attr('id',airline_id).css('display','block').appendTo('#airlines_list');
														$('#'+airline_id+' .airline_chekbox').attr('value',0);
														$('#'+airline_id+' .airline_name').text(entry);

													});

													
													// Create Stops Filter List
													// --------------------------------------
													stops_filter_list.sort();
													//alert(stops_filter_list.length);
													$('.stop_hide').remove();
													
													stops_filter_list.forEach(function(entry){
														if(entry != null){
															stop_id = entry;
														
															//alert(stop_id);
															$('.stop_sample').clone(true).removeClass('stop_sample').addClass('stop_hide').attr('id',stop_id).css('display','block').appendTo('#stops_list');
															$('#'+stop_id+' .stop_chekbox').attr('value',0);
															$('#'+stop_id+' .stop_name').text(entry);
														}

													});
													
																									 
											});
									  }
									}
							  });
							  
                    }
						}
						else{
							$('#loader').fadeOut('slow', function(){
								$('#search_values_response').slideDown('slow').addClass('opened');    
							});
						}
        }    
    
        $(window).load( function(){
           // alert("hi");
            // On Load
            //AjaxWithSearchParams();
            
        });
        $(document).ready( function(){				
            $('#flight_template_father').hide();
            //$('#search_values_response').slideUp();
            
            // Check if user is refered for search from another  page
            is_user_refered = <?php echo $is_user_refered; ?>;
            
            // If user is refered for search from another page, we make  search
            if(is_user_refered == 1){
            setTimeout(function(){
					$('#loader').fadeIn('slow', function(){
						AjaxWithSearchParams();
					});
				}, 1001);
            }

            // We send form data for processing
            //-------------------------------------          
            $('#submit').click(function(){
					AjaxWithSearchParams();
            return false;        
            });
            
            
            // Start Airlines Filter
            // ----------------------------
            $('.airline .airline_checkbox').bind('click');
            var airlines_filter_counter = 0;
            
            $('.airline .airline_checkbox').on('click',function(){
					var airline_value = $(this).attr('value');
					if(airline_value == '0'){
						$(this).attr('value','1');
						airlines_filter_counter++;
					}
					else if(airline_value == '1'){
						$(this).attr('value','0');
						airlines_filter_counter--;					
					}
					
					if(airlines_filter_counter == 0){
						$('.time_filter').each(function(){
							if($(this).hasClass('depart_origin_hidden') || $(this).hasClass('arrive_destination_hidden') || $(this).hasClass('depart_destination_hidden') || $(this).hasClass('arrive_origin_hidden') || $(this).hasClass('stops_hidden')){
								$(this).removeClass('airline_hidden');
							}
							else{
								$(this).removeClass('airline_hidden').fadeIn();
							}
						});
					}
					else if(airlines_filter_counter > 0){
						$('.airline').each(function(){
							var airline_filter_id = $(this).attr('id');
							var airline_filter_value = $(this).find('.airline_checkbox').attr('value');
												
							$('.time_filter').each(function(){
								airline_name = $(this).attr('airline_name');
								
								if(airline_filter_id == airline_name && airline_filter_value == 1){	
								
									if($(this).hasClass('depart_origin_hidden') || $(this).hasClass('arrive_destination_hidden') || $(this).hasClass('depart_destination_hidden') || $(this).hasClass('arrive_origin_hidden') || $(this).hasClass('stops_hidden')){
										$(this).removeClass('airline_hidden');
									}
									else{
										$(this).removeClass('airline_hidden').fadeIn();
									}
																
								}
								else if(airline_filter_id == airline_name && airline_filter_value == 0){
									$(this).addClass('airline_hidden').fadeOut();
								}
								
							});
					
						});
					}

            
            });
            
            // End Airlines Filter
            // ----------------------------
            

            // Start Stops Filter
            // ----------------------------
            $('.stop .stop_checkbox').bind('click');
            var stops_filter_counter = 0;
            
            $('.stop .stop_checkbox').on('click',function(){
					var stop_value = $(this).attr('value');
					if(stop_value == '0'){
						$(this).attr('value','1');
						stops_filter_counter++;
					}
					else if(stop_value == '1'){
						$(this).attr('value','0');
						stops_filter_counter--;					
					}
					
					if(stops_filter_counter == 0){
						$('.time_filter').each(function(){
							if($(this).hasClass('depart_origin_hidden') || $(this).hasClass('arrive_destination_hidden') || $(this).hasClass('depart_destination_hidden') || $(this).hasClass('arrive_origin_hidden') || $(this).hasClass('airline_hidden')){
								$(this).removeClass('stop_hidden');
							}
							else{
								$(this).removeClass('stop_hidden').fadeIn();
							}
						});
					}
					else if(stops_filter_counter > 0){
						$('.stop').each(function(){
							var stop_filter_id = $(this).attr('id');
							var stop_filter_value = $(this).find('.stop_checkbox').attr('value');
												
							$('.time_filter').each(function(){
								stops = $(this).attr('stops');
								
								if(stop_filter_id == stops && stop_filter_value == 1){	
								
									if($(this).hasClass('depart_origin_hidden') || $(this).hasClass('arrive_destination_hidden') || $(this).hasClass('depart_destination_hidden') || $(this).hasClass('arrive_origin_hidden') || $(this).hasClass('airline_hidden')){
										$(this).removeClass('stop_hidden');
									}
									else{
										$(this).removeClass('stop_hidden').fadeIn();
									}
																
								}
								else if(stop_filter_id == stops && stop_filter_value == 0){
									$(this).addClass('stop_hidden').fadeOut();
								}
								
							});
					
						});
					}

            
            });
            
            // End Stops Filter
            // ----------------------------
                    
        });        
    </script>  
</head>
<body>
<div id="outdated_reminder">
	<div>The price and seats information is outdated already, because your search result is more than 5 minutes old.<br>We recommend yo to make new search and get fresh flight information.</div>
	<div id="outdated_reminder_close">OK</div>
	</div>
<div id="loader"><img src="images/logo.png" alt="Gokuest-Logo">Loading...</div>
<nav class="navbar navbar-default navbar-fixed-top navbar-black">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbarCollapse" aria-expanded="false">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#" title="Gokuest">
          <img src="images/logo.png" alt="Gokuest-logo">
      </a>
    </div>
    <!-- Collect the nav links for toggling -->
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#" title="Flights"><i class="fa fa-plane" aria-hidden="true"></i> Flights</a></li>
        <li><a href="#" title="Hotels"><i class="fa fa-bed" aria-hidden="true"></i> Hotels</a></li>
        <li><a href="#" title="Cars"><i class="fa fa-car" aria-hidden="true"></i> Cars</a></li>
        <li><a href="#" title="Tours"><i class="fa fa-suitcase" aria-hidden="true"></i> Tours</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container -->
</nav>

<section class="searching-section">
    <div class="container searching-bx">
        <div class="row">
            <div class="col-sm-12">
              <div class="tab-content">
                <div role="tabpanel" class="tab-pane active in fade" id="home">
                    <div class="form-section">
             
                <form id="search_form" role="form" method="post" action="php/search.php">
                 <!-- form row 1 start --><div class="row">
                
						<input type="hidden" id="flights_system" name="flights_system" value="travelpaddy" />
						<input type="hidden" id="user_random_id" name="user_random_id" value="<?php echo $user_random_id ?>" />
						<input type="hidden" id="type_of_trip" name="type_of_trip" value="return" />
						
                  <div class="col-sm-4 col-md-2">
                    <div class="form-group tp-autocomplete form-input-bx">
                      <input value="<?php if(isset($_POST['from'])) echo $_POST['from']; ?>" type="text" class="form-control find-input my-input-from" id="from" name="from" placeholder="From" autocomplete="off" required>
                      <div id="search_response_from" class="from_to_suggestions"></div>
                    </div>
                  </div>
                  <div class="col-sm-4 col-md-2">
                    <div class="form-group tp-autocomplete form-input-bx">
                      <input value="<?php if(isset($_POST['to'])) echo $_POST['to']; ?>" type="text" class="form-control find-input find-input-line my-input-to" id="to" name="to" placeholder="To" autocomplete="off" required>
                      <div id="search_response_to" class="from_to_suggestions"></div>
                    </div>
                  </div>
                  <div class="col-sm-4 col-md-2">
                    <div class="form-group form-input-bx">
                      <div class="input-group find-input-group date" id="datepicker1">
                          <span class="input-group-addon">
                              <i class="fa fa-calendar-o"></i>
                          </span>
                        <input value="<?php if(isset($_POST['check_in'])) echo $_POST['check_in']; ?>" type="text" class="form-control find-input" id="check_in" name="check_in" placeholder="Check in" required>                          
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-4 col-md-2">
                    <div class="form-group form-input-bx">
                      <div class="input-group find-input-group date" id="datepicker2">
                          <span class="input-group-addon">
                              <i class="fa fa-calendar-o"></i>
                          </span>
                        <input value="<?php if(isset($_POST['check_out'])) echo $_POST['check_out']; ?>" type="text" class="form-control find-input" id="check_out" name="check_out" placeholder="Check out new" required>                          
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-4 col-md-2">
                    <div class="form-group form-input-bx">
                        <div class="cabin-wrapper">
                          <input value="<?php if(isset($_POST['TargetValSet'])) echo $_POST['TargetValSet']; ?>" type="text" class="form-control find-input find-input-line input-pass" placeholder="Passenger, Cabin" id="TargetValSet" name="TargetValSet">
                          <div class="cabin-design">
                                                    <div class="row">
                                                        <div class="col-xs-4 mt8">Cabin</div>
                                                        <div class="col-xs-8">
                                                            <select class="form-control" id="CabinSet">
																					 <option>Economy</option>
																					 <option>Premium</option>
                                                                <option>Business</option>
                                                                <option>First</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <!-- //adult -->
                                                    <div class="row mt10">
                                                        <div class="col-xs-4 mt5">Adult</div>
                                                        <div class="col-xs-5">
                                                            <div class="input-group input-group-sm">
                                                          <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button" data-counting="minus" data-person="Adult">
                                                                <span class="glyphicon glyphicon-minus"></span>
                                                            </button>
                                                          </span>
                                                          <input type="text" class="form-control adult-field" placeholder="0" data-choosen="Adult">
                                                          <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button" data-counting="plus" data-person="Adult">
                                                                <span class="glyphicon glyphicon-plus"></span>
                                                            </button>
                                                          </span>
                                                        </div>
                                                        </div>
                                                        <div class="col-xs-3 mt5">12+</div>
                                                    </div>
                                                    <!-- //child -->
                                                    <div class="row mt10">
                                                        <div class="col-xs-4 mt5">Children</div>
                                                        <div class="col-xs-5">
                                                            <div class="input-group input-group-sm">
                                                          <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button" data-counting="minus" data-person="Children">
                                                                <span class="glyphicon glyphicon-minus"></span>
                                                            </button>
                                                          </span>
                                                          <input type="text" class="form-control children-field" placeholder="0" data-choosen="Children">
                                                          <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button" data-counting="plus" data-person="Children">
                                                                <span class="glyphicon glyphicon-plus"></span>
                                                            </button>
                                                          </span>
                                                        </div>
                                                        </div>
                                                        <div class="col-xs-3 mt5">2-11</div>
                                                    </div>
                                                    <!-- //infant -->
                                                    <div class="row mt10">
                                                        <div class="col-xs-4 mt5">Infant</div>
                                                        <div class="col-xs-5">
                                                            <div class="input-group input-group-sm">
                                                          <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button" data-counting="minus" data-person="Infant">
                                                                <span class="glyphicon glyphicon-minus"></span>
                                                            </button>
                                                          </span>
                                                          <input type="text" class="form-control infant-field" placeholder="0" data-choosen="Infant">
                                                          <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button" data-counting="plus" data-person="Infant">
                                                                <span class="glyphicon glyphicon-plus"></span>
                                                            </button>
                                                          </span>
                                                        </div>
                                                        </div>
                                                        <div class="col-xs-3 mt5">&#60;2</div>
                                                    </div>
                                                </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-4 col-md-2">
                    <button id="submit" type="submit" class="btn btn-block btn-field-search">
                        Search</button>
                  </div>

                  </div><!-- form row 1 end -->

                  <!-- form row 2 start -->
                  <div class="row">
                  	

                  </div><!-- form row 1 start -->
                </form>
              
              <div id="search_values_response">You have to fill all fields above before search!</div>
            </div>         
                </div>
              </div>              
            </div>
        </div>
    </div>
</section>

<section class="padding-tb20">
    <!--<div class="container container-1300">-->
    <div class="container">
        <div class="row">
            <!-- //Left Section -->
            <div class="col-sm-3 col-md-2 mt20">
                <h2 class="bar-heading bar-heading-theme">Create Fare Alerts</h2>

                <div class="filter-sidebar">

                
                <h3 class="bar-heading2">Flight Time</h3>
                <ul class="ul-slider">
                    <li>
                        <h5>
                            Depart <span id="depart_origin">Origin</span>
                            <input type="text" class="time-setter" id="amount_depart_origin" readonly>
                        </h5>
                        <div id="slider_range_depart_origin"></div>
                    </li>
                    <li>
                        <h5>
                            Arrive <span id="arrive_destination">Destination</span>
                            <input type="text" class="time-setter" id="amount_arrive_destination" readonly>
                        </h5>
                        <div id="slider_range_arrive_destination"></div>
                    </li>
                    <li>
                        <h5>
                            Depart <span id="depart_destination">Destination</span>
                            <input type="text" class="time-setter" id="amount_depart_destination" readonly>
                        </h5>
                        <div id="slider_range_depart_destination"></div>
                    </li>
                    <li>
                        <h5>
                            Arrive <span id="arrive_origin">Origin</span>
                            <input type="text" class="time-setter" id="amount_arrive_origin" readonly>
                        </h5>
                        <div id="slider_range_arrive_origin"></div>
                    </li>
                </ul>
             
                
<script>
/*slider 1*/
$( function() {
    $("#slider-range").slider({
        range: true,
        min: 0,
        max: 23,
        values: [ 0, 10 ],
        slide: function( event, ui ) {
            $( "#amount" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
        }
    });
    $("#amount").val($("#slider-range").slider("values", 0)+":00 - " + $("#slider-range").slider("values", 1)+":00");

/*
    $("#slider_range_depart_origin").slider({
        range: true,
        min: 0,
        max: 23,
        values: [ 0, 23 ],
        slide: function( event, ui ) {
            $( "#amount_depart_origin" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
        }
    });
    $("#amount_depart_origin").val($("#slider_range_depart_origin").slider("values", 0)+":00 - " + $("#slider_range_depart_origin").slider("values", 1)+":00");
*/    
                   
});

/*slider 2*/
$( function() {    
/*    
    $("#slider_range_arrive_destination").slider({
        range: true,
        min: 0,
        max: 23,
        values: [ 0, 23 ],
        slide: function( event, ui ) {
            $( "#amount_arrive_destination" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
        }
    });
    $("#amount_arrive_destination").val($("#slider_range_arrive_destination").slider("values", 0)+":00 - " + 				$("#slider_range_arrive_destination").slider("values", 1)+":00");
*/                    
});

/*slider 3*/
$( function() {
/*
    $("#slider_range_depart_destination").slider({
        range: true,
        min: 0,
        max: 23,
        values: [ 0, 23 ],
        slide: function( event, ui ) {
            $( "#amount_depart_destination" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
        }
    });
    $("#amount_depart_destination").val($("#slider_range_depart_destination").slider("values", 0)+":00 - " + $("#slider_range_depart_destination").slider("values", 1)+":00");
*/
});

/*slider 4*/
$( function() {    
/*    
    $("#slider_range_arrive_origin").slider({
        range: true,
        min: 0,
        max: 23,
        values: [ 0, 23 ],
        slide: function( event, ui ) {
            $( "#amount_arrive_origin" ).val(ui.values[0] + ":00 - " + ui.values[1]+':00');
        }
    });
    $("#amount_arrive_origin").val($("#slider_range_arrive_origin").slider("values", 0)+":00 - " + $("#slider_range_arrive_origin").slider("values", 1)+":00");  
*/                  
});
</script>

                <hr class="filter-sidebar-line">

                <h3 class="bar-heading2">Airline</h3>
                <ul class="ul-checkbox" id="airlines_list">
                    <li class="airline airline_sample" style="display:none;">
                        <label class="checkbox-design">
                            <input type="checkbox" name="" class="airline_checkbox" value="0">
                            <span class="check-tick"></span>
                            <span class="airline_name"></span>
                        </label>
                    </li>             
						  <!--
                    <li>
                        <label class="checkbox-design">
                            <input type="checkbox" name="">
                            <span class="check-tick"></span>
                            Qatar Airways
                        </label>
                    </li>
                    <li>
                        <label class="checkbox-design">
                            <input type="checkbox" name="">
                            <span class="check-tick"></span>
                            Withad Airways
                        </label>
                    </li>
                    <li>
                        <label class="checkbox-design">
                            <input type="checkbox" name="">
                            <span class="check-tick"></span>
                            Emirates
                        </label>
                    </li>
                    <li>
                        <label class="checkbox-design">
                            <input type="checkbox" name="">
                            <span class="check-tick"></span>
                            Gulf Air
                        </label>
                    </li>
                    <li>
                        <label class="checkbox-design">
                            <input type="checkbox" name="">
                            <span class="check-tick"></span>
                            PIA
                        </label>
                    </li>
                    <li>
                        <label class="checkbox-design">
                            <input type="checkbox" name="">
                            <span class="check-tick"></span>
                            Turkish Airlines
                        </label>
                    </li>
                    <li>
                        <label class="checkbox-design">
                            <input type="checkbox" name="">
                            <span class="check-tick"></span>
                            Oman Airlines
                        </label>
                    </li>
                    -->
                </ul>

                <hr class="filter-sidebar-line">

                <h3 class="bar-heading2">Stops</h3>
                <ul class="ul-checkbox" id="stops_list">
                    <li class="stop stop_sample" style="display:none;">
                        <label class="checkbox-design">
                            <input type="checkbox" name="stop" class="stop_checkbox" value="0">
                            <span class="check-tick"></span>
                            <span class="stop_name"></span>
                        </label>
                    </li>                
						  <!--
                    <li>
                        <label class="checkbox-design">
                            <input type="radio" name="stop">
                            <span class="check-tick"></span>
                            Non-Stop
                        </label>
                    </li>
                    <li>
                        <label class="checkbox-design">
                            <input type="radio" name="stop">
                            <span class="check-tick"></span>
                            One-Stop
                        </label>
                    </li>
                    <li>
                        <label class="checkbox-design">
                            <input type="radio" name="stop">
                            <span class="check-tick"></span>
                            Two-Stop
                        </label>
                    </li>
                    -->
                </ul>




					 <!--
                <hr>


                <h3 class="bar-heading2">Cabins</h3>
                <ul class="ul-checkbox">
                    <li>
                        <label class="checkbox-design">
                            <input type="checkbox" name="">
                            <span class="check-tick"></span>
                            Economy
                        </label>
                    </li>
                    <li>
                        <label class="checkbox-design">
                            <input type="checkbox" name="">
                            <span class="check-tick"></span>
                            Premium Economy
                        </label>
                    </li>
                    <li>
                        <label class="checkbox-design">
                            <input type="checkbox" name="">
                            <span class="check-tick"></span>
                            Business
                        </label>
                    </li>
                </ul>
					 -->
					 
					 
                </div>
            </div><!-- //Left Section end -->
            <!-- //Middle Section -->
            <div class="col-sm-6 col-md-7 l1 mt20" id="chorni">
            <div class="row">
            	 <h2 class="bar-heading bar-heading-theme2">
                    Are you flexible?
                    <span class="pull-right">Yes Show Me! <i class="fa fa-download"></i></span>
                </h2>
            </div>

            <div class="row">
            <div class="feature-wrapper">
            	<div class="col-md-4 no-gutter">
            	<div class="feature-wrap feature-wrap1">
            		<h3>Cheaper</h3>
            		<p>1046 EUR</p>
            		<p>6hr 20min (Average)</p>
            		</div>
            	</div>

            	<div class="col-md-4 no-gutter">
            	<div class="feature-wrap feature-wrap2">
            		<h3>Quickest</h3>
            		<p>1046 EUR</p>
            		<p>6hr 20min (Average)</p>
            		</div>
            	</div>

            	<div class="col-md-4 no-gutter">
            	<div class="feature-wrap feature-wrap3">
            		<h3>Best</h3>
            		<p>1046 EUR</p>
            		<p>6hr 20min (Average)</p>
            		</div>
            	</div>
            	</div>
            </div>


               
                <div id="search_response"></div>
                
                <div id="flight_template_father" class="search_result">
                    <div class="" id="flight_template">
                        <div class="listing-offlight">
                            <div class="row">
                                <div class="col-lg-5">
                                    <table class="ft-price-table">
                                        <tr class="gokuest_father">
                                            <td><img src="images/logo.png"></td>
                                            <td><span class="gokuest_price">200,000 Naira</span></td>
                                        </tr>
                                        <tr class="travelpaddy_father">														 
														 <td><a href="https://travelpaddy.com"><img src="images/flights/travelpaddy.png"></a></td>
														 <td><a href="https://travelpaddy.com"><span class="travelpaddy_price">210,000 Naira</span></a></td>														 
                                        </tr>                                        
                                        <tr class="travelbeta_father">														                                         
                                           <td><a href="https://www.travelbeta.com/"><img src="images/flights/beta.png"></a></td>
                                           <td><a href="https://www.travelbeta.com/"><span class="travelbeta_price">210,000 Naira</span></a></td>														                                         </tr>
                                        
                                        <!--
                                        <tr>
                                            <td><img src="images/flights/travelstart.png"></td>
                                            <td><span class="travelstart_price">210,000 Naira</span></td>
                                        </tr>
                                        -->
                                        <tr class="travelden_father">												                                         
                                           <td><a href="https://travelden.com/"><img src="images/flights/travelden.png"></a></td>
                                           <td><a href="https://travelden.com/"><span class="travelden_price">215,000 Naira</span></a></td>														                                             
                                        </tr>
                                        <tr class="wakanow_father">														                                         
                                           <td><a href="https://www.wakanow.com/en-ng/"><img src="images/flights/now.png"></a></td>
                                           <td><a href="https://www.wakanow.com/en-ng/"><span class="wakanow_price">215,000 Naira</span></a></td>														                                             
                                        </tr>
                                    </table>
                                </div>
                                <div class="col-lg-7">
                                    <div class="media">
                                      <div class="media-left">
                                         <a href="#">
                                            <img class="media-object" src="images/airlines_logos/no-image-icon-23.jpg" alt="...">
                                         </a>
                                      </div>
                                      <div class="media-body">
                                         <h4 class="media-heading flt-heading"><span class="aircompany">Qatar Airways</span></h4>
                                         <table class="flights-timetable">
                                            <tr>
                                                <td><span class="fa fa-plane font18 fa-rotate-45"></span></td>
                                                <td><span class="departure_origin_time">06:10</span> <span class="from_code">ISB</span></td>
                                                <td><span class="arrival_destination_time">08:40</span> <span class="to_code">YYZ</span></td>
                                                <td>1 Stop(Doha)</td>
                                            </tr>
                                            <tr>
                                                <td><span class="fa fa-plane font18 fa-rotate-225"></span></td>
                                                <td><span class="departure_destination_time">06:10</span> <span class="to_code">ISB</span></td>
                                                <td><span class="arrival_origin_time">08:40</span> <span class="from_code">YYZ</span></td>
                                                <td>1 Stop(Doha)</td>
                                            </tr>
                                         </table>
                                      </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <h4>
                                                <span class="gokuest_price">225,000</span><br>
                                                GOKUEST
                                            </h4>
                                            <a href="#" class="btn btn-theme btn-flightbook">Book</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a class="common-flightsh" data-toggle="collapse" href="#collapse">
                                Show Flight Details</a>
                                
                     <!--popup code starts-->
                     
                                     <div class="row collapse flight_detail" id="collapse">
                            	<div class="close s_f  s_f_redirect_a3"></div>
                                <div class="col-sm-12 padding-tb20">
                                	<div class="row" style="margin-top: -37px;">
                                    	<div class="col-md-6 col-sm-6 col-xs-12">
                                        	<div class="outbound">outbound</div>
                                        	<div class="shaded">
                                            	<div class="header">
                                                	 <div class="pull-left place-name">
                                                        Lagos - London
                                                    </div>
                                                    <div class="pull-right flight-date">
                                                    	12 October, 2017
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>
                                            	<span class="segmentDate">Departs: <strong>Thursday</strong> 12. October 2017</span>
                                                
                                                <div class="segmentLeg clearfix">
                                                    <div class="legLeft">
                                                        <div class="legLocations">
                                                            <span class="legBigText ">Lagos</span> <span class="legSmallText ">Murtala Muhammad</span>
                                                            <span class="legBigText ">Doha</span> <span class="legSmallText ">Doha</span>
                                                        </div>
                                                        <div class="legTimes">
                                                            <span class="legBigText">17:00</span> <span class="legSmallText">Thursday</span> 
                                                            <span class="legBigText">19:00</span> <span class="legSmallText (undefined)">Thursday</span>
                                                        </div>
                                                        <div class="legIcons"><span class="sprite s_f s_f_popup_a1"></span><span class="sprite s_f s_f_popup_a1"></span></div>
                                                        <div class="legPath"><div class="legConnector"></div></div>
                                                    </div>
                                                    <div class="legFlight">
                                                        <div class="triBubble bubGrey">
                                                            <div class="clearfix">
                                                                <img src="https://cdn1.momondo.net/logos/airlines/pa-small.png" alt="airblue" class="legAirline">
                                                                <div class="legPlane"><span class="legBigText">PA205</span> <span class="legSmallText">airblue</span></div>
                                                                <div class="legFlightTime"><span class="legBigText">2h 00m</span></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                        <div class="segmentLeg stop transit clearfix">
                                                            <div class="legLeft">
                                                                <div class="legLocations">
                                                                </div>
                                                                <div class="legTimes">
                                                                </div>
                                                                <div class="legIcons">
                                                                </div>
                                                                <div class="legPath">
                                                                    <div class="legWait"></div>
                                                                </div>
                                                            </div>
                                                            <div class="legFlight">
                                                                <div class="triBubble bubRed">
                                                                    <div class="legWaitReason">
                                                                        <span class="legBigText">Change planes</span>
                                                                    </div>
                                                                    <div class="legWaitTime">
                                                                        <span class="legBigText">2h 00m</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                <div class="segmentLeg clearfix">
                                                    <div class="legLeft">
                                                        <div class="legLocations">
                                                            <span class="legBigText ">Lagos</span> <span class="legSmallText ">Murtala Muhammad</span>
                                                            <span class="legBigText ">Doha</span> <span class="legSmallText ">Doha</span>
                                                        </div>
                                                        <div class="legTimes">
                                                            <span class="legBigText">17:00</span> <span class="legSmallText">Thursday</span> 
                                                            <span class="legBigText">19:00</span> <span class="legSmallText (undefined)">Thursday</span>
                                                        </div>
                                                        <div class="legIcons"><span class="sprite s_f s_f_popup_a1"></span><span class="sprite s_f s_f_popup_a1"></span></div>
                                                        <div class="legPath"><div class="legConnector"></div></div>
                                                    </div>
                                                    <div class="legFlight">
                                                        <div class="triBubble bubGrey">
                                                            <div class="clearfix">
                                                                <img src="https://cdn1.momondo.net/logos/airlines/pa-small.png" alt="airblue" class="legAirline">
                                                                <div class="legPlane"><span class="legBigText">PA205</span> <span class="legSmallText">airblue</span></div>
                                                                <div class="legFlightTime"><span class="legBigText">2h 00m</span></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                              
												<span class="segmentDuration">Total flight time <strong>11h 15m</strong></span>
                                                <span class="segmentDate legWarning">Arrives: <strong>Friday</strong> 20. October 2017</span>
                                             </div>   

                                        </div>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                        	<div class="return">return</div>
                                        	<div class="shaded">
                                            	<div class="header">
                                                	 <div class="pull-left place-name">
                                                         London - Lagos
                                                    </div>
                                                    <div class="pull-right flight-date">
                                                    	19 October, 2017.
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>
                                            	<span class="segmentDate">Departs: <strong>Thursday</strong> 19 October, 2017</span>
                                                
                                                <div class="segmentLeg clearfix">
                                                    <div class="legLeft">
                                                        <div class="legLocations">
                                                            <span class="legBigText ">london</span> <span class="legSmallText ">Heathrow</span>
                                                            <span class="legBigText ">Doha</span> <span class="legSmallText ">Doha</span>
                                                        </div>
                                                        <div class="legTimes">
                                                            <span class="legBigText">17:00</span> <span class="legSmallText">Thursday</span> 
                                                            <span class="legBigText">19:00</span> <span class="legSmallText (undefined)">Thursday</span>
                                                        </div>
                                                        <div class="legIcons"><span class="sprite s_f s_f_popup_a1"></span><span class="sprite s_f s_f_popup_a1"></span></div>
                                                        <div class="legPath"><div class="legConnector"></div></div>
                                                    </div>
                                                    <div class="legFlight">
                                                        <div class="triBubble bubGrey">
                                                            <div class="clearfix">
                                                                <img src="https://cdn1.momondo.net/logos/airlines/pa-small.png" alt="airblue" class="legAirline">
                                                                <div class="legPlane"><span class="legBigText">PA205</span> <span class="legSmallText">airblue</span></div>
                                                                <div class="legFlightTime"><span class="legBigText">2h 00m</span></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                 <div class="segmentLeg stop transit clearfix">
                                                            <div class="legLeft">
                                                                <div class="legLocations">
                                                                </div>
                                                                <div class="legTimes">
                                                                </div>
                                                                <div class="legIcons">
                                                                </div>
                                                                <div class="legPath">
                                                                    <div class="legWait"></div>
                                                                </div>
                                                            </div>
                                                            <div class="legFlight">
                                                                <div class="triBubble bubRed">
                                                                    <div class="legWaitReason">
                                                                        <span class="legBigText">Change planes</span>
                                                                    </div>
                                                                    <div class="legWaitTime">
                                                                        <span class="legBigText">2h 00m</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                <div class="segmentLeg clearfix">
                                                    <div class="legLeft">
                                                        <div class="legLocations">
                                                            <span class="legBigText ">london</span> <span class="legSmallText ">Heathrow</span>
                                                            <span class="legBigText ">Doha</span> <span class="legSmallText ">Doha</span>
                                                        </div>
                                                        <div class="legTimes">
                                                            <span class="legBigText">17:00</span> <span class="legSmallText">Thursday</span> 
                                                            <span class="legBigText">19:00</span> <span class="legSmallText (undefined)">Thursday</span>
                                                        </div>
                                                        <div class="legIcons"><span class="sprite s_f s_f_popup_a1"></span><span class="sprite s_f s_f_popup_a1"></span></div>
                                                        <div class="legPath"><div class="legConnector"></div></div>
                                                    </div>
                                                    <div class="legFlight">
                                                        <div class="triBubble bubGrey">
                                                            <div class="clearfix">
                                                                <img src="https://cdn1.momondo.net/logos/airlines/pa-small.png" alt="airblue" class="legAirline">
                                                                <div class="legPlane"><span class="legBigText">PA205</span> <span class="legSmallText">airblue</span></div>
                                                                <div class="legFlightTime"><span class="legBigText">2h 00m</span></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <span class="segmentDuration">Total flight time <strong>11h 15m</strong></span>
                                                <span class="segmentDate legWarning">Arrives: <strong>Friday</strong> 20. October 2017</span>
                                             </div>   

                                        </div>
                                    </div>
                                    <div >
                                    
                                        
                                    </div>
                                </div>
                            </div>
                     <!--popup code ends-->

                            <div class="row collapse" id="collapse">
                                <div class="col-sm-12 padding-tb20">
                                    <div >
                                        <h3 class="flight-da-heading">Depart - Sat, Oct 15 <span class="pull-right">17h 35m</span></h3>
                                        <hr class="dotted-line">
                                        <p class="flight-da-para">
                                            10:45 - <span class="text-danger">6:15a Lands Sun, Oct 16</span>
                                            <span class="pull-right">Economy 6h 30m</span>
                                        </p>
                                        <p class="flight-da-para">
                                            Lagos (LOS) - Frankfurt am Main (FRA)
                                            <span class="text-success">5 seat remain</span>
                                        </p>
                                        <p class="flight-da-para text-muted">
                                            Lufthansa 5969 - Wide-body jet - Airbus A330-300
                                        </p>
                                        <hr class="dotted-line">
                                        <p class="flight-da-para">
                                            Change planes in Frankfurt <span class="text-warning">Long layover</span><span class="pull-right">9h 55m</span>
                                        </p>
                                        <p class="flight-da-para">
                                            4:10p - <span class="text-danger">5:20p</span> <span class="pull-right">Economy 1h 10m</span>
                                        </p>
                                        <p class="flight-da-para">
                                            Frankfurt am Main (FRA) - Paris (CDG) <span class="text-success">5 seat remain</span>
                                        </p>
                                        <p class="flight-da-para text-muted">
                                            Lufthansa 1040 - Narrow-body jet - Airbus A320
                                        </p>
                                        <hr class="dotted-line">
                                        <h3 class="flight-da-heading">Return - Wed, Nov 30 <span class="pull-right">22h 20m</span></h3>
                                        <hr class="dotted-line">
                                        <p class="flight-da-para">
                                            10:45 - <span class="text-danger">6:15a Lands Sun, Oct 16</span>
                                            <span class="pull-right">Economy 6h 30m</span>
                                        </p>
                                        <p class="flight-da-para">
                                            Lagos (LOS) - Frankfurt am Main (FRA)
                                            <span class="text-success">5 seat remain</span>
                                        </p>
                                        <p class="flight-da-para text-muted">
                                            Lufthansa 5969 - Wide-body jet - Airbus A330-300
                                        </p>
                                        <hr class="dotted-line">
                                        <p class="flight-da-para">
                                            Change planes in Frankfurt <span class="text-warning">Long layover</span><span class="pull-right">9h 55m</span>
                                        </p>
                                        <p class="flight-da-para">
                                            4:10p - <span class="text-danger">5:20p</span> <span class="pull-right">Economy 1h 10m</span>
                                        </p>
                                        <p class="flight-da-para">
                                            Frankfurt am Main (FRA) - Paris (CDG) <span class="text-success">5 seat remain</span>
                                        </p>
                                        <p class="flight-da-para text-muted">
                                            Lufthansa 1040 - Narrow-body jet - Airbus A320
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>




            </div><!-- // End Middle Section -->


            

            <!-- //Right Section -->
            <div class="col-sm-3 col-md-3 mt20">
                <iframe src="//a.impactradius-go.com/gen-ad-code/386395/208643/3435/" width="300" height="250" scrolling="no" frameborder="0" marginheight="0" marginwidth="0"></iframe>
                    <p>
                

                    </p>
                </div>
            
        </div>
                    <p>

                                        </p>
                </div>
            </div>
        </div>
    </div>
</section>


<footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4 col-lg-5">
                <ul>
                    <li><a href="#" title="About GoKuest">About GoKuest</a></li>
                    <li><a href="#" title="GoKuest on Mobile">GoKuest on Mobile</a></li>
                    <li><a href="#" title="Careers">Careers</a></li>
                </ul>
            </div>
            <div class="col-sm-4 col-lg-5">
                <ul>
                    <li><a href="#" title="FAQ">FAQ</a></li>
                    <li><a href="#" title="Hotel Operations">Hotel Operations</a></li>
                    <li><a href="#" title="Terms and Conditions">Terms and Conditions</a></li>
                </ul>
            </div>
            <div class="col-sm-4 col-lg-2">
                <ul>
                    <li><p>Country / Currency</p></li>
                </ul>
                <div class="footer-select">
                    <select>
                        <option>Negeria / Naira</option>
                        <option>England / Dollar</option>
                        <option>America / Dollar</option>
                    </select>
                </div>
            </div>
        </div>
        <!-- // -->
        <div class="row">
            <div class="col-sm-12">
                <h3>
                    Search cheap flights with GOKUEST. Find the cheapest airline tickets for all the top airlines around the world and the top international flight routes. We search travel sites to help you find and book the flight that suits you best.
                </h3>
                <div class="social-icons">
                    <h4>Socialize with us</h4>
                    <a href="#" title="Facebook" target="_blank"><span class="fa fa-facebook"></span></a>
                    <a href="#" title="Twitter" target="_blank"><span class="fa fa-twitter"></span></a>
                    <a href="#" title="Youtube" target="_blank"><span class="fa fa-youtube"></span></a>
                    <a href="#" title="Instagram" target="_blank"><span class="fa fa-instagram"></span></a>
                </div>
            </div>
        </div>
        <!-- // -->
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2">
                <hr>
                <h5>
                    GOKUEST is part of the Virgo group a market leader in Online travel and related services
                </h5>
            </div>
        </div>
    </div>
</footer>

<!-- //onclick then go to top on page -->
<a class="gototop" title="Go to top" href="#">
    <span class="fa fa-arrow-circle-up"></span>
</a>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/smoothscroll.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Datepicker -->
<script type="text/javascript" src="js/moment.js"></script>
<script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>

<!-- Range Slider -->
<script src="js/jquery-ui.js"></script>

<!-- Common JS -->
<script src="js/common.js"></script>
<script src='//vws.responsivevoice.com/v/e?key=NpSbzqUK'></script>
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/59b2b22fc28eca75e461ee9e/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();

$(document).ready(function(){
	$('.close').click(function(){
		$('.flight_detail').removeClass('in');
	});
});

</script>
</body>
</html>
