<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | ~E_NOTICE);
include_once 'workflow/Workflow.php';
include_once 'rest_activities/LeadPriceCalendarActivity.php';

$retFlightSegment = array();

$origin = 'LOS';//filter_input(INPUT_POST, "origin");
$destination = 'LIT';//filter_input(INPUT_POST, "destination");
$departureDate = '2018-03-24';//filter_input(INPUT_POST, "departureDate");
$returnDate = '2018-04-13';
$cabin = "Economy";
$adt = 2;
$children = 2;
$infant = 1;
$workflow = new Workflow(new LeadPriceCalendarActivity($origin, $destination, $departureDate, $cabin, $adt, $children, $infant, $returnDate));
$result = $workflow->runWorkflow();
$LeadPriceCalendar = $result->getResult("LeadPriceCalendar");
$data = $result->getResult("BargainFinderMax")->OTA_AirLowFareSearchRS->PricedItineraries->PricedItinerary;
echo "<pre>"; print_r($result);exit;

$retworkflow = new Workflow(new LeadPriceCalendarActivity($destination, $origin, $returnDate));
$retresult = $retworkflow->runWorkflow();
echo "<pre>"; print_r($retresult);exit;
$retLeadPriceCalendar = $retresult->getResult("LeadPriceCalendar");
if($retLeadPriceCalendar->status != 'NotProcessed'){
	$retdata = $retresult->getResult("BargainFinderMax")->OTA_AirLowFareSearchRS->PricedItineraries->PricedItinerary;
	if(count($retdata) > 0){
		foreach($retdata as $arrRetData){
			$retFlightSegment[$arrRetData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment[0]->FlightNumber] = $arrRetData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment;
		}
	}
}

/*if(count($retFlightSegment) > 0){
	foreach($retFlightSegment as $arrRetFlight){
		echo "<pre>"; print_r($arrRetFlight);exit;
	}
}
echo "<pre>"; print_r($retFlightSegment);exit;*/

if($LeadPriceCalendar->status != 'NotProcessed'){
	$data = $result->getResult("BargainFinderMax")->OTA_AirLowFareSearchRS->PricedItineraries->PricedItinerary;
	if(count($data) > 0){
		foreach($data as $arrData){
			$FlightSegment = $arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment;
			if(count($retFlightSegment) > 0){
				foreach($retFlightSegment as $key=>$value){
					if($FlightSegment[0]->OperatingAirline->Code == $value[0]->OperatingAirline->Code){
						echo $key."-------->".$value[0]->OperatingAirline->Code."<---------<br/>";
						unset($retFlightSegment[$key]);
						break;
					}					
				}
			}
			/*if(array_key_exists($FlightSegment[0]->OperatingAirline->Code,$retFlightSegment)){
				echo "33333333...".$FlightSegment[0]->FlightNumber."<br/>";
			}*/
		}
	}
}

exit;
echo "========================= origin to destination ============= <br/>";
echo "<pre>"; print_r($result);//exit;
echo "======================= end ========================= <br/>";
echo "========================= destination to origin ============= <br/>";
echo "<pre>"; print_r($retresult);//exit;
echo "======================= end ========================= <br/>";
exit;


/*$LeadPriceCalendar = $result->getResult("LeadPriceCalendar");
if($LeadPriceCalendar->status == 'Complete'){
	$data = $result->getResult("BargainFinderMax")->OTA_AirLowFareSearchRS->PricedItineraries->PricedItinerary;
	if(count($data) > 0){
		foreach($data as $arrData){
			$price_scraped = $arrData->AirItineraryPricingInfo[0]->ItinTotalFare->TotalFare->Amount;
			$price_scraped_currencycode = $arrData->AirItineraryPricingInfo[0]->ItinTotalFare->TotalFare->CurrencyCode;
			$departure_origin = $arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment[0]->DepartureDateTime;
			
			$FlightSegment = $arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment;
			foreach($FlightSegment as $arrFlightSegment){
				echo $arrFlightSegment->ArrivalDateTime."-----";
			}
		}
	}
}*/
$data = $result->getResult("BargainFinderMax")->OTA_AirLowFareSearchRS->PricedItineraries->PricedItinerary;
echo "<pre>"; print_r($data[0]);exit;
//echo "<pre>"; print_r($data[0]->AirItineraryPricingInfo);exit;
ob_start();
var_dump($result);
$dump = ob_get_clean();
echo $dump;
flush();
?>