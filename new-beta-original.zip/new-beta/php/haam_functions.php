﻿<?php

// Functions
//--------------------
// Sanitize bad input data
function test_input($data, $conn) {
	global $conn;
   $data=trim($data);
   $data=htmlspecialchars($data);
   $data=mysqli_real_escape_string($conn, $data);
  return $data;
}


// Check 
function checkLen($str,$len) {
	return mb_strlen($str,"utf-8") > $len;
}


//function for ip address
    function getRealIp() {
       if (!empty($_SERVER['HTTP_CLIENT_IP'])) {  //check ip from share internet
         $ip=$_SERVER['HTTP_CLIENT_IP'];
       } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  //to check ip is pass from proxy
         $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
       } else {
         $ip=$_SERVER['REMOTE_ADDR'];
       }
       return $ip;
    }
    
