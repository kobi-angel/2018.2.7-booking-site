<?php

// Utf-8 Header
header('Content-Type: text/html; charset=utf-8');

// Error Reporting
error_reporting(E_ERROR | E_WARNING | E_PARSE);

// Include DB connection
require_once('db.php');
// Include the file with functions
require_once("haam_functions.php"); 


// Max Excecution Time - 86400 seconds = 1 day
ini_set('max_execution_time', 600); 

// Memory usage limit
// Depends on server or machine available memory
ini_set('memory_limit','4096M');


// Test
//echo 'We are here <br>'; # Test

// Test
//echo 'From: '.$_POST['from'].'<br>'; # Test

// Test
//echo 'To: '.$_POST['to'].'<br>'; # Test

// Test
//echo 'Check In: '.$_POST['check_in'].'<br>'; # Test

// Test
//echo 'Check Out: '.$_POST['check_out'].'<br>'; # Test

// Test
//echo 'Passenger, Cabin: '.$_POST['TargetValSet'].'<br>'; # Test


if($_POST['from'] != '' && $_POST['to'] != '' && $_POST['check_in'] != '' && $_POST['check_out'] != '' && $_POST['TargetValSet'] != ''){

	// First make some input changes, to have correct values
	//------------------------------------------------------------
	$from_exploded_1 = explode("(",$_POST['from']);
	
	$from_exploded_2 = explode(")",$from_exploded_1[1]);
	
	$from_db = $from_exploded_2[0];
	
	// Test
	//echo $from_db.'<br>'; # Test
	
	//$from_url = str_replace(" ","%",$from_exploded[0]);
	$from_url = $from_db;
	
	// Test
	//echo $from_url.'<br>'; # Test
		
	$to_exploded_1 = explode("(",$_POST['to']);
	
	$to_exploded_2 = explode(")",$to_exploded_1[1]);
	
	$to_db = $to_exploded_2[0];
	
	// Test	
	//echo $to_db.'<br>'; # Test
	
	//$to_url = str_replace(" ","%",$to_exploded[0]);
	$to_url = $to_db;
	
	// Test
	//echo $to_url.'<br>'; # Test
		
	$check_in_time = strtotime($_POST['check_in']);
	
	$check_in_db = date('Y-m-d', $check_in_time);
	
	$check_in_db_year = date('Y', $check_in_time);
	
	// Test
	//echo $check_in_db.'<br>'; # Test 
		
	$check_in_url = date('d-m-Y', $check_in_time);
	
	// Test
	//echo $check_in_url.'<br>'; # Test 
	
	$check_out_time = strtotime($_POST['check_out']);
	
	$check_out_db = date('Y-m-d', $check_out_time);
	
	$check_out_db_year = date('Y', $check_out_time);
	
	// Test
	//echo $check_out_db.'<br>'; # Test
		
	$check_out_url = date('d-m-Y', $check_out_time);
	
	// Test
	//echo $check_out_url.'<br>'; # Test 

	
	// Passenger And Cabin
	$pass_cabin_explode = explode(', ', $_POST['TargetValSet']);
	
	$cabin_db = $pass_cabin_explode[count($pass_cabin_explode)-1];
	
	$cabin_url = strtolower($pass_cabin_explode[count($pass_cabin_explode)-1]);
	
	$passenger = 0;
	$adult = 0;
	$children = 0;
	$infant = 0;
	for($i = 0; $i < (count($pass_cabin_explode)-1); $i++){
	
		$pass_explode = explode(' ', $pass_cabin_explode[$i]);
		
		if($pass_explode[1] == 'Adult'){
			$passenger += $pass_explode[0];
			$adult = $pass_explode[0];		
		}
		else if($pass_explode[1] == 'Children'){
			$passenger += $pass_explode[0];
			$children = $pass_explode[0];			
		}
		else if($pass_explode[1] == 'Infant'){
			$passenger += $pass_explode[0];
			$infant = $pass_explode[0];			
		}
	
	}
	
	//$passenger = $adult + $children + $infant;
	 	
	// Check if already exist records in the DB for that search values
	//-----------------------------------------------------------------
	//$query_check_records = "SELECT * FROM flights WHERE from_code = '$from_db' AND to_code = '$to_db' AND departure_origin_date = '$check_in_db' AND arrival_origin_date = '$check_out_db'";
	
	//$result_check_records = mysqli_query($conn, $query_check_records) or die(mysqli_error($conn));
	
	//$count_check_records = mysqli_num_rows($result_check_records);
	
	// Test
	//echo $count_check_records.'<br>'; # Test
	
	// If no records are available, will scrap from API
	//--------------------------------------------------
	//if($row_count_check_records == 0){

		
		// If scraped items count is more than 0 will save into the DB
		// Else will tell user nothing is found
		//--------------------------------------------------------------
		if(1==1){
				
			// Frontend Ouput
			//--------------------------------
			$frontend_output = array();
			
				//$query_get_records = "SELECT * FROM flights WHERE user_random_id = '".$_POST['user_random_id']."' AND flights_system='travelpaddy'";
				$query_get_records = "SELECT * FROM flights WHERE from_code = '$from_db' AND to_code = '$to_db' AND departure_origin_date = '$check_in_db' AND arrival_origin_date = '$check_out_db' AND user_random_id = '".$_POST['user_random_id']."' ORDER BY price ASC";
				
				$result_get_records = mysqli_query($conn, $query_get_records) or die(mysqli_error($conn));
				
				while($row_get_records = mysqli_fetch_assoc($result_get_records)){
					
					// We get company logo
					$company_name_exploded = '';
					$company_name = '';
					$company_logo = '';	
					//$row_get_records['aircompany'] = 'Aegean Airlines - 859';				
					$company_name_exploded = explode(' - ',$row_get_records['aircompany']);
					$company_name  = $company_name_exploded[0];		
					
					$row_get_records['aircompany'] = $company_name;
								
					$query_get_logo = "SELECT * FROM airlines_logos WHERE airline_name LIKE '%".$company_name."%'";		
								
					$result_get_logo = mysqli_query($conn, $query_get_logo) or die(mysqli_error($conn));
										
					while($row_get_logo = mysqli_fetch_assoc($result_get_logo))	{	
									
						$company_logo = $row_get_logo['logo_name'];
					
					}					
								
					$row_get_records['company_logo'] = $company_logo;


					
						// We do travelpaddy info now
						$travelpaddy_price = 0;
						$query_get_records_travelpaddy = "SELECT * FROM flights WHERE aircompany LIKE '%".$company_name."%' AND from_code = '".$row_get_records['from_code']."' AND to_code = '".$row_get_records['to_code']."' AND departure_origin_time = '".$row_get_records['departure_origin_time']."' AND arrival_destination_time = '".$row_get_records['arrival_destination_time']."' AND arrival_origin_time = '".$row_get_records['arrival_origin_time']."' AND departure_destination_time = '".$row_get_records['departure_destination_time']."' AND user_random_id = '".$_POST['user_random_id']."' AND flights_system = 'travelpaddy' LIMIT 1";
										
						$result_get_records_travelpaddy = mysqli_query($conn, $query_get_records_travelpaddy) or die(mysqli_error($conn));
						
						$row_get_records_travelpaddy = mysqli_fetch_assoc($result_get_records_travelpaddy);
						
						if(mysqli_num_rows($result_get_records_travelpaddy) > 0){
						
							$travelpaddy_price = $row_get_records_travelpaddy['price'];
							
						}
						$row_get_records['price'] = $travelpaddy_price;
						
											
						// We do travelbeta info now
						$travelbeta_price = 0;
						$query_get_records_travelbeta = "SELECT * FROM flights WHERE aircompany LIKE '%".$company_name."%' AND from_code = '".$row_get_records['from_code']."' AND to_code = '".$row_get_records['to_code']."' AND departure_origin_time = '".$row_get_records['departure_origin_time']."' AND arrival_destination_time = '".$row_get_records['arrival_destination_time']."' AND arrival_origin_time = '".$row_get_records['arrival_origin_time']."' AND departure_destination_time = '".$row_get_records['departure_destination_time']."' AND user_random_id = '".$_POST['user_random_id']."' AND flights_system = 'travelbeta' LIMIT 1";
										
						$result_get_records_travelbeta = mysqli_query($conn, $query_get_records_travelbeta) or die(mysqli_error($conn));
						
						$row_get_records_travelbeta = mysqli_fetch_assoc($result_get_records_travelbeta);
						
						if(mysqli_num_rows($result_get_records_travelbeta) > 0){
						
							$travelbeta_price = $row_get_records_travelbeta['price'];
							
						}
						$row_get_records['travelbeta_price'] = $travelbeta_price;


						// We do travelden info now
						$travelden_price = 0;
						$query_get_records_travelden = "SELECT * FROM flights WHERE aircompany LIKE '%".$company_name."%' AND from_code = '".$row_get_records['from_code']."' AND to_code = '".$row_get_records['to_code']."' AND departure_origin_time = '".$row_get_records['departure_origin_time']."' AND arrival_destination_time = '".$row_get_records['arrival_destination_time']."' AND arrival_origin_time = '".$row_get_records['arrival_origin_time']."' AND departure_destination_time = '".$row_get_records['departure_destination_time']."' AND user_random_id = '".$_POST['user_random_id']."' AND flights_system = 'travelden' LIMIT 1";
										
						$result_get_records_travelden = mysqli_query($conn, $query_get_records_travelden) or die(mysqli_error($conn));
						
						$row_get_records_travelden = mysqli_fetch_assoc($result_get_records_travelden);
						
						if(mysqli_num_rows($result_get_records_travelden) > 0){
						
							$travelden_price = $row_get_records_travelden['price'];
							
						}
						$row_get_records['travelden_price'] = $travelden_price;
						

						// We do wakanow info now
						$wakanow_price = 0;
						$query_get_records_wakanow = "SELECT * FROM flights WHERE aircompany LIKE '%".$company_name."%' AND from_code = '".$row_get_records['from_code']."' AND to_code = '".$row_get_records['to_code']."' AND departure_origin_time = '".$row_get_records['departure_origin_time']."' AND arrival_destination_time = '".$row_get_records['arrival_destination_time']."' AND arrival_origin_time = '".$row_get_records['arrival_origin_time']."' AND departure_destination_time = '".$row_get_records['departure_destination_time']."' AND user_random_id = '".$_POST['user_random_id']."' AND flights_system = 'wakanow' LIMIT 1";
										
						$result_get_records_wakanow = mysqli_query($conn, $query_get_records_wakanow) or die(mysqli_error($conn));
						
						$row_get_records_wakanow = mysqli_fetch_assoc($result_get_records_wakanow);
						
						if(mysqli_num_rows($result_get_records_wakanow) > 0){
						
							$wakanow_price = $row_get_records_wakanow['price'];
							
						}
						$row_get_records['wakanow_price'] = $wakanow_price;
						
								
					// Frontend Output
					$frontend_output[] = $row_get_records;
				
				}


			
			// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
			echo(json_encode($frontend_output));
						
			// Test
			//print_r($frontend_output); #Test
			
		}
		else{
		
			echo 'NOK';		
		
		}
	
	//}
	//else{
	
	
	//	Frontend Output
	
	//}
	
	
}
else{
	echo '<div id="search_values_response" style="display:block;">You have to fill all fields above before search!</div>';
}

?>