<?php

// Utf-8 Header
header('Content-Type: text/html; charset=utf-8');

// Error Reporting
error_reporting(E_ERROR | E_WARNING | E_PARSE | ~E_NOTICE);

// Include DB connection
require_once('db.php');
// Include the file with functions
require_once("haam_functions.php"); 
include_once 'workflow/Workflow.php';
include_once 'rest_activities/LeadPriceCalendarActivity.php';


// Max Excecution Time - 86400 seconds = 1 day
ini_set('max_execution_time', 600); 

// Memory usage limit
// Depends on server or machine available memory
ini_set('memory_limit','1024M');


// Test
//echo 'We are here <br>'; # Test

// Test
//echo 'From: '.$_POST['from'].'<br>'; # Test

// Test
//echo 'To: '.$_POST['to'].'<br>'; # Test

// Test
//echo 'Check In: '.$_POST['check_in'].'<br>'; # Test

// Test
//echo 'Check Out: '.$_POST['check_out'].'<br>'; # Test

// Test
//echo 'Passenger, Cabin: '.$_POST['TargetValSet'].'<br>'; # Test


//if($_POST['from'] != '' && $_POST['to'] != '' && $_POST['check_in'] != '' && $_POST['check_out'] != '' && $_POST['TargetValSet'] != ''){
if($_POST['from'] != '' && $_POST['to'] != '' && $_POST['check_in'] != '' && $_POST['check_out'] != ''){

	// First make some input changes, to have correct values
	//------------------------------------------------------------
	$from_exploded_1 = explode("(",$_POST['from']);
	
	$from_exploded_2 = explode(")",$from_exploded_1[1]);
	
	$from_db = $from_exploded_2[0];
	
	// Test
	//echo $from_db.'<br>'; # Test
	
	//$from_url = str_replace(" ","%",$from_exploded[0]);
	$from_url = $from_db;
	
	// Test
	//echo $from_url.'<br>'; # Test
		
	$to_exploded_1 = explode("(",$_POST['to']);
	
	$to_exploded_2 = explode(")",$to_exploded_1[1]);
	
	$to_db = $to_exploded_2[0];
	
	// Test	
	//echo $to_db.'<br>'; # Test
	
	//$to_url = str_replace(" ","%",$to_exploded[0]);
	$to_url = $to_db;
	
	// Test
	//echo $to_url.'<br>'; # Test
		
	$check_in_time = strtotime($_POST['check_in']);
	
	$check_in_db = date('Y-m-d', $check_in_time);
	
	$check_in_db_year = date('Y', $check_in_time);
	
	// Test
	//echo $check_in_db.'<br>'; # Test 
		
	$check_in_url = date('d-m-Y', $check_in_time);
	
	// Test
	//echo $check_in_url.'<br>'; # Test 
	
	$check_out_time = strtotime($_POST['check_out']);
	
	$check_out_db = date('Y-m-d', $check_out_time);
	
	$check_out_db_year = date('Y', $check_out_time);
	
	// Test
	//echo $check_out_db.'<br>'; # Test
		
	$check_out_url = date('d-m-Y', $check_out_time);
	
	// Test
	//echo $check_out_url.'<br>'; # Test 

	
	// Passenger And Cabin
	$pass_cabin_explode = explode(', ', $_POST['TargetValSet']);
	
	$cabin_db = $pass_cabin_explode[count($pass_cabin_explode)-1];
	
	$cabin_url = strtolower($pass_cabin_explode[count($pass_cabin_explode)-1]);
	
	$passenger = 0;
	$adult = 0;
	$children = 0;
	$infant = 0;
	for($i = 0; $i < (count($pass_cabin_explode)-1); $i++){
	
		$pass_explode = explode(' ', $pass_cabin_explode[$i]);
		
		if($pass_explode[1] == 'Adult'){
			$passenger += $pass_explode[0];
			$adult = $pass_explode[0];		
		}
		else if($pass_explode[1] == 'Children'){
			$passenger += $pass_explode[0];
			$children = $pass_explode[0];			
		}
		else if($pass_explode[1] == 'Infant'){
			$passenger += $pass_explode[0];
			$infant = $pass_explode[0];			
		}
	
	}
	

	 	
	// Check if already exist records in the DB for that search values
	//-----------------------------------------------------------------
	$query_check_records = "SELECT flights_system FROM flights WHERE from_code = '".$from_db."' AND to_code = '".$to_db."' AND departure_origin_date = '".$check_in_db."' AND arrival_origin_date = '".$check_out_db."' AND flights_system = '".$_POST['flights_system']."'";
	
	$result_check_records = mysqli_query($conn, $query_check_records) or die(mysqli_error($conn));
	
	$count_check_records = mysqli_num_rows($result_check_records);
	
	// Test
	echo $count_check_records.'<br>'; # Test
	
	// If no records are available, will scrap from API
	//--------------------------------------------------
	if($count_check_records > 0){
	
		echo 'I am ready!';
		exit;
	
	} else if($count_check_records == 0){
	
		$item_scraped_count = 0;
		if($_POST['flights_system'] == 'sabre'){
			$retFlightSegment = array();
			$frontend_output = array();
			$workflow = new Workflow(new LeadPriceCalendarActivity($from_url, $to_url, $check_in_db, $cabin_db, $adult, $children, $infant, $check_out_db));
			$result = $workflow->runWorkflow();			
			$LeadPriceCalendar = $result->getResult("LeadPriceCalendar");

			if($LeadPriceCalendar->status != 'NotProcessed'){
				//$data = $LeadPriceCalendar->PricedItineraries;
				$data = $result->getResult("BargainFinderMax")->OTA_AirLowFareSearchRS->PricedItineraries->PricedItinerary;
				if(count($data) > 0){
					foreach($data as $arrData){
						//echo "<pre>"; print_r($arrData);exit;
						$price_scraped = $arrData->AirItineraryPricingInfo[0]->ItinTotalFare->TotalFare->Amount;
						$price_scraped_currencycode = $arrData->AirItineraryPricingInfo[0]->ItinTotalFare->TotalFare->CurrencyCode;

						//$origindata = $arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment;
						
						$FlightSegment = $arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment;
						//$from_db = $arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment[0]->DepartureAirport->LocationCode;
						
						$departure_origin = explode('T',$arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment[0]->DepartureDateTime);
						$departure_origin_time = $departure_origin[1];
						$departure_origin_date = $departure_origin[0];

						$arrival_destination_date = $arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment[0]->ArrivalDateTime;
						$arrival_destination = explode('T',$arrival_destination_date);
						$arrival_destination_time = $arrival_destination[1];
						$arrival_destination_date = $arrival_destination[0];
												
						$arrival_origin = explode('T',$arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[1]->FlightSegment[0]->DepartureDateTime);
						$arrival_origin_time = $arrival_origin[1];
						$arrival_origin_date = $arrival_origin[0];				
										
						$departure_destination = explode('T',$arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[1]->FlightSegment[0]->ArrivalDateTime);
						$departure_destination_time = $departure_destination[1];
						$departure_destination_date = $departure_destination[0];

						$company = '';
						$query_company = "SELECT * FROM airlines_logos WHERE logo_name = '".$arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment[0]->OperatingAirline->Code."'";
						$result_company = mysqli_query($conn, $query_company) or die(mysqli_error($conn));						
						$row_company = mysqli_fetch_assoc($result_company);						
						if(mysqli_num_rows($result_company) > 0){						
							$company = $row_company['airline_name'];							
						}						

						$stops = count($arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment) - 1;

						// DB insert
						$query_save_records = "INSERT INTO `flights` (`from_code`, `to_code`, `aircompany`, `price`, `stops`, `cabin`, `adult`, `children`, `infant`, `departure_origin_date`, `departure_origin_time`, `arrival_destination_date`, `arrival_destination_time`, `arrival_origin_date`, `arrival_origin_time`, `departure_destination_date`, `departure_destination_time`, `user_random_id`, `flights_system`, `type_of_trip`) VALUES ('".$from_db."', '".$to_db."', '".$company."', ".$price_scraped.", ".$stops.", '".$cabin_db."', ".$adult.", ".$children.", ".$infant.", '".$departure_origin_date."', '".$departure_origin_time."', '".$arrival_destination_date."', '".$arrival_destination_time."', '".$arrival_origin_date."', '".$arrival_origin_time."', '".$departure_destination_date."', '".$departure_destination_time."', '".$_POST['user_random_id']."', '".$_POST['flights_system']."', '".$_POST['type_of_trip']."')"; //exit;
			
						$result_save_records = mysqli_query($conn, $query_save_records) or die(mysqli_error($conn));
						
						echo 'I am ready! sabre';
					}
				}
			}
		}else{
		
			//Test scrap ulr
			//$scrap_url ='http://217.160.14.208/crawl.json?spider_name=travelpaddy&url=http://travelpaddy/Lagos/Paris/20-07-2017/30-07-2017/1/premium/return';
			
			echo $scrap_url = 'http://217.160.14.208/crawl.json?spider_name='.$_POST['flights_system'].'&url=http://'.$_POST['flights_system'].'/'.$from_url.'/'.$to_url.'/'.$check_in_url.'/'.$check_out_url.'/'.$passenger.'/'.$cabin_url.'/'.$_POST['type_of_trip'];
			
			// Test
			//echo $scrap_url.'<br>'; # Test
			
			$scrap_result = json_decode(file_get_contents($scrap_url), $assoc=true);
			
			// Test
			//print_r(json_decode(file_get_contents($scrap_url), $assoc=true));# Test
			// Test
			//echo '<br>'; # Test
			
			$item_scraped_count = 0;
			
			$item_scraped_count = $scrap_result['stats']['item_scraped_count'];
			
			// Test
			//echo $item_scraped_count.'<br>'; # Test
			
			// If scraped items count is more than 0 will save into the DB
			// Else will tell user nothing is found
			//--------------------------------------------------------------
			if($item_scraped_count > 0){
				$scraped_ids = array();
				$i = 0;
				for($i = 0; $i < $item_scraped_count; $i++){
					
					if($_POST['flights_system'] == 'travelpaddy'){
						// Test
						//echo $scrap_result['items'][$i]['arrival_destination'].'<br>'; # Test
						
						// Scraped price value tuning
						$price_exploded = explode(' ',$scrap_result['items'][$i]['price']);
						$price_scraped = $price_exploded[1];
						
						// Scraped departure_origin value tuning
						$departure_origin = explode(', ',$scrap_result['items'][$i]['departure_origin']);
						$departure_origin_time = date('H:i:s',strtotime($departure_origin[0]));
						$departure_origin_date = date('Y-m-d',strtotime($departure_origin[2]));
						
						// Test
						//echo 'departure_origin_time: '.$departure_origin_time.'<br>'; # Test
						//echo 'departure_origin_date: '.date('Y-m-d',strtotime($departure_origin[2])).'<br>'; # Test
										
						// Scraped arrival_destination value tuning	
						$arrival_destination = explode(', ',$scrap_result['items'][$i]['arrival_destination']);
						$arrival_destination_time = date('H:i:s',strtotime($arrival_destination[0]));
						$arrival_destination_date = date('Y-m-d',strtotime($arrival_destination[2]));				
									
						// Scraped arrival_origin value tuning
						$arrival_origin = explode(', ',$scrap_result['items'][$i]['arrival_origin']);
						$arrival_origin_time = date('H:i:s',strtotime($arrival_origin[0]));
						$arrival_origin_date = date('Y-m-d',strtotime($arrival_origin[2]));				
										
						// Scraped departure_destination value tuning
						$departure_destination = explode(', ',$scrap_result['items'][$i]['departure_destination']);
						$departure_destination_time = date('H:i:s',strtotime($departure_destination[0]));
						$departure_destination_date = date('Y-m-d',strtotime($departure_destination[2]));
										
										
					} elseif($_POST['flights_system'] == 'travelbeta'){
					
						// Scraped price value tuning
						$price_scraped = str_replace(',', '', $scrap_result['items'][$i]['price']);	
														
						// Scraped departure_origin value tuning
						$departure_origin = explode(', ',$scrap_result['items'][$i]['departure_origin']);
						$departure_origin_time = date('H:i:s',strtotime($departure_origin[2]));
						$departure_origin_date = date('Y-m-d',strtotime($departure_origin[1].' '.$check_in_db_year));
						
						// Test
						//echo 'departure_origin_time: '.$departure_origin_time.'<br>'; # Test
						//echo 'departure_origin_date: '.$departure_origin_date.'<br>'; # Test
										
						// Scraped arrival_destination value tuning	
						$arrival_destination = explode(', ',$scrap_result['items'][$i]['arrival_destination']);
						$arrival_destination_time = date('H:i:s',strtotime($arrival_destination[2]));	
						$arrival_destination_date = date('Y-m-d',strtotime($arrival_destination[1].' '.$check_in_db_year));	
						
						// Test
						//echo 'arrival_destination_time: '.$arrival_destination_time.'<br>'; # Test
						//echo 'arrival_destination_date: '.$arrival_destination_date.'<br>'; # Test			
									
						// Scraped arrival_origin value tuning
						$arrival_origin = explode(', ',$scrap_result['items'][$i]['arrival_origin']);
						$arrival_origin_time = date('H:i:s',strtotime($arrival_origin[2]));	
						$arrival_origin_date = date('Y-m-d',strtotime($arrival_origin[1].' '.$check_out_db_year));	
						
						// Test
						//echo 'arrival_origin_time: '.$arrival_origin_time.'<br>'; # Test
						//echo 'arrival_origin_date: '.$arrival_origin_date.'<br>'; # Test				
										
						// Scraped departure_destination value tuning
						$departure_destination = explode(', ',$scrap_result['items'][$i]['departure_destination']);
						$departure_destination_time = date('H:i:s',strtotime($departure_destination[2]));	
						$departure_destination_date = date('Y-m-d',strtotime($departure_destination[1].' '.$check_out_db_year));	
						
						// Test
						//echo 'departure_destination_time: '.$departure_destination_time.'<br>'; # Test
						//echo 'departure_destination_date: '.$departure_destination_date.'<br>'.'<br>'.'<br>'; # Test		
										
					} elseif($_POST['flights_system'] == 'travelden'){
					
					
						// Scraped price value tuning
						$price_scraped = str_replace(',', '', $scrap_result['items'][$i]['price']);				
										
						// Scraped departure_origin value tuning
						$departure_origin = explode(' ',$scrap_result['items'][$i]['departure_origin']);
						$departure_origin_time = date('H:i:s',strtotime($departure_origin[0]));
						$departure_origin_date = date('Y-m-d',strtotime($departure_origin[2].' '.$departure_origin[3].' '.$check_in_db_year));
						
						// Test
						//echo 'departure_origin_time: '.$departure_origin_time.'<br>'; # Test
						//echo 'departure_origin_date: '.date('Y-m-d',strtotime($departure_origin[2])).'<br>'; # Test
										
						// Scraped arrival_destination value tuning	
						$arrival_destination = explode(' ',$scrap_result['items'][$i]['arrival_destination']);
						$arrival_destination_time = date('H:i:s',strtotime($arrival_destination[0]));	
						$arrival_destination_date = date('Y-m-d',strtotime($arrival_destination[2].' '.$arrival_destination[3].' '.$check_in_db_year));				
									
						// Scraped arrival_origin value tuning
						$arrival_origin = explode(' ',$scrap_result['items'][$i]['departure_destination']);
						$arrival_origin_time = date('H:i:s',strtotime($arrival_origin[0]));	
						$arrival_origin_date = date('Y-m-d',strtotime($arrival_origin[2].' '.$arrival_origin[3].' '.$check_out_db_year));				
										
						// Scraped departure_destination value tuning
						$departure_destination = explode(' ',$scrap_result['items'][$i]['arrival_origin']);
						$departure_destination_time = date('H:i:s',strtotime($departure_destination[0]));	
						$departure_destination_date = date('Y-m-d',strtotime($departure_destination[2].' '.$departure_destination[3].' '.$check_out_db_year));	
										
					} elseif($_POST['flights_system'] == 'wakanow'){
					
					
						// Scraped price value tuning
						$price_scraped = $scrap_result['items'][$i]['price'];	
						
						
						// Scraped departure_origin value tuning
						$departure_origin = explode('T',$scrap_result['items'][$i]['departure_origin']);
						$departure_origin_time = $departure_origin[1];
						$departure_origin_date = $departure_origin[0];
						
						// Test
						//echo 'departure_origin_time: '.$departure_origin_time.'<br>'; # Test
						//echo 'departure_origin_date: '.date('Y-m-d',strtotime($departure_origin[2])).'<br>'; # Test
										
						// Scraped arrival_destination value tuning	
						$arrival_destination = explode('T',$scrap_result['items'][$i]['arrival_destination']);
						$arrival_destination_time = $arrival_destination[1];
						$arrival_destination_date = $arrival_destination[0];				
									
						// Scraped arrival_origin value tuning
						$arrival_origin = explode('T',$scrap_result['items'][$i]['arrival_origin']);
						$arrival_origin_time = $arrival_origin[1];
						$arrival_origin_date = $arrival_origin[0];				
										
						// Scraped departure_destination value tuning
						$departure_destination = explode('T',$scrap_result['items'][$i]['departure_destination']);
						$departure_destination_time = $departure_destination[1];
						$departure_destination_date = $departure_destination[0];									
					
					}
									
					// DB insert
					$query_save_records = "INSERT INTO `flights` (`from_code`, `to_code`, `aircompany`, `price`, `cabin`, `adult`, `children`, `infant`, `departure_origin_date`, `departure_origin_time`, `arrival_destination_date`, `arrival_destination_time`, `arrival_origin_date`, `arrival_origin_time`, `departure_destination_date`, `departure_destination_time`, `user_random_id`, `flights_system`, `type_of_trip`) VALUES ('".$from_db."', '".$to_db."', '".$scrap_result['items'][$i]['company']."', ".$price_scraped.", '".$cabin_db."', ".$adult.", ".$children.", ".$infant.", '".$departure_origin_date."', '".$departure_origin_time."', '".$arrival_destination_date."', '".$arrival_destination_time."', '".$arrival_origin_date."', '".$arrival_origin_time."', '".$departure_destination_date."', '".$departure_destination_time."', '".$_POST['user_random_id']."', '".$_POST['flights_system']."', '".$_POST['type_of_trip']."')";
		
					$result_save_records = mysqli_query($conn, $query_save_records) or die(mysqli_error($conn));
					
					echo 'I am ready!';

				}
			}
			
		}

	
	}

	
	
}
else{
	echo '<div id="search_values_response" style="display:block;">You have to fill all fields above before search!</div>';
}

?>