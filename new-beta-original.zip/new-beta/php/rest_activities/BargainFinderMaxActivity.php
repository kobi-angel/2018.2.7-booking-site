<?php

include_once 'workflow/Activity.php';

class BargainFinderMaxActivity implements Activity {

    public function run(&$sharedContext) {

        $call = new RestClient();
        $origin = $sharedContext->getResult("origin");
        $destination = $sharedContext->getResult("destination");
        $departureDate = $sharedContext->getResult("departureDate");
		$returnDate = $sharedContext->getResult("returnDate");
		$cabin = $sharedContext->getResult("cabin");
		$adt = $sharedContext->getResult("adt");
		$cnn = $sharedContext->getResult("cnn");
		$inf = $sharedContext->getResult("inf");
        $result = $call->executePostCall("/v1.8.6/shop/flights?mode=live", $this->getRequest($origin, $destination, $departureDate, $cabin, $adt, $cnn, $inf, $returnDate));
        $sharedContext->addResult("BargainFinderMax", $result);
        return null;
    }

    private function getRequest($origin, $destination, $departureDate, $cabin = 'Economy', $adt = 1, $cnn = 0, $inf = 0, $returnDate = '') {
        $request = '{
			"OTA_AirLowFareSearchRQ": {
				"OriginDestinationInformation": [{
					"RPH" : "1",
					"DepartureDateTime" : "'.$departureDate.'T00:00:00",
					"OriginLocation" : {
						"LocationCode" : "'.$origin.'"
					},
					"DestinationLocation" : {
						"LocationCode" : "'.$destination.'"
					}
				}';
		if($returnDate != ''){
		$request .= ',{
					"RPH" : "2",
					"DepartureDateTime" : "'.$returnDate.'T00:00:00",
					"OriginLocation" : {
						"LocationCode" : "'.$destination.'"
					},
					"DestinationLocation" : {
						"LocationCode" : "'.$origin.'"
					}
				}';
		}
		$request .= '],
				"POS": {
					"Source": [{
						"RequestorID": {
							"CompanyName": {
								"Code": "TN"
							},							
							"ID": "REQ.ID",
							"Type": "0.AAA.X"
						}
					}]
				},				
				"TPA_Extensions": {
					"IntelliSellTransaction": {
						"RequestType": {
							"Name": "50ITINS"
						}
					}
				},
				"TravelerInfoSummary": {
					"AirTravelerAvail": [{
						"PassengerTypeQuantity": [{
							"Code": "ADT",
							"Quantity": '.$adt.'
						}';
		if($cnn > 0){
		$request .= ', {
							"Code": "CNN",
							"Quantity": '.$cnn.'
						}';
		}
		if($inf > 0){
		$request .= ', {
							"Code": "INF",
							"Quantity": '.$inf.'
						}';
		}
		$request .= ']
					}]
				}
			}
		}';
        return $request;
    }

}
