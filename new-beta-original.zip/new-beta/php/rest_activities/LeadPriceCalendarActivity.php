<?php
include_once 'workflow/Activity.php';
include_once 'rest/RestClient.php';
include_once 'rest_activities/InstaFlightActivity.php';

class LeadPriceCalendarActivity implements Activity {

    private $origin, $destination, $departureDate, $returnDate, $cabin, $adt, $cnn, $inf;
    
    public function __construct($origin, $destination, $departureDate, $cabin, $adt, $cnn, $inf, $returnDate='') {
        $this->origin = $origin;
        $this->destination = $destination;
        $this->departureDate = $departureDate;
		$this->returnDate = $returnDate;
		$this->cabin = $cabin;
		$this->adt = $adt;
		$this->cnn = $cnn;
		$this->inf = $inf;
    }
    
    public function run(&$sharedContext) {
		$call = new RestClient();
        $sharedContext->addResult("origin", $this->origin);
        $sharedContext->addResult("destination", $this->destination);
        $sharedContext->addResult("departureDate", $this->departureDate);
		$sharedContext->addResult("cabin", $this->cabin);
		$sharedContext->addResult("adt", $this->adt);
		$sharedContext->addResult("cnn", $this->cnn);
		$sharedContext->addResult("inf", $this->inf);
		if($this->returnDate != ''){
			$sharedContext->addResult("returnDate", $this->returnDate);        
			$result = $call->executeGetCall("/v2/shop/flights", $this->getRequest($this->origin, $this->destination, $this->departureDate, $this->returnDate));
		}else{
			$result = $call->executeGetCall("/v2/shop/flights", $this->getRequest($this->origin, $this->destination, $this->departureDate));
		}
        $sharedContext->addResult("LeadPriceCalendar", $result);
        return new InstaFlightActivity();
    }
    
    private function getRequest($origin, $destination, $departureDate, $returnDate = '') {
		if($returnDate != ''){
			$request = array(
					"lengthofstay" => "5",
					"triptype" => "Return",
					"limit" => 1000,
					"pointofsalecountry" => "US",
					//"passengertype" => array("code"=>"ADT", "quantity"=>3),
					"origin" => $origin,
					"destination" => $destination,
					"departuredate" => $departureDate,
					"returndate" => $returnDate
			);
		}else{
			$request = array(
					"lengthofstay" => "5",
					"limit" => 1000,
					"pointofsalecountry" => "US",
					"origin" => $origin,
					"destination" => $destination,
					"departuredate" => $departureDate
			);
		}
        return $request;
    }
}
