<?php
include_once 'workflow/Activity.php';
include_once 'rest/RestClient.php';
include_once 'rest_activities/InstaFlightActivity.php';

class LeadPriceCalendarActivity implements Activity {

    private $origin, $destination, $departureDate, $returnDate;
    
    public function __construct($origin, $destination, $departureDate, $returnDate='') {
        $this->origin = $origin;
        $this->destination = $destination;
        $this->departureDate = $departureDate;
		$this->returnDate = $returnDate;
    }
    
    public function run(&$sharedContext) {
        $sharedContext->addResult("origin", $this->origin);
        $sharedContext->addResult("destination", $this->destination);
        $sharedContext->addResult("departureDate", $this->departureDate);
		$sharedContext->addResult("returnDate", $this->returnDate);
        $call = new RestClient();
        $result = $call->executeGetCall("/v2/shop/flights", $this->getRequest($this->origin, $this->destination, $this->departureDate, $this->returnDate));
        $sharedContext->addResult("LeadPriceCalendar", $result);
        return new InstaFlightActivity();
    }
    
    private function getRequest($origin, $destination, $departureDate, $returnDate = '') {
        $request = array(
				"lengthofstay" => "5",
                /*"DirectionInd" => "Return",*/
				"limit" => 1000,
                "pointofsalecountry" => "IN",
                "origin" => $origin,
                "destination" => $destination,
                "departuredate" => $departureDate,
				"returndate" => $returnDate
        );
        return $request;
    }
}
