<?php
// Utf-8 Header
header('Content-Type: text/html; charset=utf-8');

// Error Reporting
error_reporting(E_ERROR | E_WARNING | E_PARSE | ~E_NOTICE);

// Include DB connection
require_once('db.php');
// Include the file with functions
require_once("haam_functions.php"); 
include_once 'workflow/Workflow.php';
include_once 'rest_activities/LeadPriceCalendarActivity.php';


// Max Excecution Time - 86400 seconds = 1 day
ini_set('max_execution_time', 600); 

// Memory usage limit
// Depends on server or machine available memory
ini_set('memory_limit','1024M');


if($_REQUEST['from'] != '' && $_REQUEST['to'] != '' && $_REQUEST['check_in'] != '' && $_REQUEST['check_out'] != ''){

	// First make some input changes, to have correct values
	//------------------------------------------------------------
	$from_exploded_1 = explode("(",$_REQUEST['from']);	
	$from_exploded_2 = explode(")",$from_exploded_1[1]);	

	$from_db = $from_exploded_2[0];
	$from_url = $from_db;
		
	$to_exploded_1 = explode("(",$_REQUEST['to']);	
	$to_exploded_2 = explode(")",$to_exploded_1[1]);
	
	$to_db = $to_exploded_2[0];
	$to_url = $to_db;
	
	$chekindate = explode("/", $_REQUEST['check_in']);
	//$check_in_time = strtotime($_REQUEST['check_in']);	
	$check_in_db = $chekindate[2]."-".$chekindate[0]."-".$chekindate[1];//date('Y-m-d', $check_in_time);
	$check_in_time = strtotime($check_in_db);
	$check_in_db_year = date('Y', $check_in_time);		
	$check_in_url = date('d-m-Y', $check_in_time);	
	
	$chekoutdate = explode("/", $_REQUEST['check_out']);
	//$check_out_time = strtotime($_REQUEST['check_out']);	
	$check_out_db = $chekoutdate[2]."-".$chekoutdate[0]."-".$chekoutdate[1];//date('Y-m-d', $check_out_time);
	$check_out_time = strtotime($check_out_db);
	$check_out_db_year = date('Y', $check_out_time);
	$check_out_url = date('d-m-Y', $check_out_time);
	
	// Passenger And Cabin
	$pass_cabin_explode = explode(', ', $_REQUEST['TargetValSet']);	
	$cabin_db = $pass_cabin_explode[count($pass_cabin_explode)-1];	
	$cabin_url = strtolower($pass_cabin_explode[count($pass_cabin_explode)-1]);
	
	$passenger = 0;
	$adult = 0;
	$children = 0;
	$infant = 0;
	for($i = 0; $i < (count($pass_cabin_explode)-1); $i++){	
		$pass_explode = explode(' ', $pass_cabin_explode[$i]);		
		if($pass_explode[1] == 'Adult'){
			$passenger += $pass_explode[0];
			$adult = $pass_explode[0];		
		} else if($pass_explode[1] == 'Children'){
			$passenger += $pass_explode[0];
			$children = $pass_explode[0];			
		} else if($pass_explode[1] == 'Infant'){
			$passenger += $pass_explode[0];
			$infant = $pass_explode[0];			
		}
	}
	
	$frontend_output = array();
	$filesystem = array('travelpaddy', 'travelbeta', 'travelden', 'wakanow');
	$sabredata = array();
	$travelpaddydata  = array();
	$travelbetadata  = array();
	$traveldendata  = array();
	$wakanowdata  = array();

	$retFlightSegment = array();
	$frontend_output = array();
	$workflow = new Workflow(new LeadPriceCalendarActivity($from_url, $to_url, $check_in_db, $cabin_db, $adult, $children, $infant, $check_out_db));
	$result = $workflow->runWorkflow();			
	$LeadPriceCalendar = $result->getResult("LeadPriceCalendar");
	//echo "<pre>!!!!!"; print_r($LeadPriceCalendar);exit;

	if($LeadPriceCalendar->status != 'NotProcessed'){
		$data = $result->getResult("BargainFinderMax")->OTA_AirLowFareSearchRS->PricedItineraries->PricedItinerary;
		//echo "<pre>!!!!!"; print_r($data);exit;
		if(count($data) > 0){
			foreach($data as $arrData){
				//echo "<pre>"; print_r($arrData);exit;
				$price_scraped = $arrData->AirItineraryPricingInfo[0]->ItinTotalFare->TotalFare->Amount;
				$price_scraped_currencycode = $arrData->AirItineraryPricingInfo[0]->ItinTotalFare->TotalFare->CurrencyCode;

				//$origindata = $arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment;
				
				$FlightSegment = $arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment;
				//$from_db = $arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment[0]->DepartureAirport->LocationCode;
				
				$departure_origin = explode('T',$arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment[0]->DepartureDateTime);
				$departure_origin_time = $departure_origin[1];
				$departure_origin_date = $departure_origin[0];

				$arrival_destination_date = $arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment[0]->ArrivalDateTime;
				$arrival_destination = explode('T',$arrival_destination_date);
				$arrival_destination_time = $arrival_destination[1];
				$arrival_destination_date = $arrival_destination[0];
										
				$arrival_origin = explode('T',$arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[1]->FlightSegment[0]->DepartureDateTime);
				$arrival_origin_time = $arrival_origin[1];
				$arrival_origin_date = $arrival_origin[0];				
								
				$departure_destination = explode('T',$arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[1]->FlightSegment[0]->ArrivalDateTime);
				$departure_destination_time = $departure_destination[1];
				$departure_destination_date = $departure_destination[0];

				$company = '';
				$query_company = "SELECT * FROM airlines_logos WHERE logo_name = '".$arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment[0]->OperatingAirline->Code."'";
				$result_company = mysqli_query($conn, $query_company) or die(mysqli_error($conn));						
				$row_company = mysqli_fetch_assoc($result_company);						
				if(mysqli_num_rows($result_company) > 0){						
					$company = $row_company['airline_name'];							
				}						

				$stops = count($arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment) - 1;
				$sabtemparr = array();
				$sabtemparr['from_code'] = $from_db;
				$sabtemparr['to_code'] = $to_db;
				$sabtemparr['aircompany'] = $company;
				$sabtemparr['logoname'] = $arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment[0]->OperatingAirline->Code;
				$sabtemparr['price'] = $price_scraped;
				$sabtemparr['stops'] = $stops;
				$sabtemparr['cabin'] = $cabin_db;
				$sabtemparr['adult'] = $adult;
				$sabtemparr['children'] = $children;
				$sabtemparr['infant'] = $infant;
				$sabtemparr['departure_origin_date'] = $departure_origin_date;
				$sabtemparr['departure_origin_time'] = $departure_origin_time;
				$sabtemparr['arrival_destination_date'] = $arrival_destination_date;
				$sabtemparr['arrival_destination_time'] = $arrival_destination_time;
				$sabtemparr['arrival_origin_date'] = $arrival_origin_date;
				$sabtemparr['arrival_origin_time'] = $arrival_origin_time;
				$sabtemparr['departure_destination_date'] = $departure_destination_date;
				$sabtemparr['departure_destination_time'] = $departure_destination_time;
				$sabtemparr['user_random_id'] = $_REQUEST['user_random_id'];
				$sabtemparr['flights_system'] = 'sabre';//$_REQUEST['flights_system'];
				$sabtemparr['type_of_trip'] = $_REQUEST['type_of_trip'];

				$sabredata[] = $sabtemparr;
			}
		}		
	}
	
	if(count($filesystem) > 0){
		for($fs = 0; $fs < count($filesystem); $fs++){
			//echo $filesystem[$fs]."----";
			$scrap_url = 'http://217.160.14.208/crawl.json?spider_name='.$filesystem[$fs].'&url=http://'.$filesystem[$fs].'/'.$from_url.'/'.$to_url.'/'.$check_in_url.'/'.$check_out_url.'/'.$passenger.'/'.$cabin_url.'/'.$_REQUEST['type_of_trip'];

			$scrap_result = json_decode(file_get_contents($scrap_url), $assoc=true);
			$item_scraped_count = 0;
			
			$item_scraped_count = $scrap_result['stats']['item_scraped_count'];
			if($item_scraped_count > 0){
				$scraped_ids = array();
				$i = 0;
				for($i = 0; $i < $item_scraped_count; $i++){
					if($filesystem[$fs] == 'travelpaddy'){
						$price_exploded = explode(' ',$scrap_result['items'][$i]['price']);
						$price_scraped = $price_exploded[1];
						$stops = 0;

						$departure_origin = explode(', ',$scrap_result['items'][$i]['departure_origin']);
						$departure_origin_time = date('H:i:s',strtotime($departure_origin[0]));
						$departure_origin_date = date('Y-m-d',strtotime($departure_origin[2]));

						$arrival_destination = explode(', ',$scrap_result['items'][$i]['arrival_destination']);
						$arrival_destination_time = date('H:i:s',strtotime($arrival_destination[0]));
						$arrival_destination_date = date('Y-m-d',strtotime($arrival_destination[2]));

						$arrival_origin = explode(', ',$scrap_result['items'][$i]['arrival_origin']);
						$arrival_origin_time = date('H:i:s',strtotime($arrival_origin[0]));
						$arrival_origin_date = date('Y-m-d',strtotime($arrival_origin[2]));

						$departure_destination = explode(', ',$scrap_result['items'][$i]['departure_destination']);
						$departure_destination_time = date('H:i:s',strtotime($departure_destination[0]));
						$departure_destination_date = date('Y-m-d',strtotime($departure_destination[2]));

						$travelpaddytemparr = array();
						$travelpaddytemparr['from_code'] = $from_db;
						$travelpaddytemparr['to_code'] = $to_db;
						$travelpaddytemparr['aircompany'] = $company;
						$travelpaddytemparr['price'] = $price_scraped;
						$travelpaddytemparr['stops'] = $stops;
						$travelpaddytemparr['cabin'] = $cabin_db;
						$travelpaddytemparr['adult'] = $adult;
						$travelpaddytemparr['children'] = $children;
						$travelpaddytemparr['infant'] = $infant;
						$travelpaddytemparr['departure_origin_date'] = $departure_origin_date;
						$travelpaddytemparr['departure_origin_time'] = $departure_origin_time;
						$travelpaddytemparr['arrival_destination_date'] = $arrival_destination_date;
						$travelpaddytemparr['arrival_destination_time'] = $arrival_destination_time;
						$travelpaddytemparr['arrival_origin_date'] = $arrival_origin_date;
						$travelpaddytemparr['arrival_origin_time'] = $arrival_origin_time;
						$travelpaddytemparr['departure_destination_date'] = $departure_destination_date;
						$travelpaddytemparr['departure_destination_time'] = $departure_destination_time;
						$travelpaddytemparr['user_random_id'] = $_REQUEST['user_random_id'];
						$travelpaddytemparr['flights_system'] = $filesystem[$fs];
						$travelpaddytemparr['type_of_trip'] = $_REQUEST['type_of_trip'];

						$travelpaddydata[] = $travelpaddytemparr;
					}

					if($filesystem[$fs] == 'travelbeta'){
						$price_scraped = str_replace(',', '', $scrap_result['items'][$i]['price']);	

						$departure_origin = explode(', ',$scrap_result['items'][$i]['departure_origin']);
						$departure_origin_time = date('H:i:s',strtotime($departure_origin[2]));
						$departure_origin_date = date('Y-m-d',strtotime($departure_origin[1].' '.$check_in_db_year));

						$arrival_destination = explode(', ',$scrap_result['items'][$i]['arrival_destination']);
						$arrival_destination_time = date('H:i:s',strtotime($arrival_destination[2]));	
						$arrival_destination_date = date('Y-m-d',strtotime($arrival_destination[1].' '.$check_in_db_year));

						$arrival_origin = explode(', ',$scrap_result['items'][$i]['arrival_origin']);
						$arrival_origin_time = date('H:i:s',strtotime($arrival_origin[2]));	
						$arrival_origin_date = date('Y-m-d',strtotime($arrival_origin[1].' '.$check_out_db_year));

						$departure_destination = explode(', ',$scrap_result['items'][$i]['departure_destination']);
						$departure_destination_time = date('H:i:s',strtotime($departure_destination[2]));	
						$departure_destination_date = date('Y-m-d',strtotime($departure_destination[1].' '.$check_out_db_year));

						$travelbetatemparr = array();
						$travelbetatemparr['from_code'] = $from_db;
						$travelbetatemparr['to_code'] = $to_db;
						$travelbetatemparr['aircompany'] = $company;
						$travelbetatemparr['price'] = $price_scraped;
						$travelbetatemparr['stops'] = $stops;
						$travelbetatemparr['cabin'] = $cabin_db;
						$travelbetatemparr['adult'] = $adult;
						$travelbetatemparr['children'] = $children;
						$travelbetatemparr['infant'] = $infant;
						$travelbetatemparr['departure_origin_date'] = $departure_origin_date;
						$travelbetatemparr['departure_origin_time'] = $departure_origin_time;
						$travelbetatemparr['arrival_destination_date'] = $arrival_destination_date;
						$travelbetatemparr['arrival_destination_time'] = $arrival_destination_time;
						$travelbetatemparr['arrival_origin_date'] = $arrival_origin_date;
						$travelbetatemparr['arrival_origin_time'] = $arrival_origin_time;
						$travelbetatemparr['departure_destination_date'] = $departure_destination_date;
						$travelbetatemparr['departure_destination_time'] = $departure_destination_time;
						$travelbetatemparr['user_random_id'] = $_REQUEST['user_random_id'];
						$travelbetatemparr['flights_system'] = $filesystem[$fs];
						$travelbetatemparr['type_of_trip'] = $_REQUEST['type_of_trip'];

						$travelbetadata[] = $travelbetatemparr;
					}

					if($filesystem[$fs] == 'travelden'){
						$price_scraped = str_replace(',', '', $scrap_result['items'][$i]['price']);

						$departure_origin = explode(' ',$scrap_result['items'][$i]['departure_origin']);
						$departure_origin_time = date('H:i:s',strtotime($departure_origin[0]));
						$departure_origin_date = date('Y-m-d',strtotime($departure_origin[2].' '.$departure_origin[3].' '.$check_in_db_year));

						$arrival_destination = explode(' ',$scrap_result['items'][$i]['arrival_destination']);
						$arrival_destination_time = date('H:i:s',strtotime($arrival_destination[0]));	
						$arrival_destination_date = date('Y-m-d',strtotime($arrival_destination[2].' '.$arrival_destination[3].' '.$check_in_db_year));

						$arrival_origin = explode(' ',$scrap_result['items'][$i]['departure_destination']);
						$arrival_origin_time = date('H:i:s',strtotime($arrival_origin[0]));	
						$arrival_origin_date = date('Y-m-d',strtotime($arrival_origin[2].' '.$arrival_origin[3].' '.$check_out_db_year));

						$departure_destination = explode(' ',$scrap_result['items'][$i]['arrival_origin']);
						$departure_destination_time = date('H:i:s',strtotime($departure_destination[0]));	
						$departure_destination_date = date('Y-m-d',strtotime($departure_destination[2].' '.$departure_destination[3].' '.$check_out_db_year));

						$traveldentemparr = array();
						$traveldentemparr['from_code'] = $from_db;
						$traveldentemparr['to_code'] = $to_db;
						$traveldentemparr['aircompany'] = $company;
						$traveldentemparr['price'] = $price_scraped;
						$traveldentemparr['stops'] = $stops;
						$traveldentemparr['cabin'] = $cabin_db;
						$traveldentemparr['adult'] = $adult;
						$traveldentemparr['children'] = $children;
						$traveldentemparr['infant'] = $infant;
						$traveldentemparr['departure_origin_date'] = $departure_origin_date;
						$traveldentemparr['departure_origin_time'] = $departure_origin_time;
						$traveldentemparr['arrival_destination_date'] = $arrival_destination_date;
						$traveldentemparr['arrival_destination_time'] = $arrival_destination_time;
						$traveldentemparr['arrival_origin_date'] = $arrival_origin_date;
						$traveldentemparr['arrival_origin_time'] = $arrival_origin_time;
						$traveldentemparr['departure_destination_date'] = $departure_destination_date;
						$traveldentemparr['departure_destination_time'] = $departure_destination_time;
						$traveldentemparr['user_random_id'] = $_REQUEST['user_random_id'];
						$traveldentemparr['flights_system'] = $filesystem[$fs];
						$traveldentemparr['type_of_trip'] = $_REQUEST['type_of_trip'];

						$traveldendata[] = $traveldentemparr;
					}

					if($filesystem[$fs] == 'wakanow'){
						$price_scraped = $scrap_result['items'][$i]['price'];

						$departure_origin = explode('T',$scrap_result['items'][$i]['departure_origin']);
						$departure_origin_time = $departure_origin[1];
						$departure_origin_date = $departure_origin[0];

						$arrival_destination = explode('T',$scrap_result['items'][$i]['arrival_destination']);
						$arrival_destination_time = $arrival_destination[1];
						$arrival_destination_date = $arrival_destination[0];

						$arrival_origin = explode('T',$scrap_result['items'][$i]['arrival_origin']);
						$arrival_origin_time = $arrival_origin[1];
						$arrival_origin_date = $arrival_origin[0];

						$departure_destination = explode('T',$scrap_result['items'][$i]['departure_destination']);
						$departure_destination_time = $departure_destination[1];
						$departure_destination_date = $departure_destination[0];

						$wakanowtemparr = array();
						$wakanowtemparr['from_code'] = $from_db;
						$wakanowtemparr['to_code'] = $to_db;
						$wakanowtemparr['aircompany'] = $company;
						$wakanowtemparr['price'] = $price_scraped;
						$wakanowtemparr['stops'] = $stops;
						$wakanowtemparr['cabin'] = $cabin_db;
						$wakanowtemparr['adult'] = $adult;
						$wakanowtemparr['children'] = $children;
						$wakanowtemparr['infant'] = $infant;
						$wakanowtemparr['departure_origin_date'] = $departure_origin_date;
						$wakanowtemparr['departure_origin_time'] = $departure_origin_time;
						$wakanowtemparr['arrival_destination_date'] = $arrival_destination_date;
						$wakanowtemparr['arrival_destination_time'] = $arrival_destination_time;
						$wakanowtemparr['arrival_origin_date'] = $arrival_origin_date;
						$wakanowtemparr['arrival_origin_time'] = $arrival_origin_time;
						$wakanowtemparr['departure_destination_date'] = $departure_destination_date;
						$wakanowtemparr['departure_destination_time'] = $departure_destination_time;
						$wakanowtemparr['user_random_id'] = $_REQUEST['user_random_id'];
						$wakanowtemparr['flights_system'] = $filesystem[$fs];
						$wakanowtemparr['type_of_trip'] = $_REQUEST['type_of_trip'];

						$wakanowdata[] = $wakanowtemparr;
					}
				}
			}
		}
	}	

	$frontend_output['sabre'] = $sabredata;
	$frontend_output['travelpaddy'] = $travelpaddydata;
	$frontend_output['travelbeta'] = $travelbetadata;
	$frontend_output['travelden'] = $traveldendata;
	$frontend_output['wakanow'] = $wakanowdata;

	//echo "<pre>"; print_r($sabredata);
	
	//if(count($frontend_output) > 0){
	$htmlres = '';
	if(count($sabredata) > 0){
		for($sab = 0; $sab < count($sabredata); $sab++){
$htmlres .= '<div class="" id="flight_template">
	<div class="listing-offlight">
		<div class="row">
			<div class="col-lg-12">
				<div class="media">
					<div class="media-left">
						<a href="#"><img class="media-object" src="images/airlines_logos/'.$sabredata[$sab]['logoname'].'.gif" alt="..."></a>
					</div>
					<div class="media-body">
						<h4 class="media-heading flt-heading"><span class="aircompany">'.$sabredata[$sab]['aircompany'].'</span></h4>
						<table class="flights-timetable">
							<tr>
								<td><span class="fa fa-plane font18 fa-rotate-45"></span></td>
								<td><span class="departure_origin_time">'.$sabredata[$sab]['departure_origin_time'].'</span> <span class="from_code">ISB</span></td>
								<td><span class="arrival_destination_time">'.$sabredata[$sab]['arrival_destination_time'].'</span> <span class="to_code">YYZ</span></td>
								<td>1 Stop(Doha)</td>
							</tr>
							<tr>
								<td><span class="fa fa-plane font18 fa-rotate-225"></span></td>
								<td><span class="departure_destination_time">'.$sabredata[$sab]['departure_destination_time'].'</span> <span class="to_code">ISB</span></td>
								<td><span class="arrival_origin_time">'.$sabredata[$sab]['arrival_origin_time'].'</span> <span class="from_code">YYZ</span></td>
								<td>1 Stop(Doha)</td>
							</tr>
						</table>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12 pad7LR">
				<div class="inner-flight-container">
					<table class="ft-price-table">
						<tr class="gokuest_father">
							<td><img src="images/logo.png"></td>
							<td><span class="gokuest_price">'.$sabredata[$sab]['price'].' Naira</span></td>
						</tr>
						<tr class="travelpaddy_father">
							<td><a href="https://travelpaddy.com"><img src="images/flights/travelpaddy.png"></a></td>
							<td><a href="https://travelpaddy.com"><span class="travelpaddy_price">210,000 Naira</span></a></td>
						</tr>
						<tr class="travelbeta_father">
							<td><a href="https://www.travelbeta.com/"><img src="images/flights/beta.png"></a></td>
							<td><a href="https://www.travelbeta.com/"><span class="travelbeta_price">210,000 Naira</span></a></td>
						</tr>
						<tr class="travelden_father">
							<td><a href="https://travelden.com/"><img src="images/flights/travelden.png"></a></td>
						</tr>
						<tr class="wakanow_father">
							<td><a href="https://www.wakanow.com/en-ng/"><img src="images/flights/now.png"></a></td>
							<td><a href="https://www.wakanow.com/en-ng/"><span class="wakanow_price">215,000 Naira</span></a></td>
						</tr>
					</table>
				</div>
			</div>
			<div class="col-md-12 text-center pad7LR">
				<div class="inner-container-book">
					<div class="col-md-4 pull-right">
						<h7><span class="gokuest_price">'.$sabredata[$sab]['price'].'</span><br>GOKUEST</h7>
						<a href="#" class="btn btn-theme btn-flightbook">Book</a>
					</div>
				</div>
			</div>
		</div>
		<a class="common-flightsh" data-toggle="collapse" href="#collapse">Show Flight Details</a>
		
		<!--popup code starts-->
		<div class="row collapse flight_detail" id="collapse">
			<div class="close s_f  s_f_redirect_a3"></div>
			<div class="col-sm-12 padding-tb20">
				<div class="row" style="margin-top: -37px;">
					<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="outbound">outbound</div>
						<div class="shaded">
							<div class="header">
								<div class="pull-left place-name">Lagos - London</div>
								<div class="pull-right flight-date">
									12 October, 2017
								</div>
								<div class="clearfix"></div>
							</div>
							<span class="segmentDate">Departs: <strong>Thursday</strong> 12. October 2017</span>
							<div class="segmentLeg clearfix">
								<div class="legLeft">
									<div class="legLocations">
										<span class="legBigText ">Lagos</span> <span class="legSmallText ">Murtala Muhammad</span>
										<span class="legBigText ">Doha</span> <span class="legSmallText ">Doha</span>
									</div>
									<div class="legTimes">
										<span class="legBigText">17:00</span> <span class="legSmallText">Thursday</span> 
										<span class="legBigText">19:00</span> <span class="legSmallText (undefined)">Thursday</span>
									</div>
									<div class="legIcons">
										<span class="sprite s_f s_f_popup_a1"></span>
										<span class="sprite s_f s_f_popup_a1"></span>
									</div>
									<div class="legPath"><div class="legConnector"></div></div>
								</div>
								<div class="legFlight">
									<div class="triBubble bubGrey">
										<div class="clearfix">
											<img src="https://cdn1.momondo.net/logos/airlines/pa-small.png" alt="airblue" class="legAirline">
											<div class="legPlane"><span class="legBigText">PA205</span> <span class="legSmallText">airblue</span></div>
											<div class="legFlightTime"><span class="legBigText">2h 00m</span></div>
										</div>
									</div>
								</div>
							</div>
							<div class="segmentLeg stop transit clearfix">
								<div class="legLeft">
									<div class="legLocations"></div>
									<div class="legTimes"></div>
									<div class="legIcons"></div>
									<div class="legPath">
										<div class="legWait"></div>
									</div>
								</div>
								<div class="legFlight">
									<div class="triBubble bubRed">
										<div class="legWaitReason">
											<span class="legBigText">Change planes</span>
										</div>
										<div class="legWaitTime">
											<span class="legBigText">2h 00m</span>
										</div>
									</div>
								</div>
							</div>
							<div class="segmentLeg clearfix">
								<div class="legLeft">
									<div class="legLocations">
										<span class="legBigText ">Lagos</span> <span class="legSmallText ">Murtala Muhammad</span>
										<span class="legBigText ">Doha</span> <span class="legSmallText ">Doha</span>
									</div>
									<div class="legTimes">
										<span class="legBigText">17:00</span> <span class="legSmallText">Thursday</span> 
										<span class="legBigText">19:00</span> <span class="legSmallText (undefined)">Thursday</span>
									</div>
									<div class="legIcons">
										<span class="sprite s_f s_f_popup_a1"></span>
										<span class="sprite s_f s_f_popup_a1"></span>
									</div>
									<div class="legPath"><div class="legConnector"></div></div>
								</div>
								<div class="legFlight">
									<div class="triBubble bubGrey">
										<div class="clearfix">
											<img src="https://cdn1.momondo.net/logos/airlines/pa-small.png" alt="airblue" class="legAirline">
											<div class="legPlane">
												<span class="legBigText">PA205</span> 
												<span class="legSmallText">airblue</span>
											</div>
											<div class="legFlightTime"><span class="legBigText">2h 00m</span></div>
										</div>
									</div>
								</div>
							</div>
							<span class="segmentDuration">Total flight time <strong>11h 15m</strong></span>
							<span class="segmentDate legWarning">Arrives: <strong>Friday</strong> 20. October 2017</span>
						</div>
					</div>
					<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="return">return</div>
						<div class="shaded">
							<div class="header">
								<div class="pull-left place-name">London - Lagos</div>
								<div class="pull-right flight-date">
									19 October, 2017.
								</div>
								<div class="clearfix"></div>
							</div>
							<span class="segmentDate">Departs: <strong>Thursday</strong> 19 October, 2017</span>
							<div class="segmentLeg clearfix">
								<div class="legLeft">
									<div class="legLocations">
										<span class="legBigText ">london</span> <span class="legSmallText ">Heathrow</span>
										<span class="legBigText ">Doha</span> <span class="legSmallText ">Doha</span>
									</div>
									<div class="legTimes">
										<span class="legBigText">17:00</span> <span class="legSmallText">Thursday</span>
										<span class="legBigText">19:00</span> <span class="legSmallText (undefined)">Thursday</span>
									</div>
									<div class="legIcons">
										<span class="sprite s_f s_f_popup_a1"></span>
										<span class="sprite s_f s_f_popup_a1"></span>
									</div>
									<div class="legPath"><div class="legConnector"></div></div>
								</div>
								<div class="legFlight">
									<div class="triBubble bubGrey">
										<div class="clearfix">
											<img src="https://cdn1.momondo.net/logos/airlines/pa-small.png" alt="airblue" class="legAirline">
											<div class="legPlane">
												<span class="legBigText">PA205</span> 
												<span class="legSmallText">airblue</span>
											</div>
											<div class="legFlightTime"><span class="legBigText">2h 00m</span></div>
										</div>
									</div>
								</div>
							</div>
							<div class="segmentLeg stop transit clearfix">
								<div class="legLeft">
									<div class="legLocations"></div>
									<div class="legTimes"></div>
									<div class="legIcons"></div>
									<div class="legPath">
										<div class="legWait"></div>
									</div>
								</div>
								<div class="legFlight">
									<div class="triBubble bubRed">
										<div class="legWaitReason">
											<span class="legBigText">Change planes</span>
										</div>
										<div class="legWaitTime">
											<span class="legBigText">2h 00m</span>
										</div>
									</div>
								</div>
							</div>
							<div class="segmentLeg clearfix">
								<div class="legLeft">
									<div class="legLocations">
										<span class="legBigText ">london</span> <span class="legSmallText ">Heathrow</span>
										<span class="legBigText ">Doha</span> <span class="legSmallText ">Doha</span>
									</div>
									<div class="legTimes">
										<span class="legBigText">17:00</span> <span class="legSmallText">Thursday</span> 
										<span class="legBigText">19:00</span> <span class="legSmallText (undefined)">Thursday</span>
									</div>
									<div class="legIcons">
										<span class="sprite s_f s_f_popup_a1"></span>
										<span class="sprite s_f s_f_popup_a1"></span>
									</div>
									<div class="legPath"><div class="legConnector"></div></div>
								</div>
								<div class="legFlight">
									<div class="triBubble bubGrey">
										<div class="clearfix">
											<img src="https://cdn1.momondo.net/logos/airlines/pa-small.png" alt="airblue" class="legAirline">
											<div class="legPlane"><span class="legBigText">PA205</span> <span class="legSmallText">airblue</span></div>
											<div class="legFlightTime"><span class="legBigText">2h 00m</span></div>
										</div>
									</div>
								</div>
							</div>
							<span class="segmentDuration">Total flight time <strong>11h 15m</strong></span>
							<span class="segmentDate legWarning">Arrives: <strong>Friday</strong> 20. October 2017</span>
						</div>
					</div>
				</div>
				<div></div>
			</div>
		</div>
		<!--popup code ends-->

	</div>
</div>';
		}
		
		echo $htmlres;	
		//echo(json_encode($frontend_output));
	}else{
		echo 'NOK';
	}
} else{
	echo '<div id="search_values_response" style="display:block;">You have to fill all fields above before search!</div>';
}

?>