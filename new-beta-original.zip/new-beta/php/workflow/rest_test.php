<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | ~E_NOTICE);
include_once 'workflow/Workflow.php';
include_once 'rest_activities/LeadPriceCalendarActivity.php';

$origin = 'CCU';//filter_input(INPUT_POST, "origin");
$destination = 'DEL';//filter_input(INPUT_POST, "destination");
$departureDate = '2017-09-07';//filter_input(INPUT_POST, "departureDate");
$returnDate = '2017-09-07';
$workflow = new Workflow(new LeadPriceCalendarActivity($origin, $destination, $departureDate, $returnDate));
$result = $workflow->runWorkflow();
echo "<pre>"; print_r($result);exit;
/*$LeadPriceCalendar = $result->getResult("LeadPriceCalendar");
if($LeadPriceCalendar->status == 'Complete'){
	$data = $result->getResult("BargainFinderMax")->OTA_AirLowFareSearchRS->PricedItineraries->PricedItinerary;
	if(count($data) > 0){
		foreach($data as $arrData){
			$price_scraped = $arrData->AirItineraryPricingInfo[0]->ItinTotalFare->TotalFare->Amount;
			$price_scraped_currencycode = $arrData->AirItineraryPricingInfo[0]->ItinTotalFare->TotalFare->CurrencyCode;
			$departure_origin = $arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment[0]->DepartureDateTime;
			
			$FlightSegment = $arrData->AirItinerary->OriginDestinationOptions->OriginDestinationOption[0]->FlightSegment;
			foreach($FlightSegment as $arrFlightSegment){
				echo $arrFlightSegment->ArrivalDateTime."-----";
			}
		}
	}
}*/
$data = $result->getResult("BargainFinderMax")->OTA_AirLowFareSearchRS->PricedItineraries->PricedItinerary;
echo "<pre>"; print_r($data[0]);exit;
//echo "<pre>"; print_r($data[0]->AirItineraryPricingInfo);exit;
ob_start();
var_dump($result);
$dump = ob_get_clean();
echo $dump;
flush();
?>