<?php
interface Activity {

    function run(&$sharedContext);
}
