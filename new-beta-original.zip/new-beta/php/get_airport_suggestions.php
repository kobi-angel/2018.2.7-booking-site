<?php
// Utf-8 Header
header('Content-Type: text/html; charset=utf-8');

// Error Reporting
error_reporting(E_ERROR | E_WARNING | E_PARSE);

// Include DB connection
require_once('db.php');
// Include the file with functions
require_once("haam_functions.php"); 


// Test
//echo '<div class="suggestion">We are here </div>'; # Test
	
	 	
	// Check if already exist records in the DB for that search values
	//-----------------------------------------------------------------
	$query_get_airport_suggestions = "SELECT * FROM airports WHERE cityName LIKE '%".$_POST['my_input_value']."%' OR name LIKE '%".$_POST['my_input_value']."%' ORDER BY cityName";
	
	$result_get_airport_suggestions = mysqli_query($conn, $query_get_airport_suggestions) or die(mysqli_error($conn));
	
	$number_get_airport_suggestions = mysqli_num_rows($result_get_airport_suggestions);
	
	// Test
	//echo '<div class="suggestion">'.$number_get_airport_suggestions.'</div>'; # Test
	
	// If records are available, will output them
	//--------------------------------------------------
	if($number_get_airport_suggestions > 0){

		while($row_get_airport_suggestions = mysqli_fetch_assoc($result_get_airport_suggestions)){
		
			echo '<div class="suggestion">'.$row_get_airport_suggestions['cityName'].','.$row_get_airport_suggestions['countryName'].'-'.$row_get_airport_suggestions['name'].'('.$row_get_airport_suggestions['code'].')</div>'; 
		
		}
		
	}
	else{
	
	}	
