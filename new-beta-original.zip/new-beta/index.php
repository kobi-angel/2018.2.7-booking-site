<?php

header('Content-Type: text/html; charset=utf-8');
error_reporting(E_ERROR | E_WARNING | E_PARSE);


	function random_string($type = 'alnum', $len = 8){					
		switch($type)
		{
			case 'alnum'	:
			case 'numeric'	:
			case 'nozero'	:
			case 'captcha'	:
			
					switch ($type)
					{
						case 'alnum'	:	$pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
							break;
						case 'numeric'	:	$pool = '0123456789';
							break;
						case 'nozero'	:	$pool = '123456789';
							break;
						case 'captcha'	:	$pool = '123456789abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ';
							break;
					}
	
					$str = '';
					for ($i=0; $i < $len; $i++)
					{
						$str .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
					}
					return $str;
			  break;
			case 'unique' : return md5(uniqid(mt_rand()));
			  break;
		}
	}
	

$user_random_id = random_string('unique',64);
//echo $user_random_id;

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="B-verify" content="0e70f9cd8c34158eb1abc0249dcd03184bab4011"/>
  <title>Gokuest</title>
  <link rel="icon" type="image/png"href="images/favicon-32 x 32.png">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-datetimepicker.min.css">
  <link href="css/style.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5V87L2S');</script>
<!-- End Google Tag Manager -->
</head>
<script language="JavaScript" src="http://js.maxmind.com/js/apis/geoip2/v2.1/geoip2.js"></script>
<script src="https://gokuestng.pushify.com/script.js?category=5929d04d41b7b4285e07e3a2"></script>
<body>
<div id="loader"><img src="images/logo.png" alt="Gokuest-Logo">Loading...</div>
<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbarCollapse" aria-expanded="false">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#" title="Gokuest">
      	<img src="images/logo.png" alt="Gokuest-logo">
      </a>
    </div>
    <!-- Collect the nav links for toggling -->
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#" title="Flights"><i class="fa fa-plane" aria-hidden="true"></i> Flights</a></li>
        <li><a href="hotel.php" title="Hotels"><i class="fa fa-bed" aria-hidden="true"></i> Hotels</a></li>
        <li><a href="#" title="Cars"><i class="fa fa-car" aria-hidden="true"></i> Cars</a></li>
        <li><a href="#" title="Tours"><i class="fa fa-suitcase" aria-hidden="true"></i> Tours</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container -->
</nav>

<section class="booking-section">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div class="weather-container">
					<div class="weatherBox">
						<h3 id="weatherName"></h3>
						<p><img id="weatherImg" src="">&nbsp;<span id="weatherCelsius"></span></p>
						<h4 id="weatherCloudiness"></h4>
					</div>
				</div>


				<h1>Find &amp; Compare Flight Prices</h1>
				<div class="home-page-form-wrapper">
				  <!-- Round tabs -->
				  <ul class="nav nav-tabs trip-tabs" role="tablist">
				    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Round Trip</a></li>
				    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">One way</a></li>
				    <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">Multi-City</a></li>
				  </ul>
				  <!-- Round Tab panes -->
				  <div class="tab-content">
				    <div role="tabpanel" class="tab-pane active in fade" id="home">
				    	<div class="form-section">
                <div class="row">
                  <form action="search.php" method="post">
                  
						  <input type="hidden" id="flights_system" name="flights_system" value="travelpaddy" />
						  <input type="hidden" id="user_random_id" name="user_random_id" value="<?php echo $user_random_id ?>" />
						  <input type="hidden" id="type_of_trip" name="type_of_trip" value="return" />
						  
                    <div class="col-sm-4 col-md-2">
                      <div class="marg-t-20 form-group tp-autocomplete">
                         <input type="text" class="form-control find-input my-input-from" id="from" name="from" placeholder="Origin" autocomplete="off" required>
                         <div id="search_response_from" class="from_to_suggestions"></div>
                      </div>
                    </div>
                    <div class="col-sm-4 col-md-2">
                      <div class="marg-t-20 form-group tp-autocomplete">
                      <input type="text" class="form-control find-input find-input-line my-input-to" id="to" name="to" placeholder="Destination" autocomplete="off" required>
                      <div id="search_response_to" class="from_to_suggestions"></div>
                      </div>
                    </div>
                    <div class="col-sm-4 col-md-2">
                      <div class="marg-t-20 form-group">
                        <div class="input-group find-input-group date" id="datepicker1">
                        	<span class="input-group-addon">
                        		<i class="fa fa-calendar-o"></i>
                        	</span>
                          <input type="text" class="form-control find-input" id="check_in" name="check_in" placeholder="Depart" required>                        
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-4 col-md-2">
                      <div class="marg-t-20 form-group">
                        <div class="input-group find-input-group date" id="datepicker2">
                        	<span class="input-group-addon">
                        		<i class="fa fa-calendar-o"></i>
                        	</span>
                          <input type="text" class="form-control find-input" id="check_out" name="check_out" placeholder="Return" required>                          
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-4 col-md-2">
                    <div class="form-group marg-t-20">
                        <div class="cabin-wrapper">
                          <input value="<?php if(isset($_POST['TargetValSet'])) echo $_POST['TargetValSet']; ?>" type="text" class="form-control find-input find-input-line" placeholder="Passenger, Cabin" id="TargetValSet" name="TargetValSet">
                          <div class="cabin-design">
                                                    <div class="row">
                                                        <div class="col-xs-4 mt8">Cabin</div>
                                                        <div class="col-xs-8">
                                                            <select class="form-control" id="CabinSet">
																					 <option>Economy</option>
																					 <option>Premium</option>
                                                                <option>Business</option>
                                                                <option>First</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <!-- //adult -->
                                                    <div class="row mt10">
                                                        <div class="col-xs-4 mt5">Adult</div>
                                                        <div class="col-xs-5">
                                                            <div class="input-group input-group-sm">
                                                          <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button" data-counting="minus" data-person="Adult">
                                                                <span class="glyphicon glyphicon-minus"></span>
                                                            </button>
                                                          </span>
                                                          <input type="text" class="form-control adult-field" placeholder="0" data-choosen="Adult">
                                                          <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button" data-counting="plus" data-person="Adult">
                                                                <span class="glyphicon glyphicon-plus"></span>
                                                            </button>
                                                          </span>
                                                        </div>
                                                        </div>
                                                        <div class="col-xs-3 mt5">12+</div>
                                                    </div>
                                                    <!-- //child -->
                                                    <div class="row mt10">
                                                        <div class="col-xs-4 mt5">Children</div>
                                                        <div class="col-xs-5">
                                                            <div class="input-group input-group-sm">
                                                          <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button" data-counting="minus" data-person="Children">
                                                                <span class="glyphicon glyphicon-minus"></span>
                                                            </button>
                                                          </span>
                                                          <input type="text" class="form-control children-field" placeholder="0" data-choosen="Children">
                                                          <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button" data-counting="plus" data-person="Children">
                                                                <span class="glyphicon glyphicon-plus"></span>
                                                            </button>
                                                          </span>
                                                        </div>
                                                        </div>
                                                        <div class="col-xs-3 mt5">2-11</div>
                                                    </div>
                                                    <!-- //infant -->
                                                    <div class="row mt10">
                                                        <div class="col-xs-4 mt5">Infant</div>
                                                        <div class="col-xs-5">
                                                            <div class="input-group input-group-sm">
                                                          <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button" data-counting="minus" data-person="Infant">
                                                                <span class="glyphicon glyphicon-minus"></span>
                                                            </button>
                                                          </span>
                                                          <input type="text" class="form-control infant-field" placeholder="0" data-choosen="Infant">
                                                          <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button" data-counting="plus" data-person="Infant">
                                                                <span class="glyphicon glyphicon-plus"></span>
                                                            </button>
                                                          </span>
                                                        </div>
                                                        </div>
                                                        <div class="col-xs-3 mt5">&#60;2</div>
                                                    </div>
                                                </div>
								</div>
                      </div>
                    </div>
                    <div class="col-sm-4 col-md-2">
                    <button type="submit" class="btn btn-block btn-field-search">
                    Search
                    </button>
                   
                    </div>
                  </form>
                </div>
              </div>
				    </div>
				    <div role="tabpanel" class="tab-pane fade" id="profile">
				    	<div class="well">Coming Soon!</div>
				    </div>
				    <div role="tabpanel" class="tab-pane fade" id="messages">
				    	<div class="well">Coming Soon!</div>
				    </div>
				  </div>
				</div>

				<!-- // -->
				<div class="compare-haeding">
					<h5>Compare vs GOKUEST <small>all | none</small></h5>
					<ul class="compare-list">
						<li>
							<label>
								<input type="checkbox" name="">
								<span></span>
								Travelstart
							</label>
						</li>
						<li>
							<label>
								<input type="checkbox" name="">
								<span></span>
								Wakanow
							</label>
						</li>
						<li>
							<label>
								<input type="checkbox" name="">
								<span></span>
								Travelbeta
							</label>
						</li>
						<li>
							<label>
								<input type="checkbox" name="">
								<span></span>
								Travelfix
							</label>
						</li>
					</ul>
				</div>

			</div>
		</div>
	</div>
</section>

<section class="three-plans">
	<div class="container">
		<div class="row">
			<div class="col-sm-4">
				<div class="three-box">
					<div class="plans-bg" style="background: url(images/pgcontent1.jpg);"></div>
					<div class="three-box-content">						
						<h4>Your flight itinerary, status &amp; much more</h4>
						<a href="#" title="Gokuest Travel">Gokuest Travel</a>
					</div>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="three-box">
					<div class="plans-bg" style="background: url(images/pgcontent2.jpg);"></div>
					<div class="three-box-content">				
						<h4>See the world on your travel budget</h4>
						<a href="#" title="Gokuest Explorer">Gokuest Explorer</a>
					</div>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="three-box">
					<div class="plans-bg" style="background: url(images/pgcontent3.jpg);"></div>
					<div class="three-box-content">							
						<h4>Top Travel Destinations</h4>
						<p>See and Know where to go!</p>
						<a href="#" title="Travel Guide">Travel Guide</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


<section class="area-section">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div class="area-heading">
					<h2>Start Your <span class="text-theme">KUEST</span> Here</h2>
					<h4>Discover Top Destinations</h4>
				</div>
			</div>
		</div>

		<!-- //// -->
		<div class="row">
			<div class="col-sm-12">
				<ul class="tabing-list">
					<li class="active" data-tabing="all">Worldwide</li>
					<li data-tabing="africa">Africa</li>
					<li data-tabing="nigeria">Nigeria</li>
				</ul>
			</div>
			<div class="col-sm-12">
				<ul class="porfolio-list">
					<!-- /1 -->
					<li class="porfolio-w50 porfolio-h550p" data-city="africa">
						<div class="portfolio-bg" style="background: url(images/cities/london.png);"></div>
						<div class="portfolio-inner">
							<h2>London</h2>
							<div class="portfolio-content">
								<h3>Flights from $919</h3>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
							</div>
						</div>
						<a href="#" class="porfolio-sh">View Price</a>
					</li>
					<!-- /2 -->
					<li class="porfolio-w50 porfolio-h275p" data-city="nigeria">
						<div class="portfolio-bg" style="background: url(images/cities/dubai.png);"></div>
						<div class="portfolio-inner">
							<h2>Dubai</h2>
							<div class="portfolio-content">
								<h3>Flights from $919</h3>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
							</div>
						</div>
						<a href="#" class="porfolio-sh">View Price</a>
					</li>
					<li class="porfolio-w50 porfolio-h275p" data-city="africa">
						<div class="portfolio-bg" style="background: url(images/cities/istanbul.png);"></div>
						<div class="portfolio-inner">
							<h2>Istanbul</h2>
							<div class="portfolio-content">
								<h3>Flights from $919</h3>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
							</div>
						</div>
						<a href="#" class="porfolio-sh">View Price</a>
					</li>

					<!-- /3 -->
					<li class="porfolio-w50 porfolio-h275p" data-city="nigeria">
						<div class="portfolio-bg" style="background: url(images/cities/amsterdam.png);"></div>
						<div class="portfolio-inner">
							<h2>Amsterdam</h2>
							<div class="portfolio-content">
								<h3>Flights from $919</h3>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
							</div>
						</div>
						<a href="#" class="porfolio-sh">View Price</a>
					</li>
					<li class="porfolio-w50 porfolio-h550p" data-city="africa" style="float: right">
						<div class="portfolio-bg" style="background: url(images/cities/bangok.png);"></div>
						<div class="portfolio-inner">
							<h2>Bangok</h2>
							<div class="portfolio-content">
								<h3>Flights from $919</h3>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
							</div>
						</div>
						<a href="#" class="porfolio-sh">View Price</a>
					</li>
					<li class="porfolio-w50 porfolio-h275p" data-city="nigeria">
						<div class="portfolio-bg" style="background: url(images/cities/lahore.png);"></div>
						<div class="portfolio-inner">
							<h2>Lahore</h2>
							<div class="portfolio-content">
								<h3>Flights from $919</h3>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
							</div>
						</div>
						<a href="#" class="porfolio-sh">View Price</a>
					</li>

					<!-- /5 -->
					<li class="porfolio-w50 porfolio-h275p" data-city="nigeria">
						<div class="portfolio-bg" style="background: url(images/cities/newyork.png);"></div>
						<div class="portfolio-inner">
							<h2>New York</h2>
							<div class="portfolio-content">
								<h3>Flights from $919</h3>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
							</div>
						</div>
						<a href="#" class="porfolio-sh">View Price</a>
					</li>
					<li class="porfolio-w50 porfolio-h275p" data-city="nigeria">
						<div class="portfolio-bg" style="background: url(images/cities/capetown.png);"></div>
						<div class="portfolio-inner">
							<h2>Capetown</h2>
							<div class="portfolio-content">
								<h3>Flights from $919</h3>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
							</div>
						</div>
						<a href="#" class="porfolio-sh">View Price</a>
					</li>

					<!-- /6 -->
					<li class="porfolio-w100 porfolio-h550p" data-city="africa">
						<div class="portfolio-bg" style="background: url(images/cities/paris.png);"></div>
						<div class="portfolio-inner">
							<h2>Paris</h2>
							<div class="portfolio-content">
								<h3>Flights from $919</h3>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
								<p><a href="#">Flights from $919</a></p>
							</div>
						</div>
						<a href="#" class="porfolio-sh">View Price</a>
					</li>
				</ul>			
			</div>
		</div>
	</div>
</section>


<section class="clients-logo">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<h3>Find cheap flights from hundreds of airlines and travel agents</h3>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-6 col-sm-4 col-md-2">
				<div class="airlines-box">
					<a href="#"><img src="images/clients/air-asia.png" alt="Air-Asia"></a>
				</div>
			</div>
			<div class="col-xs-6 col-sm-4 col-md-2">
				<div class="airlines-box">
					<a href="#"><img src="images/clients/japan-airlines.png" alt="Japan-Airlines"></a>
				</div>
			</div>
			<div class="col-xs-6 col-sm-4 col-md-2">
				<div class="airlines-box">
					<a href="#"><img src="images/clients/emirates.png" alt="Emirates"></a>
				</div>
			</div>
			<div class="col-xs-6 col-sm-4 col-md-2">
				<div class="airlines-box">
					<a href="#"><img src="images/clients/dragonair.png" alt="Dragonair"></a>
				</div>
			</div>
			<div class="col-xs-6 col-sm-4 col-md-2">
				<div class="airlines-box">
					<a href="#"><img src="images/clients/turkish-airkines.png" alt="Turkish-Airkines"></a>
				</div>
			</div>
			<div class="col-xs-6 col-sm-4 col-md-2">
				<div class="airlines-box">
					<a href="#"><img src="images/clients/qantas.png" alt="Qantas"></a>
				</div>
			</div>
		</div>
	</div>
</section>



<footer>
	<div class="container">
		<div class="row">
			<div class="col-sm-4 col-lg-5">
				<ul>
					<li><a href="#" title="About GoKuest">About GoKuest</a></li>
					<li><a href="#" title="GoKuest on Mobile">GoKuest on Mobile</a></li>
					<li><a href="#" title="Careers">Careers</a></li>
				</ul>
			</div>
			<div class="col-sm-4 col-lg-5">
				<ul>
					<li><a href="#" title="FAQ">FAQ</a></li>
					<li><a href="#" title="Hotel Operations">Hotel Operations</a></li>
					<li><a href="#" title="Terms and Conditions">Terms and Conditions</a></li>
				</ul>
			</div>
			<div class="col-sm-4 col-lg-2">
				<ul>
					<li><p>Country / Currency</p></li>
				</ul>
				<div class="footer-select">
					<select>
						<option>Negeria / Naira</option>
						<option>England / Dollar</option>
						<option>America / Dollar</option>
					</select>
				</div>
			</div>
		</div>
		<!-- // -->
		<div class="row">
			<div class="col-sm-12">
				<h3>
					Search cheap flights with GOKUEST. Find the cheapest airline tickets for all the top airlines around the world and the top international flight routes. We search travel sites to help you find and book the flight that suits you best.
				</h3>
				<div class="social-icons">
					<h4>Socialize with us</h4>
					<a href="#" title="Facebook" target="_blank"><span class="fa fa-facebook"></span></a>
					<a href="#" title="Twitter" target="_blank"><span class="fa fa-twitter"></span></a>
					<a href="#" title="Youtube" target="_blank"><span class="fa fa-youtube"></span></a>
					<a href="#" title="Instagram" target="_blank"><span class="fa fa-instagram"></span></a>
				</div>
			</div>
		</div>
		<!-- // -->
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2">
				<hr>
				<h5>
					GOKUEST is part of the Virgo group a market leader in Online travel and related services
				</h5>
			</div>
		</div>
	</div>
</footer>

<!-- //onclick then go to top on page -->
<a class="gototop" title="Go to top" href="#">
	<span class="fa fa-arrow-circle-up"></span>
</a>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.1.12.4.min.js"></script>
<script src="js/smoothscroll.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Datepicker -->
<script type="text/javascript" src="js/moment.js"></script>
<script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>

<!-- Common JS -->
<script src="js/common.js"></script>
<script src='//vws.responsivevoice.com/v/e?key=OZUmHffv'></script>
<!-- Autocomplete JS -->
   <script>
   // ToondBad
   function loaderImage(q) {
            var url = "https://pixabay.com/api/?";
            var key = "5708871-4395043ecb88b99f3ac63f582";
            var finalurl = url+"key="+key+"&q="+q+"&image_type=photo";
			//alert(finalurl);

            $.getJSON(finalurl,null)
              .done(function (data) {
                  // alert(JSON.stringify(data));
                  	if(data.hits){
	                  var item = data.hits[0];
	                  $(".booking-section").css('background',"url('"+ item.webformatURL+"')");
	                  $(".booking-section").css('background-size',"cover");
          			}
                  /*$.each(data.hits, function (i, item) {
			          console.log("=========== start ===========");
			          console.log(item);
			          console.log("=========== end ===========");
                      //$(".booking-section").css('background',"url('"+ item.previewURL+"')");
			          
                      $("<img>").attr("src", item.userImageURL).appendTo("#images");
                      if (i === 2) {
                          return false;
                      }
                  });*/
              });
        }
    function get_airport_suggestions(my_input_value, from_to_marker){
        $.ajax({
            type: "POST",
            url: 'php/get_airport_suggestions.php',
            data: {my_input_value: my_input_value},
            success: function( response ) {                          
                $('#search_response_'+from_to_marker).html(response).addClass('open');
                from_to_marker = '';
                $('.open .suggestion').click(function(e) {
                    suggestion_value = $(this).html();
                    $(this).parents('.tp-autocomplete').find('input').attr('title',suggestion_value).val(suggestion_value);
                    $(this).parent().removeClass('open');
					// ToondBad 6/21/2017
					//alert(suggestion_value);
					
					var q = suggestion_value.substring(0,suggestion_value.indexOf(","));
					loaderImage(q);
					
					
                });
            }
        });
    }
       
    $('document').ready( function(){
    
        $(document).click(function(e) {
          if (!$(e.target).is('.my-input-from, #search_response_from *')) {
             $('#search_response_from').removeClass('open');
             if($('.my-input-from').val() == my_input_from_value){
                $('.my-input-from').val('');
             }
          }
        });

        $(document).click(function(e) {
          if (!$(e.target).is('.my-input-to, #search_response_to *')) {
             $('#search_response_to').removeClass('open');
             if($('.my-input-to').val() == my_input_to_value){
                $('.my-input-to').val('');
             }             
          }
        });
        
        my_input_from_value= '';
        my_input_to_value= '';    
        my_input_from_counter = 0;
        my_input_to_counter = 0;
        from_to_marker = '';
      $('.my-input-from').bind('input', function() {
            my_input_from_counter = $('.my-input-from').val().length;
         //alert(my_input_from_counter);
		 // ToondBad
		 //alert();
         if(my_input_from_counter >= 3){
                my_input_from_value = $('.my-input-from').val();
                from_to_marker = 'from';
                get_airport_suggestions(my_input_from_value, from_to_marker);
         }
         else{
                $('.my-input-from').next().removeClass('open');
         }
        
      });
      
      $('.my-input-to').bind('input', function() {
            my_input_to_counter = $('.my-input-to').val().length;
            //alert(my_input_to_counter);
         if(my_input_to_counter >= 3){
                my_input_to_value = $('.my-input-to').val();
                from_to_marker = 'to';
                get_airport_suggestions(my_input_to_value, from_to_marker);
         }
         else{
                $('.my-input-to').next().removeClass('open');
         }                     
      }); 
      
   });            
   </script>
   <script>  
    
function addCommas(str) {
    var parts = (str + "").split("."),
        main = parts[0],
        len = main.length,
        output = "",
        first = main.charAt(0),
        i;

    if (first === '-') {
        main = main.slice(1);
        len = main.length;    
    } else {
        first = "";
    }
    i = len - 1;
    while(i >= 0) {
        output = main.charAt(i) + output;
        if ((len - i) % 3 === 0 && i > 0) {
            output = "," + output;
        }
        --i;
    }
    // put sign back
    output = first + output;
    // put decimal part back
    if (parts.length > 1) {
        output += "." + parts[1];
    }
    return output;
}    
    
        $(document).ready( function(){
            $('#flight_template_father').hide();
            $('#search_values_response').slideUp();
            // We send form data for processing
            //-------------------------------------          
            $('#submit').click(function(){
                var form = $('#search_form');
                $('.cabin-wrapper').removeClass('open-cabin');
                if($('#from').val() != '' && $('#to').val() != '' && $('#check_in').val() != '' && $('#check_out').val() != '' && $('#TargetValSet').val() != ''){
                    $('#loader').fadeIn('slow');
                    $('.kiss').remove();
                    if($('#search_values_response').hasClass('opened')){
                        $('#search_values_response').slideUp('slow').removeClass('opened');
                    }
                    $.ajax( {
                        type: "POST",
                        url: form.attr( 'action' ),
                        data: form.serialize(),
                        success: function( response ) {
                          
                        if(response == 'NOK'){
                            $('#loader').fadeOut('slow', function(){
                                $('#search_response').html('<div class="sorry" style="text-align:center;color:orangered;font-size:17px">Sorry. The flight option you are trying to book is not available. This usually occurs in case of limited seats being available or temporary non connectivity with the airline reservation system. Please, try again using a different date combination OR after a little while.</div>');
                            });
                          }
                          else{
                              $('#loader').fadeOut('slow', function(){
                                  //$('#search_response').html(response);
                                  
                                  // Transform json php output to array
                                    frontend_array = jQuery.parseJSON( response );

                                    for (var i = 0; i < frontend_array.length; i++) {
                                    //function display_flights(i){     
                                         console.log('id: ' + frontend_array[i].id);
                                         
                                         $('#flight_template').clone(true).attr('id',frontend_array[i].id).addClass('kiss').appendTo('#chorni');
                                         //$('#chorni').last().attr('id',frontend_array[i].id);
                                         $('#'+frontend_array[i].id+' .gokuest_price').text(addCommas(frontend_array[i].price));
                                         $('#'+frontend_array[i].id+' .aircompany').text(frontend_array[i].aircompany);
                                         $('#'+frontend_array[i].id+' .from_code').text(frontend_array[i].from_code);
                                         $('#'+frontend_array[i].id+' .to_code').text(frontend_array[i].to_code);
                                         $('#'+frontend_array[i].id+' .departure_origin_time').text(frontend_array[i].departure_origin_time);
                                         $('#'+frontend_array[i].id+' .arrival_destination_time').text(frontend_array[i].arrival_destination_time);
                                         $('#'+frontend_array[i].id+' .arrival_origin_time').text(frontend_array[i].arrival_origin_time);
                                         $('#'+frontend_array[i].id+' .departure_destination_time').text(frontend_array[i].departure_destination_time);
                                         
                                         $('#'+frontend_array[i].id+' .common-flightsh').attr('href','#collapse'+frontend_array[i].id);
                                         $('#'+frontend_array[i].id+' .collapse').attr('id','collapse'+frontend_array[i].id);
                                         //i++;
                                    //}     
                                    }
                                    
                                    //i = 0;
                                    //display_flights(i);
                                    
                                    setTimeout(function(){
                                        
                                        if(i<frontend_array.length){
                                            //display_flights(i);
                                        }                                            
                                    }, 511);
                                  
                              });
                          }
                        }
                    });
                }
                else{
                    $('#search_values_response').slideDown('slow').addClass('opened');    
                }
            return false;        
            });
        
        });        
    </script>
   

<!-- <script>
var onSuccess = function(location){
  alert(
      "Lookup successful:\n\n"
      + JSON.stringify(location, undefined, 4)
  );
};
 
var onError = function(error){
  alert(
      "Error:\n\n"
      + JSON.stringify(error, undefined, 4)
  );
};
 
geoip2.city(onSuccess, onError);
</script> -->


</body>
</html>