<html>

<head>
    <style type="text/css">
        body {
            font-family: sans-serif;
            font-size: 14px;
        }
    </style>

    <title>Google Maps JavaScript API v3 Example: Places Autocomplete</title>


</head>

<body>
    <input id="searchInput" class="controls" type="text" placeholder="Enter a location">
</body>
<script>
    function initMap() {
        var input = document.getElementById('searchInput');
        var autocomplete = new google.maps.places.Autocomplete(input);
    }
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB-N1RhnBC941h-6Cs5h2PXrTrVIWx4Xmk&libraries=places&callback=initMap" async defer></script>

</html>