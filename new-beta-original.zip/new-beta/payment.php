<?php
   header('Content-Type: text/html; charset=utf-8');
   error_reporting(E_ERROR | E_WARNING | E_PARSE);
   						function random_string($type = 'alnum', $len = 8){
   		switch($type)
   		{
   				case 'alnum'	:
   				case 'numeric'	:
   				case 'nozero'	:
   				case 'captcha'	:
   			
   					switch ($type)
   					{
   								case 'alnum'	:	$pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
   							break;
   								case 'numeric'	:	$pool = '0123456789';
   							break;
   								case 'nozero'	:	$pool = '123456789';
   							break;
   								case 'captcha'	:	$pool = '123456789abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ';
   							break;
   					}
   	
   					$str = '';
   					for ($i=0; $i < $len; $i++)
   					{
   						$str .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
   					}
   					return $str;
   			break;
   			case 'unique' : return md5(uniqid(mt_rand()));
   			break;
   		}
   	}
   	
   $user_random_id = random_string('unique',64);
   //echo $user_random_id;
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Gokuest</title>
      <link rel="icon" type="image/png"href="images/favicon-32 x 32.png">
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="css/bootstrap-datetimepicker.min.css">
      <link href="css/style.css" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
      <!-- Google Tag Manager -->
      <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
         new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
         j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
         'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
         })(window,document,'script','dataLayer','GTM-5V87L2S');
      </script>
      <!-- End Google Tag Manager -->
   </head>
   <script language="JavaScript" src="http://js.maxmind.com/js/apis/geoip2/v2.1/geoip2.js"></script>
   <script src="https://gokuestng.pushify.com/script.js?category=5929d04d41b7b4285e07e3a2"></script>
   <body>
      <div id="loader"><img src="images/logo.png" alt="Gokuest-Logo">Loading...</div>
      <nav class="navbar navbar-default navbar-fixed-top">
         <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
               <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbarCollapse" aria-expanded="false">
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               </button>
               <a class="navbar-brand" href="#" title="Gokuest">
               <img src="images/logo.png" alt="Gokuest-logo">
               </a>
            </div>
            <!-- Collect the nav links for toggling -->
            <div class="collapse navbar-collapse" id="navbarCollapse">
               <ul class="nav navbar-nav navbar-right">
                  <li><a href="index.php" title="Flights"><i class="fa fa-plane" aria-hidden="true"></i> Flights</a></li>
                  <li><a href="#" title="Hotels" class="active"><i class="fa fa-bed" aria-hidden="true"></i> Hotels</a></li>
                  <li><a href="#" title="Cars"><i class="fa fa-car" aria-hidden="true"></i> Cars</a></li>
                  <li><a href="#" title="Tours"><i class="fa fa-suitcase" aria-hidden="true"></i> Tours</a></li>
               </ul>
            </div>
            <!-- /.navbar-collapse -->
         </div>
         <!-- /.container -->
      </nav>
      <section class="hotelPayment">
         <div class="paymentContainer">
            <div class="col-md-12 mySlides">
               <div class="col-md-7">
                  <h4></h4>
                  <div class="col-md-12 leftContainer">
                     <div class="media">
                        <div class="media-left">
                           <img src="images/hotels/novotel.jpg" class="media-object roomPicture">
                        </div>
                        <div class="media-body">
                           <h4 class="media-heading">Park Inn Hotel</h4>
                           <div class="rating">
                              <span class="selected">&#9734;</span><span class="selected">&#9734;</span><span class="selected">&#9734;</span><span>&#9734;</span><span>&#9734;</span>
                           </div>
                           <p>Bath Rd, Sipson, Heathrow UB7 0DU, United Kingdom </p>
                           <div class="row">
                              <label class="col-md-3">Check in : </label>
                              <span class="col-md-9">Thursday, 25 January 2018</span>
                           </div>
                           <div class="row">
                              <label class="col-md-3">Check out : </label>
                              <span class="col-md-9">Friday, 26 January 2018</span>
                           </div>
                           <div class="row">
                              <label class="col-md-3">Stay : </label>
                              <span class="col-md-9">1 night, 1 room , 2 adults</span>
                           </div>
                           <div class="row">
                              <label class="col-md-3">Neighborhood : </label>
                              <span class="col-md-9">Heathrow, London</span>
                           </div>
                        </div>
                     </div>
                     <div>
                        <label class="amentiesLabel"> Features you'll love </label>
                        <div class="row marB20">
                           <div class="col-md-4">
                              <img src="images/hotels/airplane-.png">
                              <span>Airport Transfer</span>
                           </div>
                           <div class="col-md-4">
                              <img src="images/hotels/underground.png">
                              <span>Near public transportation</span>
                           </div>
                           <div class="col-md-4">
                              <img src="images/hotels/skyline.png">
                              <span>Heart of the City</span>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-md-4">
                              <img src="images/hotels/wifi-connection-signal-symbol.png">
                              <span>Free Wi-Fi in all rooms</span>
                           </div>
                           <div class="col-md-4">
                              <img src="images/hotels/hot-kettle.png">
                              <span>Steamroom</span>
                           </div>
                           <div class="col-md-4">
                              <img src="images/hotels/minisplit.png">
                              <span>Air conditioning</span>
                           </div>
                        </div>
                     </div>
                  </div>
<div class="col-md-12 leftLowerContainer">
<div class="row">
                        <label class="col-md-9 bold">Price </label>
                        <span class="col-md-3 priceBold">AUD 112.41</span>
                     </div>
<div class="row">
                        <label class="col-md-9">Included in price : 20% Tax </label>
                       
                     </div>
<div class="row">
                        <label class="col-md-9">Smart Choice you saved AUD 100 </label>
                        
                     </div>
</div>
               </div>
               <div class="col-md-4 rightWrapper">
                  <div class="col-md-12 rightContainer">
                     <div class="row marT30">
                        <div class="col-sm-5">
                           <div class="check-in-check-out-details">
                              <div class="row">
                                 <div class="col-sm-12">
                                    <span class="title-text">Check-in</span> 
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-sm-4"> 
                                    <span class="big-text">25</span> 
                                 </div>
                                 <div class="col-sm-8 right-content">
                                    <div class="row">
                                       <div class="col-sm-12"> 	
                                          <span class="small-text">Thursday</span> 
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-sm-12"> 
                                          <span>Jan 2018</span> 
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-sm-12"> 
                                    <span class="title-text">from 02:00 PM</span>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-sm-1"> 
                           <i class="right"></i>
                        </div>
                        <div class="col-sm-5">
                           <div class="check-in-check-out-details">
                              <div class="row">
                                 <div class="col-sm-12">
                                    <span class="title-text">Check-out</span>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-sm-4"> 
                                    <span class="big-text">26</span>
                                 </div>
                                 <div class="col-sm-8 right-content">
                                    <div class="row">
                                       <div class="col-sm-12"> 
                                          <span class="small-text">Friday</span> 
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-sm-12"> 
                                          <span>Jan 2018</span> 
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-sm-12">
                                    <span class="title-text">until 12:00 PM</span> 
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="roomDetails">
                        <label class="roomHeading">Your Room Details </label>
                        <div class="row">
                           <label class="col-md-3">Room: </label>
                           <span class="col-md-9">1 x Deluxe Room</span>
                        </div>
                        <div class="row">
                           <label class="col-md-3">Occupancy: </label>
                           <span class="col-md-9">2 adults</span>
                        </div>
                        <div class="row">
                           <label class="col-md-3">Room Size: </label>
                           <span class="col-md-9">30 sq.m.</span>
                        </div>
                        <div class="row">
                           <label class="col-md-3">Policy : </label>
                           <span class="col-md-9">FREE cancellation before 24 January 2018</span>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-12  costingPart">
                     <div class="row">
                        <label class="col-md-9">Original price (1 room x 1 night) </label>
                        <span class="col-md-3 strike">AUD 282.99</span>
                     </div>
                     <div class="row">
                        <label class="col-md-9">Price (1 room x 1 night) </label>
                        <span class="col-md-3">AUD 112.41</span>
                     </div>
                     <div class="row">
                        <label class="col-md-9">Booking fees </label>
                        <span class="col-md-3">FREE</span>
                     </div>
                     <div class="row">
                        <label class="col-md-9">Price</label>
                        <span class="col-md-3 bold">AUD 112.41</span>
                     </div>
                  </div>
               </div>
               <div class="col-md-1 lastArrow">
                  <button class="w3-button w3-black w3-display-right" onclick="plusDivs(1)">&#10095;</button>
               </div>
            </div>
            <div class="col-md-12 mySlides userInfoContainer">
	       <div class="col-md-1 lastArrow">
                  <button class="w3-button w3-black w3-display-left" onclick="plusDivs(1)">&#10094;</button>
               </div>
	       <div class="col-md-11">
               <h4 class="infoHeading">Please fill in your information</h4>
               <div class="row">
                  <div class="col-md-12">
                     <label class="col-md-12">First and Last Name </label>
                     <input type="text" class="col-md-6 infoText" />
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <label class="col-md-12">Email </label>
                     <input type="text" class="col-md-6 infoText" />
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <label class="col-md-12">Mobile Number </label>
                     <input type="number" class="col-md-6 infoText" />
                  </div>
		</div>
		<div class="row">
                  <div class="col-md-12">
                     <label class="col-md-12">Country of residence </label>
                     <select class="col-md-6 infoText" >
                        <option>Australia</option>
                        <option>Nigeria</option>
                        <option>Egypt</option>
                        <option>USA</option>
                     </select>
                  </div>
               </div>
               <div class="row">
			<div class="col-md-12 cc">
                  		<input id="checkBox" type="checkbox"> I'm not staying in any of the rooms on this booking. I'm making this booking for someone else.
               		</div>
		</div>
		 <div class="row">
			<div class="col-md-12">
                                <script src="https://js.paystack.co/v1/inline.js"></script>
				<button type="button" class= "btnPay"onclick="payWithPaystack()">Pay</button>
                                </form>
                               
 <script>
  function payWithPaystack(){
    var handler = PaystackPop.setup({
      key: 'pk_test_73310e40bd8dd2c567c5f804a3913cee53f3a0f7',
      email: 'customer@email.com',
      amount: 10000,
      ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
      metadata: {
         custom_fields: [
            {
                display_name: "Mobile Number",
                variable_name: "mobile_number",
                value: "+2348012345678"
            }
         ]
      },
      callback: function(response){
          alert('success. transaction ref is ' + response.reference);
      },
      onClose: function(){
          alert('window closed');
      }
    });
    handler.openIframe();
  }
</script>  
			</div>
		</div>
</div>
            </div>
         </div>
      </section>
      <footer>
         <div class="container">
            <div class="row">
               <div class="col-sm-4 col-lg-5">
                  <ul>
                     <li><a href="#" title="About GoKuest">About GoKuest</a></li>
                     <li><a href="#" title="GoKuest on Mobile">GoKuest on Mobile</a></li>
                     <li><a href="#" title="Careers">Careers</a></li>
                  </ul>
               </div>
               <div class="col-sm-4 col-lg-5">
                  <ul>
                     <li><a href="#" title="FAQ">FAQ</a></li>
                     <li><a href="#" title="Hotel Operations">Hotel Operations</a></li>
                     <li><a href="#" title="Terms and Conditions">Terms and Conditions</a></li>
                  </ul>
               </div>
               <div class="col-sm-4 col-lg-2">
                  <ul>
                     <li>
                        <p>Country / Currency</p>
                     </li>
                  </ul>
                  <div class="footer-select">
                     <select>
                        <option>Negeria / Naira</option>
                        <option>England / Dollar</option>
                        <option>America / Dollar</option>
                     </select>
                  </div>
               </div>
            </div>
            <!-- // -->
            <div class="row">
               <div class="col-sm-12">
                  <h3>
                     Search cheap flights with GOKUEST. Find the cheapest airline tickets for all the top airlines around the world and the top international flight routes. We search travel sites to help you find and book the flight that suits you best.
                  </h3>
                  <div class="social-icons">
                     <h4>Socialize with us</h4>
                     <a href="#" title="Facebook" target="_blank"><span class="fa fa-facebook"></span></a>
                     <a href="#" title="Twitter" target="_blank"><span class="fa fa-twitter"></span></a>
                     <a href="#" title="Youtube" target="_blank"><span class="fa fa-youtube"></span></a>
                     <a href="#" title="Instagram" target="_blank"><span class="fa fa-instagram"></span></a>
                  </div>
               </div>
            </div>
            <!-- // -->
            <div class="row">
               <div class="col-sm-8 col-sm-offset-2">
                  <hr>
                  <h5>
                     GOKUEST is part of the Virgo group a market leader in Online travel and related services
                  </h5>
               </div>
            </div>
         </div>
      </footer>
      <!-- //onclick then go to top on page -->
      <a class="gototop" title="Go to top" href="#">
      <span class="fa fa-arrow-circle-up"></span>
      </a>
      <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
      <script src="js/jquery.1.12.4.min.js"></script>
      <script src="js/smoothscroll.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- Datepicker -->
      <script type="text/javascript" src="js/moment.js"></script>
      <script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>
      <!-- Common JS -->
      <script src="js/common.js"></script>
      <script src="js/jquery.slides.min.js"></script>
      <script>
         var slideIndex = 1;
         showDivs(slideIndex);
         
         function plusDivs(n) {
          	showDivs(slideIndex += n);
         }
         
         function showDivs(n) {
          		var i;
          		var x = document.getElementsByClassName("mySlides");
          		if (n > x.length) {slideIndex = 1}    
          		if (n < 1) {slideIndex = x.length}
          		for (i = 0; i < x.length; i++) {
             			x[i].style.display = "none";  
          		}
          		x[slideIndex-1].style.display = "block";  
         }
      </script>
   </body>
</html>