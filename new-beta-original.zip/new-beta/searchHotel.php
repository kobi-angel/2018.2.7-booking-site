

<?php
   header('Content-Type: text/html; charset=utf-8');
   error_reporting(E_ERROR | E_WARNING | E_PARSE);
                     function random_string($type = 'alnum', $len = 8){
         switch($type)
         {
               case 'alnum'   :
               case 'numeric' :
               case 'nozero'  :
               case 'captcha' :
            
                  switch ($type)
                  {
                           case 'alnum'   :  $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                        break;
                           case 'numeric' :  $pool = '0123456789';
                        break;
                           case 'nozero'  :  $pool = '123456789';
                        break;
                           case 'captcha' :  $pool = '123456789abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ';
                        break;
                  }
      
                  $str = '';
                  for ($i=0; $i < $len; $i++)
                  {
                     $str .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
                  }
                  return $str;
            break;
            case 'unique' : return md5(uniqid(mt_rand()));
            break;
         }
      }
      
   $user_random_id = random_string('unique',64);
   //echo $user_random_id;
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Gokuest</title>
      <link rel="icon" type="image/png"href="images/favicon-32 x 32.png">
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="css/bootstrap-datetimepicker.min.css">
      <link href="css/style.css" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
      <!-- Google Tag Manager -->
      <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
         new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
         j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
         'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
         })(window,document,'script','dataLayer','GTM-5V87L2S');
      </script>
      <!-- End Google Tag Manager -->
   </head>
   <script language="JavaScript" src="http://js.maxmind.com/js/apis/geoip2/v2.1/geoip2.js"></script>
   <script src="https://gokuestng.pushify.com/script.js?category=5929d04d41b7b4285e07e3a2"></script>
   <body>
      <div id="loader"><img src="images/logo.png" alt="Gokuest-Logo">Loading...</div>
      <nav class="navbar navbar-default navbar-fixed-top">
         <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
               <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbarCollapse" aria-expanded="false">
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               </button>
               <a class="navbar-brand" href="#" title="Gokuest">
               <img src="images/logo.png" alt="Gokuest-logo">
               </a>
            </div>
            <!-- Collect the nav links for toggling -->
            <div class="collapse navbar-collapse" id="navbarCollapse">
               <ul class="nav navbar-nav navbar-right">
                  <li><a href="index.php" title="Flights"><i class="fa fa-plane" aria-hidden="true"></i> Flights</a></li>
                  <li><a href="#" title="Hotels" class="active"><i class="fa fa-bed" aria-hidden="true"></i> Hotels</a></li>
                  <li><a href="#" title="Cars"><i class="fa fa-car" aria-hidden="true"></i> Cars</a></li>
                  <li><a href="#" title="Tours"><i class="fa fa-suitcase" aria-hidden="true"></i> Tours</a></li>
               </ul>
            </div>
            <!-- /.navbar-collapse -->
         </div>
         <!-- /.container -->
      </nav>
      <section class="hotelContainerSearch">
         <div>
            <div class="container">
               <div class="row">
                  <div class="col-sm-12">
                     <div class="home-page-form-wrapper">
                        <!-- Round Tab panes -->
                        <div class="tab-content">
                           <div role="tabpanel" class="tab-pane active in fade" id="home">
                              <div class="form-section">
                                 <div class="row">
                                    <form action="search.php" method="post">
                                       <input type="hidden" id="flights_system" name="flights_system" value="travelpaddy" />
                                       <input type="hidden" id="user_random_id" name="user_random_id" value="<?php echo $user_random_id ?>" />
                                       <input type="hidden" id="type_of_trip" name="type_of_trip" value="return" />
                                       <div class="col-sm-4 col-md-3">
                                          <div class="marg-t-20 form-group tp-autocomplete">
                                             <input type="text" class="form-control find-input find-input-line my-input-to" id="place" name="to" placeholder="London,United Kingdom" autocomplete="off" required>
                                             <div id="search_response_to" class="from_to_suggestions"></div>
                                          </div>
                                       </div>
                                       <div class="col-sm-4 col-md-2">
                                          <div class="marg-t-20 form-group">
                                             <div class="input-group find-input-group date" id="datepicker1">
                                                <span class="input-group-addon">
                                                <i class="fa fa-calendar-o"></i>
                                                </span>
                                                <input type="text" class="form-control find-input" id="check_in" name="check_in" placeholder="Check in" required>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-sm-4 col-md-2">
                                          <div class="marg-t-20 form-group">
                                             <div class="input-group find-input-group date" id="datepicker2">
                                                <span class="input-group-addon">
                                                <i class="fa fa-calendar-o"></i>
                                                </span>
                                                <input type="text" class="form-control find-input" id="check_out" name="check_out" placeholder="Check out" required>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-sm-4 col-md-3">
                                          <div class="form-group marg-t-20">
                                             <div class="cabin-wrapper">
                                                <input type="text" class="form-control find-input find-input-line" value="2 adults in 1 room"  id="RoomTarget" name="RoomTarget" readonly>
                                                <div class="cabin-design">
                                                   <div id="roomWrapper">
                                                      <div class="roomCont firstElement">
                                                         <div class="row">
                                                            <div class="col-xs-12 mt8 box" id="roomCount">Room 1</div>
                                                         </div>
                                                         <div class="row mt10">
                                                            <div class="col-xs-4 mt5">Adult</div>
                                                            <div class="col-xs-5">
                                                               <div class="input-group input-group-sm">
                                                                  <span class="input-group-btn">
                                                                  <button class="btn btn-default" type="button" data-counting="minus" data-person="Adult">
                                                                  <span class="glyphicon glyphicon-minus"></span>
                                                                  </button>
                                                                  </span>
                                                                  <input type="text" class="form-control adult-field" placeholder="0" data-choosen="Adult">
                                                                  <span class="input-group-btn">
                                                                  <button class="btn btn-default" type="button" data-counting="plus" data-person="Adult">
                                                                  <span class="glyphicon glyphicon-plus"></span>
                                                                  </button>
                                                                  </span>
                                                               </div>
                                                            </div>
                                                            <div class="col-xs-3 mt5">12+</div>
                                                         </div>
                                                         <div class="row mt10">
                                                            <div class="col-xs-4 mt5">Children</div>
                                                            <div class="col-xs-5">
                                                               <div class="input-group input-group-sm">
                                                                  <span class="input-group-btn">
                                                                  <button class="btn btn-default" type="button" data-counting="minus" data-person="Children">
                                                                  <span class="glyphicon glyphicon-minus"></span>
                                                                  </button>
                                                                  </span>
                                                                  <input type="text" class="form-control children-field" placeholder="0" data-choosen="Children">
                                                                  <span class="input-group-btn">
                                                                  <button class="btn btn-default" type="button" data-counting="plus" data-person="Children">
                                                                  <span class="glyphicon glyphicon-plus"></span>
                                                                  </button>
                                                                  </span>
                                                               </div>
                                                            </div>
                                                            <div class="col-xs-3 mt5">2-11</div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                   <div class="row mt10">
                                                      <div class="col-xs-8 col-md-6">
                                                         <button class="btn btn-default" type="button" id="addRoom">
                                                         <span class="glyphicon glyphicon-plus"></span> Add Room
                                                         </button>
                                                      </div>
                                                      <div class="col-xs-8 col-md-6">
                                                         <button class="btn btn-default hide" type="button" id="removeRoom">
                                                         <span class="glyphicon glyphicon-minus"></span> Remove Room
                                                         </button>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-sm-4 col-md-2">
                                          <button type="button"  class="btn btn-block btn-field-search" >
                                          Search
                                          </button>
                                       </div>
                                    </form>
                                 </div>
                              </div>
                           </div>
                           <div role="tabpanel" class="tab-pane fade" id="profile">
                              <div class="well">Coming Soon!</div>
                           </div>
                           <div role="tabpanel" class="tab-pane fade" id="messages">
                              <div class="well">Coming Soon!</div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section class="hotelSearch">
         <div class="col-md-2">
            <div class="filterPanel">
               <div class="eachFilter">
                  <span class="title"> Sort </span>
                  <select>
                     <option> Recommended </option>
                     <option> Cheapest </option>
                     <option> Highest review score </option>
                     <option> Biggest savings </option>
                     <option> Highest star rating </option>
                  </select>
               </div>
               <div class="eachFilter">
                  <span class="title">Hotel Name </span>
                  <div>
                     <input type="text" placeholder"Hotel Name" class="hotelSearchText">
                  </div>
               </div>
               <div class="eachFilter">
                  <span class="title">Price </span>
                  <div class="range-slider">
                     <input class="range-slider__range" type="range" value="1000" min="0" max="5000">
                     <span class="range-slider__value">0</span>
                  </div>
               </div>
               <div class="eachFilter">
                  <span class="title"> Rating </span>
                  <div class="rating">
                     <span class="selected">&#9734;</span><span>&#9734;</span><span>&#9734;</span><span>&#9734;</span><span>&#9734;</span>
                  </div>
               </div>
               <div class="eachFilter">
                  <span class="title"> Guest Rating </span>
                  <div>
                     <div>
                        <input type="checkbox" name="guestRating" value="awesome"><label>9+ Awesome</label>
                     </div>
                     <div>
                        <input type="checkbox" name="guestRating" value="veryGreat"><label>8+ Very Great</label>
                     </div>
                     <div>
                        <input type="checkbox" name="guestRating" value="great"><label>7+ Great</label>
                     </div>
                     <div>
                        <input type="checkbox" name="guestRating" value="okay"><label>6+ Okay</label>
                     </div>
                  </div>
               </div>
               <div class="eachFilter">
                  <span class="title"> Amenities </span>
                  <div>
                     <div>
                        <input type="checkbox" name="amenities" value="ac"><label>Air-conditioned </label>
                     </div>
                     <div>
                        <input type="checkbox" name="amenities" value="airportShuttle"><label>Airport Shuttle</label>
                     </div>
                     <div>
                        <input type="checkbox" name="amenities" value="businessCenter"><label>Business Center</label>
                     </div>
                     <div>
                        <input type="checkbox" name="amenities" value="fitness"><label>Fitness</label>
                     </div>
                     <div>
                        <input type="checkbox" name="amenities" value="internet"><label>Internet</label>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-7 main-container">
            <div class="col-md-12 wrapper">
               <div class="media">
                  <div class="media-left">
                     <div id="slides">
                        <img src="images/hotels/novotel.jpg" class="media-object mySlides">
                        <img src="images/hotels/park-inn.jpg" class="media-object mySlides">
                        <img src="images/hotels/novotel.jpg" class="media-object mySlides">
                        <img src="images/hotels/park-inn.jpg" class="media-object mySlides">
                        <a href="#" class="slidesjs-previous slidesjs-navigation w3-display-left">&#10094;</a>
                        <a href="#" class="slidesjs-next slidesjs-navigation w3-display-right">&#10095;</a>
                     </div>
                  </div>
                  <div class="media-body">
                     <div class="row">
                        <div class="col-md-9">
                           <div>
                              <span class="media-heading">Park Inn Hotel</span>
                              <span id="place">West Drayton</span>
                           </div>
                           <div>
                              <div class="rating">
                                 <span class="selected">&#9734;</span><span class="selected">&#9734;</span><span class="selected">&#9734;</span><span>&#9734;</span><span>&#9734;</span>
                              </div>
                              <span class="ratingReviews"> Good </span>
                              <span class="numberOfRating">(9.0,11,014 reviews)</span>
                           </div>
                           <div class="tagContainer">
                              <div class="tagWrapperBlue">
                                 <span> BEST AIRPORT HOTEL
                                 </span>
                              </div>
                              <div class="tagWrapperGreen">
                                 <span> FAMILY SAVER
                                 </span>
                              </div>
                           </div>
                           <div class="row externalWebsiteWrapper">
                              <div class="col-md-4">
                                 <span class="cost"> $1108</span>
                                 <span class="externalWebsite">Orbitz</span>
                              </div>
                              <div class="col-md-4">
                                 <span class="cost"> $1108</span>
                                 <span class="externalWebsite">CheapTickets</span>
                              </div>
                              <div class="col-md-4">
                                 <span class="cost"> $1108</span>
                                 <span class="externalWebsite">Travelocity</span>
                              </div>
                           </div>
                           <div class="row externalWebsiteWrapper">
                              <div class="col-md-4">
                                 <span class="cost"> $1108</span>
                                 <span class="externalWebsite">Orbitz</span>
                              </div>
                              <div class="col-md-4">
                                 <span class="cost"> $1108</span>
                                 <span class="externalWebsite">CheapTickets</span>
                              </div>
                              <div class="col-md-4">
                                 <span class="cost"> $1108</span>
                                 <span class="externalWebsite">Travelocity</span>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-3">
                           <div class="priceTag">
                              <span class="leastPrice"> $1115 </span>
                              <span class="tag"> Flight+Hotel </span>
                              <span class="leastWebsite">Expedia </span>
                           </div>
                           <div class="viewDeal">
                              <button type="submit" class="greenView" onclick="location.href = 'http://gokuest.com/new-beta/payment.php';"> Book Hotel 
                           </div>
                        </div>
                     </div>
                  </div>
                  <a class="common-flightsh" data-toggle="collapse" href="#collapse" aria-expanded="true">
                  Show Room Details</a>
                  <div class="row hotel_detail collapse" id="collapse" aria-expanded="true" style="">
                     <div class="close s_f  s_f_redirect_a3 close-popup"></div>
                     <div class="col-md-12">
                        <div class="col-md-6">
                           <h5> Hotel Amenities </h5>
                           <div class="col-md-12 amenities">
                              <div class="col-md-6">
                                 <span> Wi-Fi </span>
                              </div>
                              <div class="col-md-6">
                                 <span> Parking </span>
                              </div>
                           </div>
                           <div class="col-md-12 amenities">
                              <div class="col-md-6">
                                 <span> Pool </span>
                              </div>
                              <div class="col-md-6">
                                 <span> Restaurant </span>
                              </div>
                           </div>
                           <div class="col-md-12 amenities">
                              <div class="col-md-6">
                                 <span> Gym </span>
                              </div>
                              <div class="col-md-6">
                                 <span> Roomservice </span>
                              </div>
                           </div>
                           <div class="col-md-12 amenities">
                              <div class="col-md-6">
                                 <span> Pets Allowed </span>
                              </div>
                              <div class="col-md-6">
                                 <span> Handicap access </span>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div>
                              <h5> Check-in </h5>
                              <span>From 2:00 PM</span>
                           </div>
                           <div>
                              <h5> Check-out </h5>
                              <span>Prior to 12:00 PM</span>
                           </div>
                           <div>
                              <h5> General </h5>
                              <p>Room Service , Bar/lounge</p>
                              <p>Cable Satellite TV, Hair Dryer</p>
                              <p>Desk , En Suite, Private Bathroom</p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-md-12 wrapper">
               <div class="media">
                  <div class="media-left">
                     <div  id="slides2">                                                  <img src="images/hotels/novotel.jpg" class="media-object mySlides">
                        <img src="images/hotels/park-inn.jpg" class="media-object mySlides">
                        <img src="images/hotels/novotel.jpg" class="media-object mySlides">
                        <img src="images/hotels/park-inn.jpg" class="media-object mySlides">
                        <a href="#" class="slidesjs-previous slidesjs-navigation w3-display-left">&#10094;</a>
                        <a href="#" class="slidesjs-next slidesjs-navigation w3-display-right">&#10095;</a>
                     </div>
                  </div>
                  <div class="media-body">
                     <div class="row">
                        <div class="col-md-9">
                           <div>
                              <span class="media-heading">Park Inn Hotel</span>
                              <span id="place">West Drayton</span>
                           </div>
                           <div>
                              <div class="rating">
                                 <span class="selected">&#9734;</span><span class="selected">&#9734;</span><span class="selected">&#9734;</span><span>&#9734;</span><span>&#9734;</span>
                              </div>
                              <span class="ratingReviews"> Good </span>
                              <span class="numberOfRating">(9.0,11,014 reviews)</span>
                           </div>
                           <div class="tagContainer">
                              <div class="tagWrapperBlue">
                                 <span> BEST AIRPORT HOTEL
                                 </span>
                              </div>
                              <div class="tagWrapperGreen">
                                 <span> FAMILY SAVER
                                 </span>
                              </div>
                           </div>
                           <div class="row externalWebsiteWrapper">
                              <div class="col-md-4">
                                 <span class="cost"> $1108</span>
                                 <span class="externalWebsite">Orbitz</span>
                              </div>
                              <div class="col-md-4">
                                 <span class="cost"> $1108</span>
                                 <span class="externalWebsite">CheapTickets</span>
                              </div>
                              <div class="col-md-4">
                                 <span class="cost"> $1108</span>
                                 <span class="externalWebsite">Travelocity</span>
                              </div>
                           </div>
                           <div class="row externalWebsiteWrapper">
                              <div class="col-md-4">
                                 <span class="cost"> $1108</span>
                                 <span class="externalWebsite">Orbitz</span>
                              </div>
                              <div class="col-md-4">
                                 <span class="cost"> $1108</span>
                                 <span class="externalWebsite">CheapTickets</span>
                              </div>
                              <div class="col-md-4">
                                 <span class="cost"> $1108</span>
                                 <span class="externalWebsite">Travelocity</span>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-3">
                           <div class="priceTag">
                              <span class="leastPrice"> $1115 </span>
                              <span class="tag"> Flight+Hotel </span>
                              <span class="leastWebsite">Expedia </span>
                           </div>
                           <div class="viewDeal">
                              <button type="submit" class="greenView" onclick="location.href = 'http://gokuest.com/new-beta/payment.php';"> Book Hotel
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         </div>
         <div class="col-md-3">
         <style>
     #map{
       height:400px;
       width:100%;
      }
   </style>
</head>
 <body>
    <div id="map"></div>
    <script>
       function initMap() {
          var options = {
             zoom:8,
             center: {lat: 40.7128, lng: -74.0060}
            }
         
           var map = new google.maps.Map(document.getElementById('map'), options); 

           
           var marker = new google.maps.Marker({
              position:{lat: 40.7484,lng: -73.9857},
              map:map,
              icon:'http://gokuest.com/new-beta/images/map_icon.png'
         }); 

           var infoWindow = new google.maps.InfoWindow({
             content:'<h1>KUEST</h1>'
          });

           marker.addListener('click', function(){
             infoWindow.open(map, marker);
          });
      }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCABsUV0eCHYDSoBWQtULGfwG6lnEY7zIQ&callback=initMap"
    async defer></script
</body>
</html>
         </div>
      </section>
      <footer>
         <div class="container">
            <div class="row">
               <div class="col-sm-4 col-lg-5">
                  <ul>
                     <li><a href="#" title="About GoKuest">About GoKuest</a></li>
                     <li><a href="#" title="GoKuest on Mobile">GoKuest on Mobile</a></li>
                     <li><a href="#" title="Careers">Careers</a></li>
                  </ul>
               </div>
               <div class="col-sm-4 col-lg-5">
                  <ul>
                     <li><a href="#" title="FAQ">FAQ</a></li>
                     <li><a href="#" title="Hotel Operations">Hotel Operations</a></li>
                     <li><a href="#" title="Terms and Conditions">Terms and Conditions</a></li>
                  </ul>
               </div>
               <div class="col-sm-4 col-lg-2">
                  <ul>
                     <li>
                        <p>Country / Currency</p>
                     </li>
                  </ul>
                  <div class="footer-select">
                     <select>
                        <option>Negeria / Naira</option>
                        <option>England / Dollar</option>
                        <option>America / Dollar</option>
                     </select>
                  </div>
               </div>
            </div>
            <!-- // -->
            <div class="row">
               <div class="col-sm-12">
                  <h3>
                     Search cheap flights with GOKUEST. Find the cheapest airline tickets for all the top airlines around the world and the top international flight routes. We search travel sites to help you find and book the flight that suits you best.
                  </h3>
                  <div class="social-icons">
                     <h4>Socialize with us</h4>
                     <a href="#" title="Facebook" target="_blank"><span class="fa fa-facebook"></span></a>
                     <a href="#" title="Twitter" target="_blank"><span class="fa fa-twitter"></span></a>
                     <a href="#" title="Youtube" target="_blank"><span class="fa fa-youtube"></span></a>
                     <a href="#" title="Instagram" target="_blank"><span class="fa fa-instagram"></span></a>
                  </div>
               </div>
            </div>
            <!-- // -->
            <div class="row">
               <div class="col-sm-8 col-sm-offset-2">
                  <hr>
                  <h5>
                     GOKUEST is part of the Virgo group a market leader in Online travel and related services
                  </h5>
               </div>
            </div>
         </div>
      </footer>
      <!-- //onclick then go to top on page -->
      <a class="gototop" title="Go to top" href="#">
      <span class="fa fa-arrow-circle-up"></span>
      </a>
      <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
      <script src="js/jquery.1.12.4.min.js"></script>
      <script src="js/smoothscroll.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- Datepicker -->
      <script type="text/javascript" src="js/moment.js"></script>
      <script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>
      <!-- Common JS -->
      <script src="js/common.js"></script>
      <script>
         $(".close-popup").on('click' , function(){
                              $(".close-popup").parent().removeClass("in");
         });
         var rangeSlider = function(){
           var slider = $('.range-slider'),
               range = $('.range-slider__range'),
               value = $('.range-slider__value');
             
           slider.each(function(){
         
             value.each(function(){
               var value = $(this).prev().attr('value');
               $(this).html(value);
             });
         
             range.on('input', function(){
               $(this).next(value).html(this.value);
             });
           });
         };
         
         rangeSlider();
         
                           
      </script>
      <script src="js/jquery.slides.min.js"></script>
      <script>
         $(function() {
              $('#slides').slidesjs({
                width: 210,
                height: 170,
                navigation: false
              });
         
              /*
                To have multiple slideshows on the same page
                they just need to have separate IDs
              */
              $('#slides2').slidesjs({
                width: 210,
                height: 170,
                navigation: false,
                start: 3,
                play: {
                  auto: true
                }
              });
         
         });
      </script>
   </body>
</html>

