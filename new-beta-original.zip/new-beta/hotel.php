<?php

header('Content-Type: text/html; charset=utf-8');
error_reporting(E_ERROR | E_WARNING | E_PARSE);


	function random_string($type = 'alnum', $len = 8){					
		switch($type)
		{
			case 'alnum'	:
			case 'numeric'	:
			case 'nozero'	:
			case 'captcha'	:
			
					switch ($type)
					{
						case 'alnum'	:	$pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
							break;
						case 'numeric'	:	$pool = '0123456789';
							break;
						case 'nozero'	:	$pool = '123456789';
							break;
						case 'captcha'	:	$pool = '123456789abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ';
							break;
					}
	
					$str = '';
					for ($i=0; $i < $len; $i++)
					{
						$str .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
					}
					return $str;
			  break;
			case 'unique' : return md5(uniqid(mt_rand()));
			  break;
		}
	}
	

$user_random_id = random_string('unique',64);
//echo $user_random_id;

?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Gokuest</title>
        <link rel="icon" type="image/png" href="images/favicon-32 x 32.png">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/bootstrap-datetimepicker.min.css">
        <link href="css/style.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
        <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
        <!-- Google Tag Manager -->
        <script>
            (function (w, d, s, l, i) {
                w[l] = w[l] || [];
                w[l].push({
                    'gtm.start': new Date().getTime(),
                    event: 'gtm.js'
                });
                var f = d.getElementsByTagName(s)[0],
                    j = d.createElement(s),
                    dl = l != 'dataLayer' ? '&l=' + l : '';
                j.async = true;
                j.src =
                    'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
                f.parentNode.insertBefore(j, f);
            })(window, document, 'script', 'dataLayer', 'GTM-5V87L2S');
        </script>
        <!-- End Google Tag Manager -->
    </head>
    <script language="JavaScript" src="http://js.maxmind.com/js/apis/geoip2/v2.1/geoip2.js"></script>
    <script src="https://gokuestng.pushify.com/script.js?category=5929d04d41b7b4285e07e3a2"></script>

    <body>
        <div id="loader"><img src="images/logo.png" alt="Gokuest-Logo">Loading...</div>
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbarCollapse" aria-expanded="false">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#" title="Gokuest">
                        <img src="images/logo.png" alt="Gokuest-logo">
                    </a>
                </div>
                <!-- Collect the nav links for toggling -->
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="index.php" title="Flights"><i class="fa fa-plane" aria-hidden="true"></i> Flights</a></li>
                        <li><a href="#" title="Hotels" class="active"><i class="fa fa-bed" aria-hidden="true"></i> Hotels</a></li>
                        <li><a href="#" title="Cars"><i class="fa fa-car" aria-hidden="true"></i> Cars</a></li>
                        <li><a href="#" title="Tours"><i class="fa fa-suitcase" aria-hidden="true"></i> Tours</a></li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
            <!-- /.container -->
        </nav>

        <section class="


Container booking-section-hotel">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="weather-container">
                            <div class="weatherBox">
                                <h3 id="weatherName"></h3>
                                <p><img id="weatherImg" src="">&nbsp;<span id="weatherCelsius"></span></p>
                                <h4 id="weatherCloudiness"></h4>
                            </div>
                        </div>


                        <h1>Find the best deals from all the major hotel sites</h1>
                        <div class="home-page-form-wrapper">
                            <!-- Round Tab panes -->
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane active in fade" id="home">
                                    <div class="form-section">
                                        <div class="row">
                                            <form action="search.php" method="post">

                                                <input type="hidden" id="flights_system" name="flights_system" value="travelpaddy" />
                                                <input type="hidden" id="user_random_id" name="user_random_id" value="<?php echo $user_random_id ?>" />
                                                <input type="hidden" id="type_of_trip" name="type_of_trip" value="return" />


                                                <div class="col-sm-4 col-md-3">
                                                    <div class="marg-t-20 form-group tp-autocomplete">
                                                        <input type="text" class="form-control find-input find-input-line" id="place" name="to" placeholder="Enter Location" autocomplete="off" required>
                                                        <div id="search_response_to" class="from_to_suggestions"></div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-2">
                                                    <div class="marg-t-20 form-group">
                                                        <div class="input-group find-input-group date" id="datepicker1">
                                                            <span class="input-group-addon">
                        		<i class="fa fa-calendar-o"></i>
                        	</span>
                                                            <input type="text" class="form-control find-input" id="check_in" name="check_in" placeholder="Check in" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-2">
                                                    <div class="marg-t-20 form-group">
                                                        <div class="input-group find-input-group date" id="datepicker2">
                                                            <span class="input-group-addon">
                        		<i class="fa fa-calendar-o"></i>
                        	</span>
                                                            <input type="text" class="form-control find-input" id="check_out" name="check_out" placeholder="Check out" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-3">
                                                    <div class="form-group marg-t-20">
                                                        <div class="cabin-wrapper">
                                                            <input type="text" class="form-control find-input find-input-line" value="2 adults in 1 room" id="RoomTarget" name="RoomTarget" readonly>
                                                            <div class="cabin-design">
                                                                <div id="roomWrapper">
                                                                    <div class="roomCont firstElement">
                                                                        <div class="row">
                                                                            <div class="col-xs-12 mt8 box" id="roomCount">Room 1</div>
                                                                        </div>
                                                                        <div class="row mt10">
                                                                            <div class="col-xs-4 mt5">Adult</div>
                                                                            <div class="col-xs-5">
                                                                                <div class="input-group input-group-sm">
                                                                                    <span class="input-group-btn">
                                                        <button class="btn btn-default" type="button" data-counting="minus" data-person="Adult">
                                                            <span class="glyphicon glyphicon-minus"></span>
                                                                                    </button>
                                                                                    </span>
                                                                                    <input type="text" class="form-control adult-field" placeholder="0" data-choosen="Adult">
                                                                                    <span class="input-group-btn">
														<button class="btn btn-default" type="button" data-counting="plus" data-person="Adult">
                                                            <span class="glyphicon glyphicon-plus"></span>
                                                                                    </button>
                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-xs-3 mt5">12+</div>
                                                                        </div>
                                                                        <div class="row mt10">
                                                                            <div class="col-xs-4 mt5">Children</div>
                                                                            <div class="col-xs-5">
                                                                                <div class="input-group input-group-sm">
                                                                                    <span class="input-group-btn">
                                                        <button class="btn btn-default" type="button" data-counting="minus" data-person="Children">
                                                            <span class="glyphicon glyphicon-minus"></span>
                                                                                    </button>
                                                                                    </span>
                                                                                    <input type="text" class="form-control children-field" placeholder="0" data-choosen="Children">
                                                                                    <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button" data-counting="plus" data-person="Children">
                                                                <span class="glyphicon glyphicon-plus"></span>
                                                                                    </button>
                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-xs-3 mt5">2-11</div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row mt10">
                                                                    <div class="col-xs-8 col-md-6">
                                                                        <button class="btn btn-default" type="button" id="addRoom">
                                                                            <span class="glyphicon glyphicon-plus"></span> Add Room
                                                                        </button>
                                                                    </div>
                                                                    <div class="col-xs-8 col-md-6">
                                                                        <button class="btn btn-default hide" type="button" id="removeRoom">
                                                                            <span class="glyphicon glyphicon-minus"></span> Remove Room
                                                                        </button>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-md-2">
                                                    <button type="button" onclick="location.href = 'http://gokuest.com/new-beta/searchHotel.php';" class="btn btn-block btn-field-search">
                                                        Search
                                                    </button>

                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div role="tabpanel" class="tab-pane fade" id="profile">
                                    <div class="well">Coming Soon!</div>
                                </div>
                                <div role="tabpanel" class="tab-pane fade" id="messages">
                                    <div class="well">Coming Soon!</div>
                                </div>
                            </div>
                        </div>

                        <!-- // -->
                        <div class="compare-haeding">
                            <h5>Compare vs GOKUEST <small>all | none</small></h5>
                            <ul class="compare-list">
                                <li>
                                    <label>
                                        <input type="checkbox" name="">
                                        <span></span> Travelstart
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox" name="">
                                        <span></span> Hotels.com
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox" name="">
                                        <span></span> Booking.com
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox" name="">
                                        <span></span> Agoda.com
                                    </label>
                                </li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </section>

        <section class="three-plans">
            <div class="container">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="three-box">
                            <div class="plans-bg" style="background: url(images/pgcontent1.jpg);"></div>
                            <img src="">
                            <div class="three-box-content">
                                <h4>Your flight itinerary, status &amp; much more</h4>
                                <a href="#" title="Gokuest Travel">Gokuest Travel</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="three-box">
                            <div class="plans-bg" style="background: url(images/pgcontent2.jpg);"></div>
                            <img src="">
                            <div class="three-box-content">
                                <h4>See the world on your travel budget</h4>
                                <a href="#" title="Gokuest Explorer">Gokuest Explorer</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="three-box">
                            <div class="plans-bg" style="background: url(images/pgcontent3.jpg);"></div>
                            <img src="">
                            <div class="three-box-content">
                                <h4>Top Travel Destinations</h4>
                                <p>See and Know where to go!</p>
                                <a href="#" title="Travel Guide">Travel Guide</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <section class="area-section topHotelDestina">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="area-heading">
                            <h2>Trending Destinations</h2>
                            <h4>The most searched hotel destinations</h4>
                        </div>
                    </div>
                </div>

                <!-- //// -->
                <div class="row mt10">

                    <div class="col-sm-12">
                        <div class="col-sm-4 hotelMedia">
                            <div class="media">
                                <div class="media-left">
                                    <img src="images/cities/london.png" class="media-object">
                                </div>
                                <div class="media-body">
                                    <p> HOTELS IN
                                        <h4 class="media-heading">London</h4>
                                        <p>United Kingdom</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 hotelMedia">
                            <div class="media">
                                <div class="media-left">
                                    <img src="images/cities/dubai.png" class="media-object">
                                </div>
                                <div class="media-body">
                                    <p> HOTELS IN
                                        <h4 class="media-heading">Dubai</h4>
                                        <p>UAE</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 hotelMedia">
                            <div class="media">
                                <div class="media-left">
                                    <img src="images/cities/istanbul.png" class="media-object">
                                </div>
                                <div class="media-body">
                                    <p> HOTELS IN
                                        <h4 class="media-heading">Istanbul</h4>
                                        <p>Turkey</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt10">

                    <div class="col-sm-12">
                        <div class="col-sm-4 hotelMedia">
                            <div class="media">
                                <div class="media-left">
                                    <img src="images/cities/lahore.png" class="media-object">
                                </div>
                                <div class="media-body">
                                    <p> HOTELS IN
                                        <h4 class="media-heading">Lahore</h4>
                                        <p>Pakistan</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 hotelMedia">
                            <div class="media">
                                <div class="media-left">
                                    <img src="images/cities/amsterdam.png" class="media-object">
                                </div>
                                <div class="media-body">
                                    <p> HOTELS IN
                                        <h4 class="media-heading">Amsterdam</h4>
                                        <p>Netherlands</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 hotelMedia">
                            <div class="media">
                                <div class="media-left">
                                    <img src="images/cities/bangok.png" class="media-object">
                                </div>
                                <div class="media-body">
                                    <p> HOTELS IN
                                        <h4 class="media-heading">Bangkok</h4>
                                        <p>Thailand</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt10">

                    <div class="col-sm-12">
                        <div class="col-sm-4 hotelMedia">
                            <div class="media">
                                <div class="media-left">
                                    <img src="images/cities/newyork.png" class="media-object">
                                </div>
                                <div class="media-body">
                                    <p> HOTELS IN
                                        <h4 class="media-heading">New York</h4>
                                        <p>United States of America</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 hotelMedia">
                            <div class="media">
                                <div class="media-left">
                                    <img src="images/cities/capetown.png" class="media-object">
                                </div>
                                <div class="media-body">
                                    <p> HOTELS IN
                                        <h4 class="media-heading">Capetown</h4>
                                        <p>South Africa</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 hotelMedia">
                            <div class="media">
                                <div class="media-left">
                                    <img src="images/cities/paris.png" class="media-object">
                                </div>
                                <div class="media-body">
                                    <p> HOTELS IN
                                        <h4 class="media-heading">Paris</h4>
                                        <p>France</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-4 col-lg-5">
                        <ul>
                            <li><a href="#" title="About GoKuest">About GoKuest</a></li>
                            <li><a href="#" title="GoKuest on Mobile">GoKuest on Mobile</a></li>
                            <li><a href="#" title="Careers">Careers</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-4 col-lg-5">
                        <ul>
                            <li><a href="#" title="FAQ">FAQ</a></li>
                            <li><a href="#" title="Hotel Operations">Hotel Operations</a></li>
                            <li><a href="#" title="Terms and Conditions">Terms and Conditions</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-4 col-lg-2">
                        <ul>
                            <li>
                                <p>Country / Currency</p>
                            </li>
                        </ul>
                        <div class="footer-select">
                            <select>
                                <option>Negeria / Naira</option>
                                <option>England / Dollar</option>
                                <option>America / Dollar</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- // -->
                <div class="row">
                    <div class="col-sm-12">
                        <h3>
					Search cheap flights with GOKUEST. Find the cheapest airline tickets for all the top airlines around the world and the top international flight routes. We search travel sites to help you find and book the flight that suits you best.
				</h3>
                        <div class="social-icons">
                            <h4>Socialize with us</h4>
                            <a href="#" title="Facebook" target="_blank"><span class="fa fa-facebook"></span></a>
                            <a href="#" title="Twitter" target="_blank"><span class="fa fa-twitter"></span></a>
                            <a href="#" title="Youtube" target="_blank"><span class="fa fa-youtube"></span></a>
                            <a href="#" title="Instagram" target="_blank"><span class="fa fa-instagram"></span></a>
                        </div>
                    </div>
                </div>
                <!-- // -->
                <div class="row">
                    <div class="col-sm-8 col-sm-offset-2">
                        <hr>
                        <h5>
					GOKUEST is part of the Virgo group a market leader in Online travel and related services
				</h5>
                    </div>
                </div>
            </div>
        </footer>

        <!-- //onclick then go to top on page -->
        <a class="gototop" title="Go to top" href="#">
            <span class="fa fa-arrow-circle-up"></span>
        </a>


        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery.1.12.4.min.js"></script>
        <script src="js/smoothscroll.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <!-- Datepicker -->

        <script type="text/javascript" src="js/moment.js"></script>
        <script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>

        <!-- Common JS -->
        <script src="js/common.js"></script>
        <script src='//vws.responsivevoice.com/v/e?key=OZUmHffv'></script>
        <!-- Autocomplete JS -->
        <script>
            // ToondBad
            function initMap() {
                var input = document.getElementById('place');
                var autocomplete = new google.maps.places.Autocomplete(input);
            }

            function loaderImage(q) {
                var url = "https://pixabay.com/api/?";
                var key = "5708871-4395043ecb88b99f3ac63f582";
                var finalurl = url + "key=" + key + "&q=" + q + "&image_type=photo";
                //alert(finalurl);

                $.getJSON(finalurl, null)
                    .done(function (data) {
                        // alert(JSON.stringify(data));
                        if (data.hits) {
                            var item = data.hits[0];
                            $(".booking-section").css('background', "url('" + item.webformatURL + "')");
                            $(".booking-section").css('background-size', "cover");
                        }
                        /*$.each(data.hits, function (i, item) {
			          console.log("=========== start ===========");
			          console.log(item);
			          console.log("=========== end ===========");
                      //$(".booking-section").css('background',"url('"+ item.previewURL+"')");
			          
                      $("<img>").attr("src", item.userImageURL).appendTo("#images");
                      if (i === 2) {
                          return false;
                      }
                  });*/
                    });
            }

            function get_airport_suggestions(my_input_value, from_to_marker) {
                $.ajax({
                    type: "POST",
                    url: 'php/get_airport_suggestions.php',
                    data: {
                        my_input_value: my_input_value
                    },
                    success: function (response) {
                        $('#search_response_' + from_to_marker).html(response).addClass('open');
                        from_to_marker = '';
                        $('.open .suggestion').click(function (e) {
                            suggestion_value = $(this).html();
                            $(this).parents('.tp-autocomplete').find('input').attr('title', suggestion_value).val(suggestion_value);
                            $(this).parent().removeClass('open');
                            // ToondBad 6/21/2017
                            //alert(suggestion_value);

                            var q = suggestion_value.substring(0, suggestion_value.indexOf(","));
                            loaderImage(q);


                        });
                    }
                });
            }

            $('document').ready(function () {


                my_input_from_value = '';
                my_input_to_value = '';
                my_input_from_counter = 0;
                my_input_to_counter = 0;
                from_to_marker = '';
                $('.my-input-from').bind('input', function () {
                    my_input_from_counter = $('.my-input-from').val().length;
                    //alert(my_input_from_counter);
                    // ToondBad
                    //alert();
                    if (my_input_from_counter >= 3) {
                        my_input_from_value = $('.my-input-from').val();
                        from_to_marker = 'from';
                        get_airport_suggestions(my_input_from_value, from_to_marker);
                    } else {
                        $('.my-input-from').next().removeClass('open');
                    }

                });

                $('.my-input-to').bind('input', function () {
                    my_input_to_counter = $('.my-input-to').val().length;
                    //alert(my_input_to_counter);
                    if (my_input_to_counter >= 3) {
                        my_input_to_value = $('.my-input-to').val();
                        from_to_marker = 'to';
                        get_airport_suggestions(my_input_to_value, from_to_marker);
                    } else {
                        $('.my-input-to').next().removeClass('open');
                    }
                });

            });
        </script>
        <script>
            function addCommas(str) {
                var parts = (str + "").split("."),
                    main = parts[0],
                    len = main.length,
                    output = "",
                    first = main.charAt(0),
                    i;

                if (first === '-') {
                    main = main.slice(1);
                    len = main.length;
                } else {
                    first = "";
                }
                i = len - 1;
                while (i >= 0) {
                    output = main.charAt(i) + output;
                    if ((len - i) % 3 === 0 && i > 0) {
                        output = "," + output;
                    }
                    --i;
                }
                // put sign back
                output = first + output;
                // put decimal part back
                if (parts.length > 1) {
                    output += "." + parts[1];
                }
                return output;
            }
        </script>
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB-N1RhnBC941h-6Cs5h2PXrTrVIWx4Xmk&libraries=places&callback=initMap" async defer></script>
        < /body>
            < /html>